import json
import boto3
from botocore.exceptions import ClientError
from datetime import datetime
from decimal import Decimal
def lambda_handler(event, context):
    # uni is the primary/paritition key
    # note they all have unique attributes
    restraunts = [
    {
        "bid": "hdiuRS9sVZSMReZm4oV5SA",
        "rating": 4.5,
        "reviews": 1820,
        "coordinates": {
            "latitude": 40.736218,
            "longitude": -73.99597
        },
        "name": "Da Andrea",
        "address": {
            "address1": "35 W 13th St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10011",
            "country": "US",
            "state": "NY",
            "display_address": [
                "35 W 13th St",
                "New York, NY 10011"
            ]
        }
    },
    {
        "bid": "IA3EQ0Ilx0yI7dNYnq-YGQ",
        "rating": 4.5,
        "reviews": 149,
        "coordinates": {
            "latitude": 40.730369942268375,
            "longitude": -73.9837222575225
        },
        "name": "Salma",
        "address": {
            "address1": "351 E 12th St",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10003",
            "country": "US",
            "state": "NY",
            "display_address": [
                "351 E 12th St",
                "New York, NY 10003"
            ]
        }
    },
    {
        "bid": "owYYuyLvlsdjLz68c3SSfg",
        "rating": 4.5,
        "reviews": 981,
        "coordinates": {
            "latitude": 40.7346038818359,
            "longitude": -73.9928283691406
        },
        "name": "Taboonette",
        "address": {
            "address1": "30 E 13th St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10003",
            "country": "US",
            "state": "NY",
            "display_address": [
                "30 E 13th St",
                "New York, NY 10003"
            ]
        }
    },
    {
        "bid": "Rj2ACaJcbroJLPDhRhzvBw",
        "rating": 4.5,
        "reviews": 856,
        "coordinates": {
            "latitude": 40.72707,
            "longitude": -74.00283
        },
        "name": "Shuka",
        "address": {
            "address1": "38 MacDougal St",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10012",
            "country": "US",
            "state": "NY",
            "display_address": [
                "38 MacDougal St",
                "New York, NY 10012"
            ]
        }
    },
    {
        "bid": "jAaVnUKLITkuhzwXIe0vLQ",
        "rating": 4.5,
        "reviews": 1370,
        "coordinates": {
            "latitude": 40.719747,
            "longitude": -73.959993
        },
        "name": "Cafe Mogador",
        "address": {
            "address1": "133 Wythe Ave",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11211",
            "country": "US",
            "state": "NY",
            "display_address": [
                "133 Wythe Ave",
                "Brooklyn, NY 11211"
            ]
        }
    },
    {
        "bid": "0FaLilJs2VN83hOEBcBnPg",
        "rating": 4.0,
        "reviews": 1490,
        "coordinates": {
            "latitude": 40.728901,
            "longitude": -73.981185
        },
        "name": "Au Za'atar",
        "address": {
            "address1": "188 Avenue A",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10009",
            "country": "US",
            "state": "NY",
            "display_address": [
                "188 Avenue A",
                "New York, NY 10009"
            ]
        }
    },
    {
        "bid": "SwFr8vVU9j2Wlo-QejpRGA",
        "rating": 4.5,
        "reviews": 105,
        "coordinates": {
            "latitude": 40.69059,
            "longitude": -73.99503
        },
        "name": "Al Badawi",
        "address": {
            "address1": "151 Atlantic Ave",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11201",
            "country": "US",
            "state": "NY",
            "display_address": [
                "151 Atlantic Ave",
                "Brooklyn, NY 11201"
            ]
        }
    },
    {
        "bid": "BODtGPQP__QyMMI7zWvtTA",
        "rating": 5.0,
        "reviews": 26,
        "coordinates": {
            "latitude": 40.71745,
            "longitude": -73.95614
        },
        "name": "Bis Bas Mediterranean Grill",
        "address": {
            "address1": "536 Driggs Ave",
            "address2": None,
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11211",
            "country": "US",
            "state": "NY",
            "display_address": [
                "536 Driggs Ave",
                "Brooklyn, NY 11211"
            ]
        }
    },
    {
        "bid": "cg7IxNN5wyrXVP5tkCaZRg",
        "rating": 4.5,
        "reviews": 411,
        "coordinates": {
            "latitude": 40.689436,
            "longitude": -73.9723809
        },
        "name": "Miss Ada",
        "address": {
            "address1": "184 Dekalb Ave",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11205",
            "country": "US",
            "state": "NY",
            "display_address": [
                "184 Dekalb Ave",
                "Brooklyn, NY 11205"
            ]
        }
    },
    {
        "bid": "wYmb7YpPwlchsYEPHzgcdQ",
        "rating": 4.5,
        "reviews": 73,
        "coordinates": {
            "latitude": 40.71418787933165,
            "longitude": -73.96078337251589
        },
        "name": "The Rusty Face",
        "address": {
            "address1": "188 Grand St",
            "address2": None,
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11211",
            "country": "US",
            "state": "NY",
            "display_address": [
                "188 Grand St",
                "Brooklyn, NY 11211"
            ]
        }
    },
    {
        "bid": "OL2su47yPDPZyvzY8IRk9A",
        "rating": 5.0,
        "reviews": 85,
        "coordinates": {
            "latitude": 40.69756,
            "longitude": -73.9719
        },
        "name": "Holy Pita",
        "address": {
            "address1": "10 Clermont Ave",
            "address2": None,
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11205",
            "country": "US",
            "state": "NY",
            "display_address": [
                "10 Clermont Ave",
                "Brooklyn, NY 11205"
            ]
        }
    },
    {
        "bid": "0AoaUlXkQOlalpA3v-Ivqw",
        "rating": 4.5,
        "reviews": 225,
        "coordinates": {
            "latitude": 40.71964,
            "longitude": -73.98507
        },
        "name": "Lava Shawarma",
        "address": {
            "address1": "57 Clinton St",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10002",
            "country": "US",
            "state": "NY",
            "display_address": [
                "57 Clinton St",
                "New York, NY 10002"
            ]
        }
    },
    {
        "bid": "4lvM8_IWe_TgSszfwhmrdg",
        "rating": 4.0,
        "reviews": 434,
        "coordinates": {
            "latitude": 40.7145615,
            "longitude": -73.9653168
        },
        "name": "12 Chairs Cafe",
        "address": {
            "address1": "342 Wythe Ave",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "11249",
            "country": "US",
            "state": "NY",
            "display_address": [
                "342 Wythe Ave",
                "New York, NY 11249"
            ]
        }
    },
    {
        "bid": "StF9WWWbrRzEOmNAcEINcA",
        "rating": 4.0,
        "reviews": 519,
        "coordinates": {
            "latitude": 40.72139,
            "longitude": -73.99545
        },
        "name": "Balzem",
        "address": {
            "address1": "202 Mott St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10012",
            "country": "US",
            "state": "NY",
            "display_address": [
                "202 Mott St",
                "New York, NY 10012"
            ]
        }
    },
    {
        "bid": "W4hobe10Fy54MKqmLaObEg",
        "rating": 4.0,
        "reviews": 2098,
        "coordinates": {
            "latitude": 40.727258767439,
            "longitude": -73.9845085144043
        },
        "name": "Cafe Mogador",
        "address": {
            "address1": "101 St Marks Pl",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10009",
            "country": "US",
            "state": "NY",
            "display_address": [
                "101 St Marks Pl",
                "New York, NY 10009"
            ]
        }
    },
    {
        "bid": "niODyKeyStKEut1b6FNlhQ",
        "rating": 4.5,
        "reviews": 162,
        "coordinates": {
            "latitude": 40.736601,
            "longitude": -73.985085
        },
        "name": "Eleni's",
        "address": {
            "address1": "226 3rd Ave",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10003",
            "country": "US",
            "state": "NY",
            "display_address": [
                "226 3rd Ave",
                "New York, NY 10003"
            ]
        }
    },
    {
        "bid": "20PuwdAiKJmyMBnYGTtHGg",
        "rating": 4.5,
        "reviews": 66,
        "coordinates": {
            "latitude": 40.71897,
            "longitude": -73.95634
        },
        "name": "Terasa North Ninth",
        "address": {
            "address1": "145 Bedford Ave",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11211",
            "country": "US",
            "state": "NY",
            "display_address": [
                "145 Bedford Ave",
                "Brooklyn, NY 11211"
            ]
        }
    },
    {
        "bid": "kTQ0rRfgtlPwX9_O8OY_UA",
        "rating": 4.0,
        "reviews": 469,
        "coordinates": {
            "latitude": 40.742575,
            "longitude": -74.006206
        },
        "name": "Miznon",
        "address": {
            "address1": "435 W 15th St",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10011",
            "country": "US",
            "state": "NY",
            "display_address": [
                "435 W 15th St",
                "New York, NY 10011"
            ]
        }
    },
    {
        "bid": "7xV4gzrgaOgQYtPC3FBZig",
        "rating": 4.5,
        "reviews": 1212,
        "coordinates": {
            "latitude": 40.72608,
            "longitude": -73.98415
        },
        "name": "Pylos",
        "address": {
            "address1": "128 E 7th St",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10009",
            "country": "US",
            "state": "NY",
            "display_address": [
                "128 E 7th St",
                "New York, NY 10009"
            ]
        }
    },
    {
        "bid": "CuwHhq1MKX5hm8YyxtqukQ",
        "rating": 4.5,
        "reviews": 218,
        "coordinates": {
            "latitude": 40.74745,
            "longitude": -74.00041
        },
        "name": "Shukette",
        "address": {
            "address1": "230 9th Ave",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10001",
            "country": "US",
            "state": "NY",
            "display_address": [
                "230 9th Ave",
                "New York, NY 10001"
            ]
        }
    },
    {
        "bid": "x7Q721PDf7s1iYYP7diaVw",
        "rating": 4.5,
        "reviews": 97,
        "coordinates": {
            "latitude": 40.72252,
            "longitude": -73.99296
        },
        "name": "Karvouna Mezze",
        "address": {
            "address1": "241 Bowery",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10002",
            "country": "US",
            "state": "NY",
            "display_address": [
                "241 Bowery",
                "New York, NY 10002"
            ]
        }
    },
    {
        "bid": "gG0pitVnSaUMGbEL3boF0g",
        "rating": 4.0,
        "reviews": 956,
        "coordinates": {
            "latitude": 40.721196,
            "longitude": -73.987118
        },
        "name": "Souvlaki GR",
        "address": {
            "address1": "116 Stanton St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10002",
            "country": "US",
            "state": "NY",
            "display_address": [
                "116 Stanton St",
                "New York, NY 10002"
            ]
        }
    },
    {
        "bid": "oqVG2LsTwvRzgJxId5pqiw",
        "rating": 4.5,
        "reviews": 562,
        "coordinates": {
            "latitude": 40.711266,
            "longitude": -73.950317
        },
        "name": "Dar 525",
        "address": {
            "address1": "525 Grand St",
            "address2": None,
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11211",
            "country": "US",
            "state": "NY",
            "display_address": [
                "525 Grand St",
                "Brooklyn, NY 11211"
            ]
        }
    },
    {
        "bid": "Jhs11j9wkfN98uXYGHx4Zw",
        "rating": 4.5,
        "reviews": 33,
        "coordinates": {
            "latitude": 40.6882741,
            "longitude": -73.989238
        },
        "name": "Zerda Mediterranean Cuisine",
        "address": {
            "address1": "101 Smith St",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11201",
            "country": "US",
            "state": "NY",
            "display_address": [
                "101 Smith St",
                "Brooklyn, NY 11201"
            ]
        }
    },
    {
        "bid": "nYZorUGAc8Df3H6l8iqXcA",
        "rating": 5.0,
        "reviews": 12,
        "coordinates": {
            "latitude": 40.71197,
            "longitude": -73.96277
        },
        "name": "ROKA Modern Mediterranean",
        "address": {
            "address1": "349 Bedford Ave",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11211",
            "country": "US",
            "state": "NY",
            "display_address": [
                "349 Bedford Ave",
                "Brooklyn, NY 11211"
            ]
        }
    },
    {
        "bid": "R3fMQtSL0MrMUyW_Q32oNw",
        "rating": 4.5,
        "reviews": 181,
        "coordinates": {
            "latitude": 40.7021301747589,
            "longitude": -74.0118362768599
        },
        "name": "NAYA - FiDi",
        "address": {
            "address1": "One New York Plz",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10004",
            "country": "US",
            "state": "NY",
            "display_address": [
                "One New York Plz",
                "New York, NY 10004"
            ]
        }
    },
    {
        "bid": "_4Grm99JEHnDWskCHAJfUg",
        "rating": 4.0,
        "reviews": 787,
        "coordinates": {
            "latitude": 40.7144971858255,
            "longitude": -73.9918553931336
        },
        "name": "Kiki's",
        "address": {
            "address1": "130 Division St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10002",
            "country": "US",
            "state": "NY",
            "display_address": [
                "130 Division St",
                "New York, NY 10002"
            ]
        }
    },
    {
        "bid": "lUpyqsKw-IBqsMgYIHZj7Q",
        "rating": 4.0,
        "reviews": 907,
        "coordinates": {
            "latitude": 40.730251,
            "longitude": -73.983001
        },
        "name": "Balade",
        "address": {
            "address1": "208 1st Ave",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10009",
            "country": "US",
            "state": "NY",
            "display_address": [
                "208 1st Ave",
                "New York, NY 10009"
            ]
        }
    },
    {
        "bid": "6G0urbBDz_CnYnGXApgUcw",
        "rating": 4.5,
        "reviews": 186,
        "coordinates": {
            "latitude": 40.6901481293837,
            "longitude": -73.9935445412993
        },
        "name": "Boutros",
        "address": {
            "address1": "185 Atlantic Ave",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11201",
            "country": "US",
            "state": "NY",
            "display_address": [
                "185 Atlantic Ave",
                "Brooklyn, NY 11201"
            ]
        }
    },
    {
        "bid": "4fNKBr3mlxKHfCojW0i_Uw",
        "rating": 4.0,
        "reviews": 463,
        "coordinates": {
            "latitude": 40.75174,
            "longitude": -73.97395
        },
        "name": "NAYA - 44 & 3rd",
        "address": {
            "address1": "688 3rd Ave",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10017",
            "country": "US",
            "state": "NY",
            "display_address": [
                "688 3rd Ave",
                "New York, NY 10017"
            ]
        }
    },
    {
        "bid": "VSPkVw9gSQx-5v4A6aC_YA",
        "rating": 4.5,
        "reviews": 503,
        "coordinates": {
            "latitude": 40.729511,
            "longitude": -74.001275
        },
        "name": "Manousheh - Bleecker",
        "address": {
            "address1": "193 Bleecker St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10012",
            "country": "US",
            "state": "NY",
            "display_address": [
                "193 Bleecker St",
                "New York, NY 10012"
            ]
        }
    },
    {
        "bid": "4taegd-dJm0xGJOmqG5DtQ",
        "rating": 4.5,
        "reviews": 81,
        "coordinates": {
            "latitude": 40.73461,
            "longitude": -73.95822
        },
        "name": "Cafe Alula",
        "address": {
            "address1": "252 Franklin St",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11222",
            "country": "US",
            "state": "NY",
            "display_address": [
                "252 Franklin St",
                "Brooklyn, NY 11222"
            ]
        }
    },
    {
        "bid": "9CMlqg0iZgYMlyUN9iroeg",
        "rating": 4.5,
        "reviews": 49,
        "coordinates": {
            "latitude": 40.8545299,
            "longitude": -73.85499
        },
        "name": "SOFRA  - Traditional Greek & Albanian cuisine",
        "address": {
            "address1": "2011A Williamsbridge Rd",
            "address2": None,
            "address3": "",
            "city": "Bronx",
            "zip_code": "10461",
            "country": "US",
            "state": "NY",
            "display_address": [
                "2011A Williamsbridge Rd",
                "Bronx, NY 10461"
            ]
        }
    },
    {
        "bid": "l9b8NbDyhKhnjLKtUwlPwQ",
        "rating": 4.0,
        "reviews": 982,
        "coordinates": {
            "latitude": 40.6877844,
            "longitude": -73.9706046
        },
        "name": "Olea",
        "address": {
            "address1": "171 Lafayette Ave",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11238",
            "country": "US",
            "state": "NY",
            "display_address": [
                "171 Lafayette Ave",
                "Brooklyn, NY 11238"
            ]
        }
    },
    {
        "bid": "iIcFJGEJ6MmPCXD2cjq7dg",
        "rating": 5.0,
        "reviews": 4,
        "coordinates": {
            "latitude": 40.585906,
            "longitude": -74.092244
        },
        "name": "Al Aqsa Restaurant",
        "address": {
            "address1": "1758 Hylan Blvd",
            "address2": "",
            "address3": None,
            "city": "Staten Island",
            "zip_code": "10305",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1758 Hylan Blvd",
                "Staten Island, NY 10305"
            ]
        }
    },
    {
        "bid": "1hdwhb6kzLxL3Lt3PxoHKA",
        "rating": 4.0,
        "reviews": 234,
        "coordinates": {
            "latitude": 40.72015,
            "longitude": -73.99623
        },
        "name": "Shoo Shoo",
        "address": {
            "address1": "371 Broome St",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10013",
            "country": "US",
            "state": "NY",
            "display_address": [
                "371 Broome St",
                "New York, NY 10013"
            ]
        }
    },
    {
        "bid": "M7KW96iW-c9FGKkkDC25OQ",
        "rating": 5.0,
        "reviews": 13,
        "coordinates": {
            "latitude": 40.71791,
            "longitude": -74.00539
        },
        "name": "Tara Kitchen - Tribeca New York",
        "address": {
            "address1": "253 Church St",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10013",
            "country": "US",
            "state": "NY",
            "display_address": [
                "253 Church St",
                "New York, NY 10013"
            ]
        }
    },
    {
        "bid": "4aF0F8w7yXX9o5_QFky_ig",
        "rating": 4.0,
        "reviews": 273,
        "coordinates": {
            "latitude": 40.704676,
            "longitude": -73.987975
        },
        "name": "Celestine",
        "address": {
            "address1": "1 John St",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11201",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1 John St",
                "Brooklyn, NY 11201"
            ]
        }
    },
    {
        "bid": "SysAthrDghPL62a6OElOCQ",
        "rating": 4.0,
        "reviews": 543,
        "coordinates": {
            "latitude": 40.726957,
            "longitude": -73.9885354
        },
        "name": "Local 92",
        "address": {
            "address1": "92 2nd Ave",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10003",
            "country": "US",
            "state": "NY",
            "display_address": [
                "92 2nd Ave",
                "New York, NY 10003"
            ]
        }
    },
    {
        "bid": "Vw8NSOu7aS8de1vVhFpemQ",
        "rating": 5.0,
        "reviews": 314,
        "coordinates": {
            "latitude": 40.70401,
            "longitude": -73.93086
        },
        "name": "Yia Yia's Taverna",
        "address": {
            "address1": "1035 Flushing Ave",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11237",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1035 Flushing Ave",
                "Brooklyn, NY 11237"
            ]
        }
    },
    {
        "bid": "d8zSYpArh4oXpxeJWNA4Pg",
        "rating": 4.5,
        "reviews": 795,
        "coordinates": {
            "latitude": 40.715688,
            "longitude": -74.007695
        },
        "name": "Nish Nush",
        "address": {
            "address1": "88 Reade St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10013",
            "country": "US",
            "state": "NY",
            "display_address": [
                "88 Reade St",
                "New York, NY 10013"
            ]
        }
    },
    {
        "bid": "i38R1KxL99JoG-Ns7FyyGw",
        "rating": 4.0,
        "reviews": 826,
        "coordinates": {
            "latitude": 40.72759,
            "longitude": -74.0024
        },
        "name": "12 Chairs",
        "address": {
            "address1": "56 MacDougal St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10012",
            "country": "US",
            "state": "NY",
            "display_address": [
                "56 MacDougal St",
                "New York, NY 10012"
            ]
        }
    },
    {
        "bid": "ExvoimQ4LzY3UWtZ6m6Lgw",
        "rating": 4.0,
        "reviews": 928,
        "coordinates": {
            "latitude": 40.74726700950392,
            "longitude": -73.98311794328527
        },
        "name": "Ravagh Persian Grill",
        "address": {
            "address1": "173 Madison Ave",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10016",
            "country": "US",
            "state": "NY",
            "display_address": [
                "173 Madison Ave",
                "New York, NY 10016"
            ]
        }
    },
    {
        "bid": "7gZGVdqMch7ls0IGO3DijQ",
        "rating": 4.5,
        "reviews": 674,
        "coordinates": {
            "latitude": 40.77492,
            "longitude": -73.95412
        },
        "name": "Agora Turkish Restaurant",
        "address": {
            "address1": "1565 2nd Ave",
            "address2": None,
            "address3": None,
            "city": "New York",
            "zip_code": "10028",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1565 2nd Ave",
                "New York, NY 10028"
            ]
        }
    },
    {
        "bid": "h77VtGL7BCXvAALx-ZFbVA",
        "rating": 4.5,
        "reviews": 201,
        "coordinates": {
            "latitude": 40.67857,
            "longitude": -73.97885
        },
        "name": "Medusa The Greek",
        "address": {
            "address1": "133 5th Ave",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11217",
            "country": "US",
            "state": "NY",
            "display_address": [
                "133 5th Ave",
                "Brooklyn, NY 11217"
            ]
        }
    },
    {
        "bid": "Ptd1vzkvdeZUws9zuLR4FA",
        "rating": 5.0,
        "reviews": 21,
        "coordinates": {
            "latitude": 40.71096,
            "longitude": -74.00787
        },
        "name": "Omar\u2019s Mediterranean Cuisine",
        "address": {
            "address1": "15 Ann St",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10038",
            "country": "US",
            "state": "NY",
            "display_address": [
                "15 Ann St",
                "New York, NY 10038"
            ]
        }
    },
    {
        "bid": "wctR1TrheHAwpHZ2sJknEw",
        "rating": 4.5,
        "reviews": 605,
        "coordinates": {
            "latitude": 40.68989,
            "longitude": -73.99366
        },
        "name": "Yemen Cafe & Restaurant",
        "address": {
            "address1": "176 Atlantic Ave",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11201",
            "country": "US",
            "state": "NY",
            "display_address": [
                "176 Atlantic Ave",
                "Brooklyn, NY 11201"
            ]
        }
    },
    {
        "bid": "hzPSNFwMVzMAkmdtLROJow",
        "rating": 4.5,
        "reviews": 74,
        "coordinates": {
            "latitude": 40.777448,
            "longitude": -73.94927679999999
        },
        "name": "Lashevet Restaurant",
        "address": {
            "address1": "1663 1st Ave",
            "address2": None,
            "address3": None,
            "city": "New York",
            "zip_code": "10028",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1663 1st Ave",
                "New York, NY 10028"
            ]
        }
    },
    {
        "bid": "B55Ocx5RBWxo6AGSucYSIA",
        "rating": 4.0,
        "reviews": 2669,
        "coordinates": {
            "latitude": 40.74435,
            "longitude": -73.98778
        },
        "name": "Ilili",
        "address": {
            "address1": "236 5th Ave",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10001",
            "country": "US",
            "state": "NY",
            "display_address": [
                "236 5th Ave",
                "New York, NY 10001"
            ]
        }
    },
    {
        "bid": "ZD9OPTKRx-BWqXgfqwCy7w",
        "rating": 4.5,
        "reviews": 201,
        "coordinates": {
            "latitude": 40.75725,
            "longitude": -73.96808
        },
        "name": "Souvlaki GR",
        "address": {
            "address1": "231 E 53rd St",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10022",
            "country": "US",
            "state": "NY",
            "display_address": [
                "231 E 53rd St",
                "New York, NY 10022"
            ]
        }
    },
    {
        "bid": "lnTPfdaqDqWjywWewsE2Lw",
        "rating": 4.0,
        "reviews": 1169,
        "coordinates": {
            "latitude": 40.6801719843659,
            "longitude": -73.9777555239717
        },
        "name": "Miriam",
        "address": {
            "address1": "79 5th Ave",
            "address2": None,
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11217",
            "country": "US",
            "state": "NY",
            "display_address": [
                "79 5th Ave",
                "Brooklyn, NY 11217"
            ]
        }
    },
    {
        "bid": "-JBFRO2z1Fr6og-3VGYRxQ",
        "rating": 4.0,
        "reviews": 341,
        "coordinates": {
            "latitude": 40.687318869309735,
            "longitude": -73.9724778
        },
        "name": "Black Iris",
        "address": {
            "address1": "120 Lafayette Ave",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11205",
            "country": "US",
            "state": "NY",
            "display_address": [
                "120 Lafayette Ave",
                "Brooklyn, NY 11205"
            ]
        }
    },
    {
        "bid": "s5N-w7EPY3DA68id5qycyA",
        "rating": 4.0,
        "reviews": 147,
        "coordinates": {
            "latitude": 40.74549437933232,
            "longitude": -73.9889085
        },
        "name": "Zaytinya - New York",
        "address": {
            "address1": "1185 Broadway",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10001",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1185 Broadway",
                "New York, NY 10001"
            ]
        }
    },
    {
        "bid": "jPLWQrh15gpyl5P4Qj6mKg",
        "rating": 4.5,
        "reviews": 11,
        "coordinates": {
            "latitude": 40.94165,
            "longitude": -73.96117
        },
        "name": "Chef Mediterranean",
        "address": {
            "address1": "38 Union Ave",
            "address2": "",
            "address3": None,
            "city": "Cresskill",
            "zip_code": "07626",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "38 Union Ave",
                "Cresskill, NJ 07626"
            ]
        }
    },
    {
        "bid": "IxFTW7805MrWpbV4RbSFhw",
        "rating": 4.0,
        "reviews": 258,
        "coordinates": {
            "latitude": 40.7208633,
            "longitude": -73.9950497
        },
        "name": "Little Rascal",
        "address": {
            "address1": "163 Elizabeth St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10012",
            "country": "US",
            "state": "NY",
            "display_address": [
                "163 Elizabeth St",
                "New York, NY 10012"
            ]
        }
    },
    {
        "bid": "k_zlryLtGZIS5QElKY8P2A",
        "rating": 5.0,
        "reviews": 2,
        "coordinates": {
            "latitude": 40.71529387315348,
            "longitude": -73.9586678890717
        },
        "name": "Cava",
        "address": {
            "address1": "174 N 4th St",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11211",
            "country": "US",
            "state": "NY",
            "display_address": [
                "174 N 4th St",
                "Brooklyn, NY 11211"
            ]
        }
    },
    {
        "bid": "m-G7KgMjYvrZNs5Jibfx4Q",
        "rating": 4.5,
        "reviews": 132,
        "coordinates": {
            "latitude": 40.72098218304858,
            "longitude": -73.95860654260929
        },
        "name": "Laser Wolf",
        "address": {
            "address1": "97 Wyth Ave",
            "address2": None,
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11249",
            "country": "US",
            "state": "NY",
            "display_address": [
                "97 Wyth Ave",
                "Brooklyn, NY 11249"
            ]
        }
    },
    {
        "bid": "tM8ZtEix8Bxg82AIKsHXcw",
        "rating": 4.5,
        "reviews": 168,
        "coordinates": {
            "latitude": 40.74293,
            "longitude": -74.00002
        },
        "name": "Zizi",
        "address": {
            "address1": "182 8th Ave",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10011",
            "country": "US",
            "state": "NY",
            "display_address": [
                "182 8th Ave",
                "New York, NY 10011"
            ]
        }
    },
    {
        "bid": "tV6Tgw6FS45BRHyQ207jag",
        "rating": 4.5,
        "reviews": 663,
        "coordinates": {
            "latitude": 40.75905,
            "longitude": -73.969273
        },
        "name": "Omar's Mediterranean East Midtown",
        "address": {
            "address1": "154 E 55th St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10022",
            "country": "US",
            "state": "NY",
            "display_address": [
                "154 E 55th St",
                "New York, NY 10022"
            ]
        }
    },
    {
        "bid": "dtcV8BLJ-0yVdYi0rwlLog",
        "rating": 5.0,
        "reviews": 2,
        "coordinates": {
            "latitude": 40.757165,
            "longitude": -73.968479
        },
        "name": "Ali Baba Mediterranean Cuisine",
        "address": {
            "address1": "224 E 53rd St",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10022",
            "country": "US",
            "state": "NY",
            "display_address": [
                "224 E 53rd St",
                "New York, NY 10022"
            ]
        }
    },
    {
        "bid": "yWhXiBrycr5h4oVSMB_8zQ",
        "rating": 4.5,
        "reviews": 109,
        "coordinates": {
            "latitude": 40.69027,
            "longitude": -73.99503
        },
        "name": "Sultan Restaurant & Cafe Lounge",
        "address": {
            "address1": "144 Atlantic Ave",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11201",
            "country": "US",
            "state": "NY",
            "display_address": [
                "144 Atlantic Ave",
                "Brooklyn, NY 11201"
            ]
        }
    },
    {
        "bid": "BjBHOqapJJmM6bN6XlzEvQ",
        "rating": 4.5,
        "reviews": 44,
        "coordinates": {
            "latitude": 40.748914,
            "longitude": -73.992528
        },
        "name": "NAYA - Chelsea",
        "address": {
            "address1": "370 7th Ave",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10001",
            "country": "US",
            "state": "NY",
            "display_address": [
                "370 7th Ave",
                "New York, NY 10001"
            ]
        }
    },
    {
        "bid": "HcWm-9ZZu2_brnuRxN5Gpg",
        "rating": 4.0,
        "reviews": 250,
        "coordinates": {
            "latitude": 40.70021198326452,
            "longitude": -73.99331599999907
        },
        "name": "Tutt  Heights",
        "address": {
            "address1": "47 Hicks St",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11201",
            "country": "US",
            "state": "NY",
            "display_address": [
                "47 Hicks St",
                "Brooklyn, NY 11201"
            ]
        }
    },
    {
        "bid": "goKn7tKTIqpNPM_jR2yRCg",
        "rating": 4.0,
        "reviews": 218,
        "coordinates": {
            "latitude": 40.77882,
            "longitude": -73.97834
        },
        "name": "Leyla",
        "address": {
            "address1": "108 W 74th St",
            "address2": None,
            "address3": None,
            "city": "New York",
            "zip_code": "10023",
            "country": "US",
            "state": "NY",
            "display_address": [
                "108 W 74th St",
                "New York, NY 10023"
            ]
        }
    },
    {
        "bid": "VMugGjWqmOfCXnYv_7aFWw",
        "rating": 4.0,
        "reviews": 346,
        "coordinates": {
            "latitude": 40.7355205142767,
            "longitude": -73.9979605809656
        },
        "name": "Kubeh",
        "address": {
            "address1": "464 Avenue Of The Americas",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10011",
            "country": "US",
            "state": "NY",
            "display_address": [
                "464 Avenue Of The Americas",
                "New York, NY 10011"
            ]
        }
    },
    {
        "bid": "M56MQwWsnP8BYgyLZ2WxVg",
        "rating": 4.5,
        "reviews": 42,
        "coordinates": {
            "latitude": 40.722090843379114,
            "longitude": -73.98799637363977
        },
        "name": "Sami & Susu",
        "address": {
            "address1": "190 Orchard St",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10002",
            "country": "US",
            "state": "NY",
            "display_address": [
                "190 Orchard St",
                "New York, NY 10002"
            ]
        }
    },
    {
        "bid": "JdXqygDw4yXQcy5lw9VI4A",
        "rating": 4.0,
        "reviews": 669,
        "coordinates": {
            "latitude": 40.71831756457833,
            "longitude": -73.95754161165478
        },
        "name": "Oasis",
        "address": {
            "address1": "168 Bedford Ave",
            "address2": None,
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11249",
            "country": "US",
            "state": "NY",
            "display_address": [
                "168 Bedford Ave",
                "Brooklyn, NY 11249"
            ]
        }
    },
    {
        "bid": "3-XEEsyymdOo4NjDL7bQxw",
        "rating": 4.5,
        "reviews": 44,
        "coordinates": {
            "latitude": 40.744444682981296,
            "longitude": -73.95368408642591
        },
        "name": "Sami's Kabab House",
        "address": {
            "address1": "47-38 Vernon Blvd",
            "address2": "",
            "address3": None,
            "city": "Long Island City",
            "zip_code": "11101",
            "country": "US",
            "state": "NY",
            "display_address": [
                "47-38 Vernon Blvd",
                "Long Island City, NY 11101"
            ]
        }
    },
    {
        "bid": "enT7NJ7tLMvUMCWQcsUonw",
        "rating": 4.0,
        "reviews": 677,
        "coordinates": {
            "latitude": 40.736412,
            "longitude": -74.00616
        },
        "name": "M\u00e9m\u00e9 Mediterranean",
        "address": {
            "address1": "581 Hudson St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10014",
            "country": "US",
            "state": "NY",
            "display_address": [
                "581 Hudson St",
                "New York, NY 10014"
            ]
        }
    },
    {
        "bid": "IBTfNZ5CLTWA-IwkhU0c2Q",
        "rating": 4.5,
        "reviews": 35,
        "coordinates": {
            "latitude": 40.718244,
            "longitude": -73.988109
        },
        "name": "Zerza Moroccan Kitchen",
        "address": {
            "address1": "88 Essex St",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10002",
            "country": "US",
            "state": "NY",
            "display_address": [
                "88 Essex St",
                "New York, NY 10002"
            ]
        }
    },
    {
        "bid": "apykLG7DTZ-7xnOcZGDZZA",
        "rating": 4.0,
        "reviews": 928,
        "coordinates": {
            "latitude": 40.731019969685164,
            "longitude": -73.98260448877211
        },
        "name": "Taverna Kyclades - East Village",
        "address": {
            "address1": "228 1st Ave",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10009",
            "country": "US",
            "state": "NY",
            "display_address": [
                "228 1st Ave",
                "New York, NY 10009"
            ]
        }
    },
    {
        "bid": "TAANt0fPbfHqVP5LyMBioA",
        "rating": 4.0,
        "reviews": 669,
        "coordinates": {
            "latitude": 40.76680229936593,
            "longitude": -73.986219866559
        },
        "name": "Kashkaval Garden",
        "address": {
            "address1": "852 9th Ave",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10019",
            "country": "US",
            "state": "NY",
            "display_address": [
                "852 9th Ave",
                "New York, NY 10019"
            ]
        }
    },
    {
        "bid": "CKDJ5EnccjRvvVF3csTn6Q",
        "rating": 4.0,
        "reviews": 98,
        "coordinates": {
            "latitude": 40.73769,
            "longitude": -74.00584
        },
        "name": "Balaboosta",
        "address": {
            "address1": "611 Hudson St",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10014",
            "country": "US",
            "state": "NY",
            "display_address": [
                "611 Hudson St",
                "New York, NY 10014"
            ]
        }
    },
    {
        "bid": "F2SwOvsP1_1JyDcCtnJzlQ",
        "rating": 5.0,
        "reviews": 158,
        "coordinates": {
            "latitude": 40.7739676833531,
            "longitude": -73.9597929340972
        },
        "name": "Tamam",
        "address": {
            "address1": "1108 Lexington Ave",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10075",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1108 Lexington Ave",
                "New York, NY 10075"
            ]
        }
    },
    {
        "bid": "J4qehrNgX-8fi9-TTiVuBA",
        "rating": 4.0,
        "reviews": 280,
        "coordinates": {
            "latitude": 40.706518,
            "longitude": -74.007133
        },
        "name": "Roti",
        "address": {
            "address1": "100 Maiden Ln",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10038",
            "country": "US",
            "state": "NY",
            "display_address": [
                "100 Maiden Ln",
                "New York, NY 10038"
            ]
        }
    },
    {
        "bid": "yVVbc0fYXw93ulhwA4kVUg",
        "rating": 4.5,
        "reviews": 27,
        "coordinates": {
            "latitude": 40.683812,
            "longitude": -73.967688
        },
        "name": "Efes Mediterranean Gyro & Grill",
        "address": {
            "address1": "887 Fulton St",
            "address2": None,
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11238",
            "country": "US",
            "state": "NY",
            "display_address": [
                "887 Fulton St",
                "Brooklyn, NY 11238"
            ]
        }
    },
    {
        "bid": "QQpQujXQGbZBK6BeAokzDA",
        "rating": 5.0,
        "reviews": 139,
        "coordinates": {
            "latitude": 40.714166,
            "longitude": -73.949612
        },
        "name": "Pomp & Circumstance Dining",
        "address": {
            "address1": "577 Lorimer St",
            "address2": "",
            "address3": None,
            "city": "Williamsburg",
            "zip_code": "11211",
            "country": "US",
            "state": "NY",
            "display_address": [
                "577 Lorimer St",
                "Williamsburg, NY 11211"
            ]
        }
    },
    {
        "bid": "AoZ_kDSEDKQvLISAfWkmCA",
        "rating": 4.0,
        "reviews": 321,
        "coordinates": {
            "latitude": 40.743718,
            "longitude": -73.979859
        },
        "name": "Hummus Kitchen",
        "address": {
            "address1": "444 3rd Ave",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10016",
            "country": "US",
            "state": "NY",
            "display_address": [
                "444 3rd Ave",
                "New York, NY 10016"
            ]
        }
    },
    {
        "bid": "4KzqwQus39gXgrwrDXAjWA",
        "rating": 4.5,
        "reviews": 247,
        "coordinates": {
            "latitude": 40.78754,
            "longitude": -73.9765199
        },
        "name": "El\u00e9a",
        "address": {
            "address1": "217 W 85th St",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10024",
            "country": "US",
            "state": "NY",
            "display_address": [
                "217 W 85th St",
                "New York, NY 10024"
            ]
        }
    },
    {
        "bid": "E9NMNWvV70HV5gB369N0EA",
        "rating": 4.5,
        "reviews": 668,
        "coordinates": {
            "latitude": 40.760313566070415,
            "longitude": -73.97302370552254
        },
        "name": "Nerai",
        "address": {
            "address1": "55 E 54th St",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10022",
            "country": "US",
            "state": "NY",
            "display_address": [
                "55 E 54th St",
                "New York, NY 10022"
            ]
        }
    },
    {
        "bid": "nGpC40fxoDQ-Ft0h-_gkVg",
        "rating": 4.0,
        "reviews": 666,
        "coordinates": {
            "latitude": 40.6869769801458,
            "longitude": -73.984394049936
        },
        "name": "Bedouin Tent",
        "address": {
            "address1": "405 Atlantic Ave",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11217",
            "country": "US",
            "state": "NY",
            "display_address": [
                "405 Atlantic Ave",
                "Brooklyn, NY 11217"
            ]
        }
    },
    {
        "bid": "5kh2c7cj3RrnoiSq479Jvg",
        "rating": 4.0,
        "reviews": 132,
        "coordinates": {
            "latitude": 40.74635,
            "longitude": -73.98494
        },
        "name": "Lamalo",
        "address": {
            "address1": "11 E 31st St",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10016",
            "country": "US",
            "state": "NY",
            "display_address": [
                "11 E 31st St",
                "New York, NY 10016"
            ]
        }
    },
    {
        "bid": "-jBC0Pc8a57x3_YdQfMtEg",
        "rating": 4.0,
        "reviews": 25,
        "coordinates": {
            "latitude": 40.73887278919948,
            "longitude": -73.9895743
        },
        "name": "Mezeh",
        "address": {
            "address1": "900 Broadway",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10003",
            "country": "US",
            "state": "NY",
            "display_address": [
                "900 Broadway",
                "New York, NY 10003"
            ]
        }
    },
    {
        "bid": "krZunArZFdp_2G1arwVuVw",
        "rating": 4.5,
        "reviews": 272,
        "coordinates": {
            "latitude": 40.759,
            "longitude": -73.962771
        },
        "name": "Au Za'atar",
        "address": {
            "address1": "1063 1st Ave",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10022",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1063 1st Ave",
                "New York, NY 10022"
            ]
        }
    },
    {
        "bid": "Ucg3flg-2tJAahEePIoigQ",
        "rating": 4.5,
        "reviews": 59,
        "coordinates": {
            "latitude": 40.71252,
            "longitude": -73.94899
        },
        "name": "Magdalene",
        "address": {
            "address1": "524 Lorimer St",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11211",
            "country": "US",
            "state": "NY",
            "display_address": [
                "524 Lorimer St",
                "Brooklyn, NY 11211"
            ]
        }
    },
    {
        "bid": "Me4TxTbPPQZQopW1wOGx5g",
        "rating": 4.0,
        "reviews": 2294,
        "coordinates": {
            "latitude": 40.7221323,
            "longitude": -73.9975402
        },
        "name": "Jack's Wife Freda",
        "address": {
            "address1": "226 Lafayette St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10012",
            "country": "US",
            "state": "NY",
            "display_address": [
                "226 Lafayette St",
                "New York, NY 10012"
            ]
        }
    },
    {
        "bid": "6ii5cphr65vt6zrP9N5RVg",
        "rating": 5.0,
        "reviews": 125,
        "coordinates": {
            "latitude": 40.764614,
            "longitude": -73.95875
        },
        "name": "Chamoun\u2019s Way",
        "address": {
            "address1": "1237 1st Ave",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10065",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1237 1st Ave",
                "New York, NY 10065"
            ]
        }
    },
    {
        "bid": "m9IqF_ZaF-IjdO6cJgESrQ",
        "rating": 5.0,
        "reviews": 1,
        "coordinates": {
            "latitude": 40.76174381046903,
            "longitude": -73.94957142883567
        },
        "name": "ME Mediterranean Eatery",
        "address": {
            "address1": "548 Main St",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10044",
            "country": "US",
            "state": "NY",
            "display_address": [
                "548 Main St",
                "New York, NY 10044"
            ]
        }
    },
    {
        "bid": "FvCslLyo0SlDKI52bEDekQ",
        "rating": 4.5,
        "reviews": 371,
        "coordinates": {
            "latitude": 40.7093241238432,
            "longitude": -74.00800699314742
        },
        "name": "Nish Nush",
        "address": {
            "address1": "41 John St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10038",
            "country": "US",
            "state": "NY",
            "display_address": [
                "41 John St",
                "New York, NY 10038"
            ]
        }
    },
    {
        "bid": "q1uIqB8PvyCCX8TajaRYBg",
        "rating": 4.0,
        "reviews": 1424,
        "coordinates": {
            "latitude": 40.73240001181511,
            "longitude": -74.00532068435112
        },
        "name": "Little Owl",
        "address": {
            "address1": "90 Bedford St",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10014",
            "country": "US",
            "state": "NY",
            "display_address": [
                "90 Bedford St",
                "New York, NY 10014"
            ]
        }
    },
    {
        "bid": "3-veNnRYcRfQ-OmnXrmfFA",
        "rating": 4.5,
        "reviews": 311,
        "coordinates": {
            "latitude": 40.7244699,
            "longitude": -74.0039
        },
        "name": "Ba'al Cafe & Falafel",
        "address": {
            "address1": "71 Sullivan St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10012",
            "country": "US",
            "state": "NY",
            "display_address": [
                "71 Sullivan St",
                "New York, NY 10012"
            ]
        }
    },
    {
        "bid": "OOAFPiztVlStZIUDwcixqA",
        "rating": 4.0,
        "reviews": 97,
        "coordinates": {
            "latitude": 40.75352,
            "longitude": -74.00012
        },
        "name": "Miznon",
        "address": {
            "address1": "20 Hudson Yards",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10001",
            "country": "US",
            "state": "NY",
            "display_address": [
                "20 Hudson Yards",
                "New York, NY 10001"
            ]
        }
    },
    {
        "bid": "ikkIneKupd7sClxu9nvdzQ",
        "rating": 4.5,
        "reviews": 168,
        "coordinates": {
            "latitude": 40.73975906936846,
            "longitude": -73.9959804
        },
        "name": "Shiraz Kitchen & Wine Bar",
        "address": {
            "address1": "111 W 17th St",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10011",
            "country": "US",
            "state": "NY",
            "display_address": [
                "111 W 17th St",
                "New York, NY 10011"
            ]
        }
    },
    {
        "bid": "sri-S6YRQ32XsvdO-EB3IA",
        "rating": 4.5,
        "reviews": 30,
        "coordinates": {
            "latitude": 40.84905,
            "longitude": -73.85498
        },
        "name": "Nana's Kitchen",
        "address": {
            "address1": "1809 Hone Ave",
            "address2": "",
            "address3": "",
            "city": "Bronx",
            "zip_code": "10461",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1809 Hone Ave",
                "Bronx, NY 10461"
            ]
        }
    },
    {
        "bid": "mCxVAHNCDmWQw7ONts8PSw",
        "rating": 4.5,
        "reviews": 293,
        "coordinates": {
            "latitude": 40.903654,
            "longitude": -73.789276
        },
        "name": "Dubrovnik Restaurant",
        "address": {
            "address1": "721 Main St",
            "address2": "",
            "address3": "",
            "city": "New Rochelle",
            "zip_code": "10801",
            "country": "US",
            "state": "NY",
            "display_address": [
                "721 Main St",
                "New Rochelle, NY 10801"
            ]
        }
    },
    {
        "bid": "6gDUVNZo0E9lxO2DkAhHOQ",
        "rating": 4.5,
        "reviews": 522,
        "coordinates": {
            "latitude": 40.72403160851802,
            "longitude": -74.01044800203925
        },
        "name": "The Greek",
        "address": {
            "address1": "452 Washington St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10013",
            "country": "US",
            "state": "NY",
            "display_address": [
                "452 Washington St",
                "New York, NY 10013"
            ]
        }
    },
    {
        "bid": "mXLrVoEi80WZaZ3agBP5Jw",
        "rating": 4.0,
        "reviews": 648,
        "coordinates": {
            "latitude": 40.68803,
            "longitude": -73.98671
        },
        "name": "Bijan's",
        "address": {
            "address1": "81 Hoyt St",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11211",
            "country": "US",
            "state": "NY",
            "display_address": [
                "81 Hoyt St",
                "Brooklyn, NY 11211"
            ]
        }
    },
    {
        "bid": "MIHDANEJyqStu3CrbDHQcA",
        "rating": 4.5,
        "reviews": 201,
        "coordinates": {
            "latitude": 40.52332,
            "longitude": -74.23447
        },
        "name": "Laila",
        "address": {
            "address1": "45 Page Ave",
            "address2": "Ste C",
            "address3": None,
            "city": "Staten Island",
            "zip_code": "10309",
            "country": "US",
            "state": "NY",
            "display_address": [
                "45 Page Ave",
                "Ste C",
                "Staten Island, NY 10309"
            ]
        }
    },
    {
        "bid": "pAqrkEtry8PFVl-_PIksnw",
        "rating": 4.5,
        "reviews": 17,
        "coordinates": {
            "latitude": 40.74634820303653,
            "longitude": -73.99744489999999
        },
        "name": "Anixi",
        "address": {
            "address1": "290 8th Ave New York 10001-4801",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10001",
            "country": "US",
            "state": "NY",
            "display_address": [
                "290 8th Ave New York 10001-4801",
                "New York, NY 10001"
            ]
        }
    },
    {
        "bid": "7CM15wd5d8WC_pHR674YXA",
        "rating": 4.0,
        "reviews": 1102,
        "coordinates": {
            "latitude": 40.7763650431587,
            "longitude": -73.9529693360589
        },
        "name": "Hummus Kitchen",
        "address": {
            "address1": "1613 2nd Ave",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10028",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1613 2nd Ave",
                "New York, NY 10028"
            ]
        }
    },
    {
        "bid": "fuSjpC1qw3fLih5SYUoOvg",
        "rating": 4.0,
        "reviews": 44,
        "coordinates": {
            "latitude": 40.71707,
            "longitude": -73.96322
        },
        "name": "Jack's Wife Freda",
        "address": {
            "address1": "258 Wythe Ave",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "11249",
            "country": "US",
            "state": "NY",
            "display_address": [
                "258 Wythe Ave",
                "New York, NY 11249"
            ]
        }
    },
    {
        "bid": "texbRCTWEMkK3aoLMIAGhA",
        "rating": 4.5,
        "reviews": 220,
        "coordinates": {
            "latitude": 40.706071,
            "longitude": -73.922414
        },
        "name": "Queen",
        "address": {
            "address1": "247 Starr St",
            "address2": None,
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11237",
            "country": "US",
            "state": "NY",
            "display_address": [
                "247 Starr St",
                "Brooklyn, NY 11237"
            ]
        }
    },
    {
        "bid": "4XOoX-yxH4npdU47WWvMNA",
        "rating": 4.5,
        "reviews": 131,
        "coordinates": {
            "latitude": 40.586377,
            "longitude": -73.816072
        },
        "name": "Kimo's",
        "address": {
            "address1": "9216 Rockaway Beach Blvd",
            "address2": "",
            "address3": None,
            "city": "Rockaway Beach",
            "zip_code": "11693",
            "country": "US",
            "state": "NY",
            "display_address": [
                "9216 Rockaway Beach Blvd",
                "Rockaway Beach, NY 11693"
            ]
        }
    },
    {
        "bid": "zvy4KOv2afqUSGin54_xxg",
        "rating": 4.5,
        "reviews": 262,
        "coordinates": {
            "latitude": 40.6870474589747,
            "longitude": -73.9938177876969
        },
        "name": "Darna Falafel",
        "address": {
            "address1": "200 Court St",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11201",
            "country": "US",
            "state": "NY",
            "display_address": [
                "200 Court St",
                "Brooklyn, NY 11201"
            ]
        }
    },
    {
        "bid": "i8UeABJuw3iK-QbGJAiJaQ",
        "rating": 3.5,
        "reviews": 35,
        "coordinates": {
            "latitude": 40.69126,
            "longitude": -73.99177
        },
        "name": "AGYRO",
        "address": {
            "address1": "86 Court St",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11201",
            "country": "US",
            "state": "NY",
            "display_address": [
                "86 Court St",
                "Brooklyn, NY 11201"
            ]
        }
    },
    {
        "bid": "6eVNHrnp67ZniJYLik1qig",
        "rating": 4.0,
        "reviews": 233,
        "coordinates": {
            "latitude": 40.75646,
            "longitude": -73.9662
        },
        "name": "Yara",
        "address": {
            "address1": "319 E 53rd St",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10022",
            "country": "US",
            "state": "NY",
            "display_address": [
                "319 E 53rd St",
                "New York, NY 10022"
            ]
        }
    },
    {
        "bid": "6KcS6hc2j4kJi2XTGxC1eg",
        "rating": 4.0,
        "reviews": 472,
        "coordinates": {
            "latitude": 40.78935,
            "longitude": -73.97411
        },
        "name": "Bodrum",
        "address": {
            "address1": "584 Amsterdam Ave",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10024",
            "country": "US",
            "state": "NY",
            "display_address": [
                "584 Amsterdam Ave",
                "New York, NY 10024"
            ]
        }
    },
    {
        "bid": "oY-tooKEm8F-6Il1JOQzKg",
        "rating": 4.0,
        "reviews": 767,
        "coordinates": {
            "latitude": 40.76465,
            "longitude": -73.98029
        },
        "name": "Souvlaki GR",
        "address": {
            "address1": "162 W 56th St",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10019",
            "country": "US",
            "state": "NY",
            "display_address": [
                "162 W 56th St",
                "New York, NY 10019"
            ]
        }
    },
    {
        "bid": "hKDCY-ZXcfPy4Vp8BfWnhw",
        "rating": 4.5,
        "reviews": 106,
        "coordinates": {
            "latitude": 40.763478,
            "longitude": -73.967816
        },
        "name": "Lezzet Mediterranean Turkish Restaurant",
        "address": {
            "address1": "132 East 61st St",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10065",
            "country": "US",
            "state": "NY",
            "display_address": [
                "132 East 61st St",
                "New York, NY 10065"
            ]
        }
    },
    {
        "bid": "xTWpl9DgIkkr5B8h8_xUpA",
        "rating": 4.5,
        "reviews": 445,
        "coordinates": {
            "latitude": 40.7842696,
            "longitude": -73.9734941
        },
        "name": "Lokal 83 Mediterranean Kitchen",
        "address": {
            "address1": "473 Columbus Ave",
            "address2": "83rd street",
            "address3": None,
            "city": "New York",
            "zip_code": "10024",
            "country": "US",
            "state": "NY",
            "display_address": [
                "473 Columbus Ave",
                "83rd street",
                "New York, NY 10024"
            ]
        }
    },
    {
        "bid": "HyQs1XjmI_x20R_rEEcFqA",
        "rating": 4.5,
        "reviews": 49,
        "coordinates": {
            "latitude": 40.67551,
            "longitude": -73.9813459
        },
        "name": "Simply Greek",
        "address": {
            "address1": "242 5th Ave",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11215",
            "country": "US",
            "state": "NY",
            "display_address": [
                "242 5th Ave",
                "Brooklyn, NY 11215"
            ]
        }
    },
    {
        "bid": "KPGZ6zr6lUX9YROjGcUbtw",
        "rating": 4.5,
        "reviews": 186,
        "coordinates": {
            "latitude": 40.68474,
            "longitude": -73.92916
        },
        "name": "Peri Peri Grill House",
        "address": {
            "address1": "235 Malcolm X Blvd",
            "address2": None,
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11233",
            "country": "US",
            "state": "NY",
            "display_address": [
                "235 Malcolm X Blvd",
                "Brooklyn, NY 11233"
            ]
        }
    },
    {
        "bid": "YfWBNXjV8OVOCxLfAtp6XA",
        "rating": 4.5,
        "reviews": 160,
        "coordinates": {
            "latitude": 40.74845,
            "longitude": -74.0278699
        },
        "name": "Seven Valleys",
        "address": {
            "address1": "936 Washington St",
            "address2": "",
            "address3": None,
            "city": "Hoboken",
            "zip_code": "07030",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "936 Washington St",
                "Hoboken, NJ 07030"
            ]
        }
    },
    {
        "bid": "XEugUtbw4rRmGr9S1XA-aQ",
        "rating": 4.0,
        "reviews": 2009,
        "coordinates": {
            "latitude": 40.7345163811398,
            "longitude": -73.9983369619683
        },
        "name": "Alta",
        "address": {
            "address1": "64 W 10th St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10011",
            "country": "US",
            "state": "NY",
            "display_address": [
                "64 W 10th St",
                "New York, NY 10011"
            ]
        }
    },
    {
        "bid": "bDx0oXgxO0Cy8uH_NbsE9w",
        "rating": 4.0,
        "reviews": 402,
        "coordinates": {
            "latitude": 40.7323545516408,
            "longitude": -74.0052938207627
        },
        "name": "Moustache",
        "address": {
            "address1": "90 Bedford St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10014",
            "country": "US",
            "state": "NY",
            "display_address": [
                "90 Bedford St",
                "New York, NY 10014"
            ]
        }
    },
    {
        "bid": "hQB3SrB-AZuRYNpgZ_NIJw",
        "rating": 4.0,
        "reviews": 107,
        "coordinates": {
            "latitude": 40.584489666,
            "longitude": -74.093878166
        },
        "name": "Grand Sahara Mediterranean Grill",
        "address": {
            "address1": "1828 Hylan Blvd",
            "address2": None,
            "address3": "",
            "city": "Staten Island",
            "zip_code": "10305",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1828 Hylan Blvd",
                "Staten Island, NY 10305"
            ]
        }
    },
    {
        "bid": "03icxNONL86QOeZQLsyrnA",
        "rating": 4.5,
        "reviews": 45,
        "coordinates": {
            "latitude": 40.7057062,
            "longitude": -73.932148
        },
        "name": "Semkeh",
        "address": {
            "address1": "53 Morgan Ave",
            "address2": None,
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11237",
            "country": "US",
            "state": "NY",
            "display_address": [
                "53 Morgan Ave",
                "Brooklyn, NY 11237"
            ]
        }
    },
    {
        "bid": "jwssDDRcC88xejYw0ZyFkw",
        "rating": 4.5,
        "reviews": 224,
        "coordinates": {
            "latitude": 40.6241292388192,
            "longitude": -74.0309519868987
        },
        "name": "Ayat NYC",
        "address": {
            "address1": "8504 3rd Ave",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11209",
            "country": "US",
            "state": "NY",
            "display_address": [
                "8504 3rd Ave",
                "Brooklyn, NY 11209"
            ]
        }
    },
    {
        "bid": "IavC9CRFtosOC7UN5ndXpg",
        "rating": 3.5,
        "reviews": 305,
        "coordinates": {
            "latitude": 40.719022672809004,
            "longitude": -73.94928253665668
        },
        "name": "Fandi Mata",
        "address": {
            "address1": "74 Bayard St",
            "address2": None,
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11222",
            "country": "US",
            "state": "NY",
            "display_address": [
                "74 Bayard St",
                "Brooklyn, NY 11222"
            ]
        }
    },
    {
        "bid": "7ZecxKox2SiVtsNDWphJZQ",
        "rating": 4.0,
        "reviews": 510,
        "coordinates": {
            "latitude": 40.7593809598193,
            "longitude": -73.9778140767212
        },
        "name": "Limani",
        "address": {
            "address1": "45 Rockerfeller Plz",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10111",
            "country": "US",
            "state": "NY",
            "display_address": [
                "45 Rockerfeller Plz",
                "New York, NY 10111"
            ]
        }
    },
    {
        "bid": "lQ8qDNaTPnewJt6xwG__gQ",
        "rating": 4.5,
        "reviews": 61,
        "coordinates": {
            "latitude": 40.679822105618534,
            "longitude": -73.96511882543564
        },
        "name": "Leland Eating and Drinking House ",
        "address": {
            "address1": "755 Dean St",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11238",
            "country": "US",
            "state": "NY",
            "display_address": [
                "755 Dean St",
                "Brooklyn, NY 11238"
            ]
        }
    },
    {
        "bid": "kp5HpNxyJQGY13VDN-Yq9Q",
        "rating": 4.0,
        "reviews": 127,
        "coordinates": {
            "latitude": 40.74524,
            "longitude": -74.00202
        },
        "name": "Qanoon",
        "address": {
            "address1": "180 9th Ave",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10011",
            "country": "US",
            "state": "NY",
            "display_address": [
                "180 9th Ave",
                "New York, NY 10011"
            ]
        }
    },
    {
        "bid": "Ey45ZiAN1TSVmvfM6DVZqA",
        "rating": 4.0,
        "reviews": 512,
        "coordinates": {
            "latitude": 40.76984,
            "longitude": -73.958015
        },
        "name": "Persepolis",
        "address": {
            "address1": "1407 2nd Ave",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10021",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1407 2nd Ave",
                "New York, NY 10021"
            ]
        }
    },
    {
        "bid": "4wDWxcGMJEgriP-6ObJsqg",
        "rating": 5.0,
        "reviews": 174,
        "coordinates": {
            "latitude": 40.727861,
            "longitude": -73.979339
        },
        "name": "Jose Luis Mediterranean Cuisine",
        "address": {
            "address1": "186 Ave B",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10009",
            "country": "US",
            "state": "NY",
            "display_address": [
                "186 Ave B",
                "New York, NY 10009"
            ]
        }
    },
    {
        "bid": "EuWNk5SJB7wADVHoCtxAqg",
        "rating": 4.0,
        "reviews": 114,
        "coordinates": {
            "latitude": 40.780201643038154,
            "longitude": -73.98087029999999
        },
        "name": "Miriam",
        "address": {
            "address1": "300 Amsterdam Ave",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10023",
            "country": "US",
            "state": "NY",
            "display_address": [
                "300 Amsterdam Ave",
                "New York, NY 10023"
            ]
        }
    },
    {
        "bid": "szrkleW0KeKcoKqnGa2Tew",
        "rating": 4.0,
        "reviews": 362,
        "coordinates": {
            "latitude": 40.678733,
            "longitude": -73.968803
        },
        "name": "Zaytoons",
        "address": {
            "address1": "594 Vanderbilt Ave",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11238",
            "country": "US",
            "state": "NY",
            "display_address": [
                "594 Vanderbilt Ave",
                "Brooklyn, NY 11238"
            ]
        }
    },
    {
        "bid": "M8xnlKQOh0tl58LJCnPUVA",
        "rating": 4.0,
        "reviews": 401,
        "coordinates": {
            "latitude": 40.7618025365842,
            "longitude": -73.9605525538847
        },
        "name": "Ravagh Persian Grill",
        "address": {
            "address1": "1135 1st Ave",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10065",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1135 1st Ave",
                "New York, NY 10065"
            ]
        }
    },
    {
        "bid": "60WfM2010WrH_LnegNckCQ",
        "rating": 4.5,
        "reviews": 47,
        "coordinates": {
            "latitude": 40.76731744427289,
            "longitude": -73.9119392
        },
        "name": "Dar Yemma",
        "address": {
            "address1": "25-21 Steinway St",
            "address2": None,
            "address3": "",
            "city": "Astoria",
            "zip_code": "11103",
            "country": "US",
            "state": "NY",
            "display_address": [
                "25-21 Steinway St",
                "Astoria, NY 11103"
            ]
        }
    },
    {
        "bid": "bt3U7PYbC1nqpXN0YExZ2Q",
        "rating": 5.0,
        "reviews": 30,
        "coordinates": {
            "latitude": 40.542635145493875,
            "longitude": -74.14541182278644
        },
        "name": "La Petite Corniche",
        "address": {
            "address1": "3972 Hylan Blvd",
            "address2": "",
            "address3": None,
            "city": "Staten Island",
            "zip_code": "10308",
            "country": "US",
            "state": "NY",
            "display_address": [
                "3972 Hylan Blvd",
                "Staten Island, NY 10308"
            ]
        }
    },
    {
        "bid": "38Lids3hUiaQryPzQSN3fw",
        "rating": 4.0,
        "reviews": 64,
        "coordinates": {
            "latitude": 40.67931,
            "longitude": -74.10486
        },
        "name": "Mediterraneo Restaurant",
        "address": {
            "address1": "932 Broadway",
            "address2": "",
            "address3": "",
            "city": "Bayonne",
            "zip_code": "07002",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "932 Broadway",
                "Bayonne, NJ 07002"
            ]
        }
    },
    {
        "bid": "ttn8OS7X986fYIuEEXG09g",
        "rating": 4.5,
        "reviews": 16,
        "coordinates": {
            "latitude": 40.75213,
            "longitude": -73.98383
        },
        "name": "Harta",
        "address": {
            "address1": "30 W 39th St",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10018",
            "country": "US",
            "state": "NY",
            "display_address": [
                "30 W 39th St",
                "New York, NY 10018"
            ]
        }
    },
    {
        "bid": "j0n_poMVZnODYOFviLbh0Q",
        "rating": 4.5,
        "reviews": 1572,
        "coordinates": {
            "latitude": 40.736002376347,
            "longitude": -74.0019588366439
        },
        "name": "ta\u00efm mediterranean kitchen - West Village",
        "address": {
            "address1": "222 Waverly Pl",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10014",
            "country": "US",
            "state": "NY",
            "display_address": [
                "222 Waverly Pl",
                "New York, NY 10014"
            ]
        }
    },
    {
        "bid": "e6ic-qLMcaQLrAnHn2jgTw",
        "rating": 4.0,
        "reviews": 179,
        "coordinates": {
            "latitude": 40.72347420863732,
            "longitude": -73.9963118
        },
        "name": "La Pecora Bianca",
        "address": {
            "address1": "54 Prince St",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10012",
            "country": "US",
            "state": "NY",
            "display_address": [
                "54 Prince St",
                "New York, NY 10012"
            ]
        }
    },
    {
        "bid": "WIe7Qi3uOoMKU2ZbHfTGew",
        "rating": 4.5,
        "reviews": 235,
        "coordinates": {
            "latitude": 40.68495,
            "longitude": -74.00289
        },
        "name": "Mazzat",
        "address": {
            "address1": "208 Columbia St",
            "address2": None,
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11231",
            "country": "US",
            "state": "NY",
            "display_address": [
                "208 Columbia St",
                "Brooklyn, NY 11231"
            ]
        }
    },
    {
        "bid": "HrdIdeDZBTUdyEdSTPG1zg",
        "rating": 4.0,
        "reviews": 958,
        "coordinates": {
            "latitude": 40.729826,
            "longitude": -74.003516
        },
        "name": "Jack's Wife Freda",
        "address": {
            "address1": "50 Carmine St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10014",
            "country": "US",
            "state": "NY",
            "display_address": [
                "50 Carmine St",
                "New York, NY 10014"
            ]
        }
    },
    {
        "bid": "OqaVCimTW9tkhSII7lYUsQ",
        "rating": 5.0,
        "reviews": 175,
        "coordinates": {
            "latitude": 40.886774,
            "longitude": -74.041142
        },
        "name": "El Turco Grill",
        "address": {
            "address1": "270 Main St",
            "address2": None,
            "address3": "",
            "city": "Hackensack",
            "zip_code": "07601",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "270 Main St",
                "Hackensack, NJ 07601"
            ]
        }
    },
    {
        "bid": "6fLuR2N-4rDf3ZTvPGnsxA",
        "rating": 4.5,
        "reviews": 18,
        "coordinates": {
            "latitude": 40.733470744912104,
            "longitude": -73.99302569999999
        },
        "name": "NAYA - Union Square",
        "address": {
            "address1": "83 University Pl",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10003",
            "country": "US",
            "state": "NY",
            "display_address": [
                "83 University Pl",
                "New York, NY 10003"
            ]
        }
    },
    {
        "bid": "Xcxare_6mb-PKSWYfIK6rg",
        "rating": 4.5,
        "reviews": 47,
        "coordinates": {
            "latitude": 40.74447,
            "longitude": -73.95316
        },
        "name": "Safir Mediterranean",
        "address": {
            "address1": "47-31 Vernon Blvd",
            "address2": None,
            "address3": "",
            "city": "Long Island City",
            "zip_code": "11101",
            "country": "US",
            "state": "NY",
            "display_address": [
                "47-31 Vernon Blvd",
                "Long Island City, NY 11101"
            ]
        }
    },
    {
        "bid": "AuzDP_4AfUONIUc2wK6UiQ",
        "rating": 4.5,
        "reviews": 77,
        "coordinates": {
            "latitude": 40.825267,
            "longitude": -73.983319
        },
        "name": "Meyhane",
        "address": {
            "address1": "671 Palisade Ave",
            "address2": None,
            "address3": "",
            "city": "Cliffside Park",
            "zip_code": "07010",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "671 Palisade Ave",
                "Cliffside Park, NJ 07010"
            ]
        }
    },
    {
        "bid": "haK6aVs_oIUqwOn0LVZlRA",
        "rating": 4.5,
        "reviews": 205,
        "coordinates": {
            "latitude": 40.7643988,
            "longitude": -73.9855199
        },
        "name": "Turkuaz Restaurant",
        "address": {
            "address1": "310 West 53rd St",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10019",
            "country": "US",
            "state": "NY",
            "display_address": [
                "310 West 53rd St",
                "New York, NY 10019"
            ]
        }
    },
    {
        "bid": "HHUMUAKDiJqrKSf2Qaxmlw",
        "rating": 4.5,
        "reviews": 253,
        "coordinates": {
            "latitude": 40.673165,
            "longitude": -73.983292
        },
        "name": "Tava Turkish Mediterranean",
        "address": {
            "address1": "318 5th Ave",
            "address2": None,
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11215",
            "country": "US",
            "state": "NY",
            "display_address": [
                "318 5th Ave",
                "Brooklyn, NY 11215"
            ]
        }
    },
    {
        "bid": "Bn1mZhb501Tvf7_-Pfi9_g",
        "rating": 4.0,
        "reviews": 249,
        "coordinates": {
            "latitude": 40.78349,
            "longitude": -73.95098
        },
        "name": "Korali Estiatorio",
        "address": {
            "address1": "1662 3rd Ave",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10128",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1662 3rd Ave",
                "New York, NY 10128"
            ]
        }
    },
    {
        "bid": "Qx01ny6b5PIBJlvI5mhjCA",
        "rating": 4.0,
        "reviews": 304,
        "coordinates": {
            "latitude": 40.72164,
            "longitude": -73.99722
        },
        "name": "19 Cleveland",
        "address": {
            "address1": "19 Cleveland Pl",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10012",
            "country": "US",
            "state": "NY",
            "display_address": [
                "19 Cleveland Pl",
                "New York, NY 10012"
            ]
        }
    },
    {
        "bid": "O9LKN5kk17lQWb7mMuiBzw",
        "rating": 4.0,
        "reviews": 91,
        "coordinates": {
            "latitude": 40.7803,
            "longitude": -73.95312
        },
        "name": "yasouvlaki",
        "address": {
            "address1": "1568 3rd Ave",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10128",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1568 3rd Ave",
                "New York, NY 10128"
            ]
        }
    },
    {
        "bid": "GyFsnBMadm3DzOyWTHr7yw",
        "rating": 3.5,
        "reviews": 34,
        "coordinates": {
            "latitude": 40.7592511,
            "longitude": -73.970623
        },
        "name": "Mama Ganoush",
        "address": {
            "address1": "638 Lexington Ave",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10022",
            "country": "US",
            "state": "NY",
            "display_address": [
                "638 Lexington Ave",
                "New York, NY 10022"
            ]
        }
    },
    {
        "bid": "MDjmE0hwZe0qLFaesCrnKQ",
        "rating": 4.5,
        "reviews": 14,
        "coordinates": {
            "latitude": 40.71755,
            "longitude": -74.01013
        },
        "name": "Argo Tribeca",
        "address": {
            "address1": "181 Duane St",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10013",
            "country": "US",
            "state": "NY",
            "display_address": [
                "181 Duane St",
                "New York, NY 10013"
            ]
        }
    },
    {
        "bid": "xnuQRQGM1axGxlLphVxY2g",
        "rating": 4.5,
        "reviews": 366,
        "coordinates": {
            "latitude": 40.8140461,
            "longitude": -74.2202284
        },
        "name": "Zeugma Mediterranean Grill",
        "address": {
            "address1": "44 South Park St",
            "address2": "",
            "address3": None,
            "city": "Montclair",
            "zip_code": "07042",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "44 South Park St",
                "Montclair, NJ 07042"
            ]
        }
    },
    {
        "bid": "njKwUg6oYDEEtLuunTmgbg",
        "rating": 4.0,
        "reviews": 270,
        "coordinates": {
            "latitude": 40.69854,
            "longitude": -73.99263
        },
        "name": "Heights Falafel",
        "address": {
            "address1": "78 Henry St",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11201",
            "country": "US",
            "state": "NY",
            "display_address": [
                "78 Henry St",
                "Brooklyn, NY 11201"
            ]
        }
    },
    {
        "bid": "MxE0X8ayNGii9zA2i2ZERA",
        "rating": 4.0,
        "reviews": 368,
        "coordinates": {
            "latitude": 40.731033,
            "longitude": -74.004814
        },
        "name": "Snack Taverna",
        "address": {
            "address1": "63 Bedford St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10014",
            "country": "US",
            "state": "NY",
            "display_address": [
                "63 Bedford St",
                "New York, NY 10014"
            ]
        }
    },
    {
        "bid": "ZoVVcwwbCxIhEmstLWrRvw",
        "rating": 4.0,
        "reviews": 204,
        "coordinates": {
            "latitude": 40.7146406,
            "longitude": -74.00677421396293
        },
        "name": "The Hummus & Pita",
        "address": {
            "address1": "79 Chambers St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10007",
            "country": "US",
            "state": "NY",
            "display_address": [
                "79 Chambers St",
                "New York, NY 10007"
            ]
        }
    },
    {
        "bid": "m4CFfE1_u5rwVgb45ZqRpA",
        "rating": 4.0,
        "reviews": 383,
        "coordinates": {
            "latitude": 40.6798617,
            "longitude": -73.973984
        },
        "name": "Sofreh",
        "address": {
            "address1": "75 St Marks Ave",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11217",
            "country": "US",
            "state": "NY",
            "display_address": [
                "75 St Marks Ave",
                "Brooklyn, NY 11217"
            ]
        }
    },
    {
        "bid": "Ti-957LNURM0Gy2CXIbQOw",
        "rating": 4.0,
        "reviews": 949,
        "coordinates": {
            "latitude": 40.76427,
            "longitude": -73.98797
        },
        "name": "Hummus Kitchen",
        "address": {
            "address1": "768 9th Ave",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10019",
            "country": "US",
            "state": "NY",
            "display_address": [
                "768 9th Ave",
                "New York, NY 10019"
            ]
        }
    },
    {
        "bid": "HmcI84HYy2ZCC2FGbgl7mw",
        "rating": 4.5,
        "reviews": 6,
        "coordinates": {
            "latitude": 40.8303116,
            "longitude": -74.0933119
        },
        "name": "Mediterranean Bowl",
        "address": {
            "address1": "91 NJ-17 S Liberty Commons",
            "address2": "",
            "address3": None,
            "city": "East Rutherford",
            "zip_code": "07073",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "91 NJ-17 S Liberty Commons",
                "East Rutherford, NJ 07073"
            ]
        }
    },
    {
        "bid": "hXqrA_Z3jZ8Q1O6ZehWSwQ",
        "rating": 4.5,
        "reviews": 519,
        "coordinates": {
            "latitude": 40.75842829623015,
            "longitude": -73.932968
        },
        "name": "Sami's Kabab House",
        "address": {
            "address1": "35-57 Crescent St",
            "address2": "",
            "address3": None,
            "city": "Astoria",
            "zip_code": "11106",
            "country": "US",
            "state": "NY",
            "display_address": [
                "35-57 Crescent St",
                "Astoria, NY 11106"
            ]
        }
    },
    {
        "bid": "CviK6c6BkxN_TTZahdvwyA",
        "rating": 4.5,
        "reviews": 221,
        "coordinates": {
            "latitude": 40.6980763644669,
            "longitude": -73.9245712108767
        },
        "name": "Zatar",
        "address": {
            "address1": "1294 Myrtle Ave",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11221",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1294 Myrtle Ave",
                "Brooklyn, NY 11221"
            ]
        }
    },
    {
        "bid": "F89nDDlYZ7wbRe8EpLCqBw",
        "rating": 4.0,
        "reviews": 999,
        "coordinates": {
            "latitude": 40.755048569901554,
            "longitude": -73.97243859999999
        },
        "name": "Avra 48th Street",
        "address": {
            "address1": "141 E 48th St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10017",
            "country": "US",
            "state": "NY",
            "display_address": [
                "141 E 48th St",
                "New York, NY 10017"
            ]
        }
    },
    {
        "bid": "R5AUhqPpHBwddjb57pHg7g",
        "rating": 4.0,
        "reviews": 23,
        "coordinates": {
            "latitude": 40.75978130438044,
            "longitude": -74.16190519167289
        },
        "name": "Torshi Mediterranean Grill",
        "address": {
            "address1": "175 Passaic Ave",
            "address2": "",
            "address3": None,
            "city": "Kearny",
            "zip_code": "07032",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "175 Passaic Ave",
                "Kearny, NJ 07032"
            ]
        }
    },
    {
        "bid": "wA_KKu3X36JcaUPgFjyIHg",
        "rating": 4.0,
        "reviews": 420,
        "coordinates": {
            "latitude": 40.73773690064076,
            "longitude": -73.95617606103727
        },
        "name": "Glasserie",
        "address": {
            "address1": "95 Commercial St",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11222",
            "country": "US",
            "state": "NY",
            "display_address": [
                "95 Commercial St",
                "Brooklyn, NY 11222"
            ]
        }
    },
    {
        "bid": "FcSblhYtEG3VzarbZefwrw",
        "rating": 4.5,
        "reviews": 189,
        "coordinates": {
            "latitude": 40.74508,
            "longitude": -73.99843
        },
        "name": "FL\u00c9 FL\u00c9 Grill",
        "address": {
            "address1": "254 8th Ave",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10011",
            "country": "US",
            "state": "NY",
            "display_address": [
                "254 8th Ave",
                "New York, NY 10011"
            ]
        }
    },
    {
        "bid": "cuUmPDEY-1KXzShGdpsqag",
        "rating": 4.0,
        "reviews": 602,
        "coordinates": {
            "latitude": 40.74189,
            "longitude": -73.98136
        },
        "name": "Turkish Kitchen",
        "address": {
            "address1": "386 3rd Ave",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10016",
            "country": "US",
            "state": "NY",
            "display_address": [
                "386 3rd Ave",
                "New York, NY 10016"
            ]
        }
    },
    {
        "bid": "kpxXi23lUQkeJQH-2BtzDw",
        "rating": 4.5,
        "reviews": 305,
        "coordinates": {
            "latitude": 40.7185628184474,
            "longitude": -73.9571302649415
        },
        "name": "Qahwah House",
        "address": {
            "address1": "162 Bedford Ave",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11249",
            "country": "US",
            "state": "NY",
            "display_address": [
                "162 Bedford Ave",
                "Brooklyn, NY 11249"
            ]
        }
    },
    {
        "bid": "BgXmo84dt_AoLlvZ22pe8g",
        "rating": 4.0,
        "reviews": 315,
        "coordinates": {
            "latitude": 40.6865844726562,
            "longitude": -73.9756927490234
        },
        "name": "Deniz Turkish Mediterranean Cuisine",
        "address": {
            "address1": "662 Fulton St",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11217",
            "country": "US",
            "state": "NY",
            "display_address": [
                "662 Fulton St",
                "Brooklyn, NY 11217"
            ]
        }
    },
    {
        "bid": "5PnLSeIC0ZR2tQNiRkj0vw",
        "rating": 4.0,
        "reviews": 10,
        "coordinates": {
            "latitude": 40.58125,
            "longitude": -74.16608
        },
        "name": "Taheni Mediterranean Grill",
        "address": {
            "address1": "2655 Richmond Ave",
            "address2": "Level 2",
            "address3": None,
            "city": "Staten Island",
            "zip_code": "10314",
            "country": "US",
            "state": "NY",
            "display_address": [
                "2655 Richmond Ave",
                "Level 2",
                "Staten Island, NY 10314"
            ]
        }
    },
    {
        "bid": "JEQ00qBAepe0oSiUBdfIew",
        "rating": 4.0,
        "reviews": 2661,
        "coordinates": {
            "latitude": 40.77444,
            "longitude": -73.90786
        },
        "name": "Taverna Kyclades",
        "address": {
            "address1": "3601 Ditmars Blvd",
            "address2": "",
            "address3": "",
            "city": "Astoria",
            "zip_code": "11105",
            "country": "US",
            "state": "NY",
            "display_address": [
                "3601 Ditmars Blvd",
                "Astoria, NY 11105"
            ]
        }
    },
    {
        "bid": "LMPhhzV9qBOyPaqfcRO_sA",
        "rating": 5.0,
        "reviews": 1,
        "coordinates": {
            "latitude": 40.72613,
            "longitude": -74.004997
        },
        "name": "Shai Hummus",
        "address": {
            "address1": "30 Vandam St",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10013",
            "country": "US",
            "state": "NY",
            "display_address": [
                "30 Vandam St",
                "New York, NY 10013"
            ]
        }
    },
    {
        "bid": "-fcbr1p0Uijjg3WpDDn5VA",
        "rating": 4.5,
        "reviews": 293,
        "coordinates": {
            "latitude": 40.679911,
            "longitude": -73.994879
        },
        "name": "Avlee Greek Kitchen",
        "address": {
            "address1": "349 Smith St",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11231",
            "country": "US",
            "state": "NY",
            "display_address": [
                "349 Smith St",
                "Brooklyn, NY 11231"
            ]
        }
    },
    {
        "bid": "GeoR6dpTUEpdIoyAd68Irg",
        "rating": 4.0,
        "reviews": 313,
        "coordinates": {
            "latitude": 40.73904,
            "longitude": -73.99283
        },
        "name": "Kyma",
        "address": {
            "address1": "15 W 18th St",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10011",
            "country": "US",
            "state": "NY",
            "display_address": [
                "15 W 18th St",
                "New York, NY 10011"
            ]
        }
    },
    {
        "bid": "g6xt5okaNzEZV6Y_Qerw0g",
        "rating": 4.5,
        "reviews": 6,
        "coordinates": {
            "latitude": 40.89059,
            "longitude": -73.898
        },
        "name": "Tawabel",
        "address": {
            "address1": "5999 Broadway",
            "address2": "",
            "address3": None,
            "city": "The Bronx",
            "zip_code": "10471",
            "country": "US",
            "state": "NY",
            "display_address": [
                "5999 Broadway",
                "The Bronx, NY 10471"
            ]
        }
    },
    {
        "bid": "_l__uXH-xeqJVZbLiISGlQ",
        "rating": 4.0,
        "reviews": 58,
        "coordinates": {
            "latitude": 40.7534541,
            "longitude": -73.9988312
        },
        "name": "Casa Dani",
        "address": {
            "address1": "448 W 33rd St",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10001",
            "country": "US",
            "state": "NY",
            "display_address": [
                "448 W 33rd St",
                "New York, NY 10001"
            ]
        }
    },
    {
        "bid": "z3vcYpnDgnBzZNqhQMOHUA",
        "rating": 4.0,
        "reviews": 111,
        "coordinates": {
            "latitude": 40.69148,
            "longitude": -73.9978
        },
        "name": "Fatoosh Pitza & Grill",
        "address": {
            "address1": "330 Hicks St",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11201",
            "country": "US",
            "state": "NY",
            "display_address": [
                "330 Hicks St",
                "Brooklyn, NY 11201"
            ]
        }
    },
    {
        "bid": "E1DbVbb3tLEerbocDC5kRQ",
        "rating": 5.0,
        "reviews": 43,
        "coordinates": {
            "latitude": 40.89507,
            "longitude": -73.97631
        },
        "name": "Antioch Restaurant",
        "address": {
            "address1": "35 W Palisade Ave",
            "address2": None,
            "address3": "",
            "city": "Englewood",
            "zip_code": "07631",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "35 W Palisade Ave",
                "Englewood, NJ 07631"
            ]
        }
    },
    {
        "bid": "EX_kzzv2RNC_WwxaJ0ll9g",
        "rating": 4.5,
        "reviews": 107,
        "coordinates": {
            "latitude": 40.72979,
            "longitude": -73.97924
        },
        "name": "Dua Kafe",
        "address": {
            "address1": "520 E 14th St",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10009",
            "country": "US",
            "state": "NY",
            "display_address": [
                "520 E 14th St",
                "New York, NY 10009"
            ]
        }
    },
    {
        "bid": "sVkwEFET38Myz3dM1uZpiw",
        "rating": 4.5,
        "reviews": 600,
        "coordinates": {
            "latitude": 40.7171,
            "longitude": -73.95164
        },
        "name": "Reunion",
        "address": {
            "address1": "544 Union Ave",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11211",
            "country": "US",
            "state": "NY",
            "display_address": [
                "544 Union Ave",
                "Brooklyn, NY 11211"
            ]
        }
    },
    {
        "bid": "o8KtWVBIVI9E3YYM5r0dPw",
        "rating": 3.5,
        "reviews": 130,
        "coordinates": {
            "latitude": 40.693359375,
            "longitude": -73.9695205688477
        },
        "name": "Damas Falafel House",
        "address": {
            "address1": "407 Myrtle Ave",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11205",
            "country": "US",
            "state": "NY",
            "display_address": [
                "407 Myrtle Ave",
                "Brooklyn, NY 11205"
            ]
        }
    },
    {
        "bid": "r2tM5A3YU8m1prp-ji5KAQ",
        "rating": 4.0,
        "reviews": 36,
        "coordinates": {
            "latitude": 40.71538461875374,
            "longitude": -74.01549343149449
        },
        "name": "Anassa Taverna",
        "address": {
            "address1": "104 North End Ave",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10282",
            "country": "US",
            "state": "NY",
            "display_address": [
                "104 North End Ave",
                "New York, NY 10282"
            ]
        }
    },
    {
        "bid": "DEp-9JVnKN7eTb9A_mUlfA",
        "rating": 4.0,
        "reviews": 197,
        "coordinates": {
            "latitude": 40.752941113750204,
            "longitude": -73.99872428597398
        },
        "name": "Zou Zou\u2019s",
        "address": {
            "address1": "385 9th Ave",
            "address2": "Ste 85",
            "address3": None,
            "city": "New York",
            "zip_code": "10001",
            "country": "US",
            "state": "NY",
            "display_address": [
                "385 9th Ave",
                "Ste 85",
                "New York, NY 10001"
            ]
        }
    },
    {
        "bid": "OMRkRHFXmS9txTWirA-yMA",
        "rating": 4.0,
        "reviews": 268,
        "coordinates": {
            "latitude": 40.67742,
            "longitude": -73.98343
        },
        "name": "Taheni Mediterranean Grill",
        "address": {
            "address1": "224 4th Ave",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11215",
            "country": "US",
            "state": "NY",
            "display_address": [
                "224 4th Ave",
                "Brooklyn, NY 11215"
            ]
        }
    },
    {
        "bid": "kgX1iNxVYKFSQ9k0oPaeKA",
        "rating": 4.0,
        "reviews": 61,
        "coordinates": {
            "latitude": 40.75666,
            "longitude": -73.98335
        },
        "name": "Dill & Parsley",
        "address": {
            "address1": "1155 Avenue Of Americas",
            "address2": "Grnd Floor, 45th Street",
            "address3": "",
            "city": "New York",
            "zip_code": "10036",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1155 Avenue Of Americas",
                "Grnd Floor, 45th Street",
                "New York, NY 10036"
            ]
        }
    },
    {
        "bid": "B8CU-uft0JEuZbEf1uQ7qg",
        "rating": 4.5,
        "reviews": 30,
        "coordinates": {
            "latitude": 40.767726,
            "longitude": -73.911449
        },
        "name": "Merguez & Frites",
        "address": {
            "address1": "40-06 25th Ave",
            "address2": None,
            "address3": "",
            "city": "Astoria",
            "zip_code": "11106",
            "country": "US",
            "state": "NY",
            "display_address": [
                "40-06 25th Ave",
                "Astoria, NY 11106"
            ]
        }
    },
    {
        "bid": "4XdK-yBAnj4wLgftIU0GmA",
        "rating": 4.0,
        "reviews": 42,
        "coordinates": {
            "latitude": 40.8478206,
            "longitude": -73.8671998
        },
        "name": "Oasis Mediterranean Restaurant",
        "address": {
            "address1": "1907 White Plains Rd",
            "address2": "",
            "address3": "",
            "city": "Bronx",
            "zip_code": "10462",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1907 White Plains Rd",
                "Bronx, NY 10462"
            ]
        }
    },
    {
        "bid": "51YLgpfHKfXxOkDFe9sT-w",
        "rating": 4.5,
        "reviews": 406,
        "coordinates": {
            "latitude": 40.7524299621582,
            "longitude": -73.9887237548828
        },
        "name": "Balade - Your Way",
        "address": {
            "address1": "144 West 37th St",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10018",
            "country": "US",
            "state": "NY",
            "display_address": [
                "144 West 37th St",
                "New York, NY 10018"
            ]
        }
    },
    {
        "bid": "mMuAsPSy2T56j0ENSTPL9w",
        "rating": 4.5,
        "reviews": 352,
        "coordinates": {
            "latitude": 40.7337897786475,
            "longitude": -73.9896078601189
        },
        "name": "Cava",
        "address": {
            "address1": "143 4th Ave",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10003",
            "country": "US",
            "state": "NY",
            "display_address": [
                "143 4th Ave",
                "New York, NY 10003"
            ]
        }
    },
    {
        "bid": "6Fi9EBxatFA6SsrK-QajLw",
        "rating": 3.5,
        "reviews": 73,
        "coordinates": {
            "latitude": 40.77199,
            "longitude": -73.95567
        },
        "name": "The Blue Mezze Bar",
        "address": {
            "address1": "1480 2nd Ave",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10075",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1480 2nd Ave",
                "New York, NY 10075"
            ]
        }
    },
    {
        "bid": "1XK53gaHMFQIA4VW3B6k1Q",
        "rating": 4.5,
        "reviews": 110,
        "coordinates": {
            "latitude": 40.755541483222,
            "longitude": -73.9718742367706
        },
        "name": "Abaita",
        "address": {
            "address1": "145 E 49th St",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10017",
            "country": "US",
            "state": "NY",
            "display_address": [
                "145 E 49th St",
                "New York, NY 10017"
            ]
        }
    },
    {
        "bid": "kGgOb9nxnFfDvPdZ1Aq7cA",
        "rating": 3.5,
        "reviews": 158,
        "coordinates": {
            "latitude": 40.7362094701213,
            "longitude": -73.9874085025025
        },
        "name": "Adalya",
        "address": {
            "address1": "55 Irving Pl",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10003",
            "country": "US",
            "state": "NY",
            "display_address": [
                "55 Irving Pl",
                "New York, NY 10003"
            ]
        }
    },
    {
        "bid": "L6DAp6L1ZJKeeDN2PwoOLQ",
        "rating": 4.5,
        "reviews": 470,
        "coordinates": {
            "latitude": 40.75927857933082,
            "longitude": -73.98087907274463
        },
        "name": "Adel's Famous Halal Food",
        "address": {
            "address1": "49th & 6th",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10019",
            "country": "US",
            "state": "NY",
            "display_address": [
                "49th & 6th",
                "New York, NY 10019"
            ]
        }
    },
    {
        "bid": "mhhTORjUdXj-UIDjyGmhBg",
        "rating": 4.0,
        "reviews": 1044,
        "coordinates": {
            "latitude": 40.763541894630784,
            "longitude": -73.97902511983438
        },
        "name": "Estiatorio Milos - Midtown New York",
        "address": {
            "address1": "125 W 55th St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10019",
            "country": "US",
            "state": "NY",
            "display_address": [
                "125 W 55th St",
                "New York, NY 10019"
            ]
        }
    },
    {
        "bid": "wSASXdz14Ma-djb8l2T1SQ",
        "rating": 4.5,
        "reviews": 27,
        "coordinates": {
            "latitude": 40.82064788801918,
            "longitude": -73.99110244313795
        },
        "name": "Pide Lahmajoun",
        "address": {
            "address1": "442 Anderson Ave",
            "address2": "Ste C",
            "address3": "",
            "city": "Cliffside Park",
            "zip_code": "07010",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "442 Anderson Ave",
                "Ste C",
                "Cliffside Park, NJ 07010"
            ]
        }
    },
    {
        "bid": "ptgu17Y_jD60815rPTEN1w",
        "rating": 4.0,
        "reviews": 121,
        "coordinates": {
            "latitude": 40.6907009,
            "longitude": -73.9834976
        },
        "name": "Kotti Berliner D\u00f6ner Kebab",
        "address": {
            "address1": "445 Albee Square W",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11201",
            "country": "US",
            "state": "NY",
            "display_address": [
                "445 Albee Square W",
                "Brooklyn, NY 11201"
            ]
        }
    },
    {
        "bid": "CD_nOkyA6TtL9HgNHr08cQ",
        "rating": 4.5,
        "reviews": 17,
        "coordinates": {
            "latitude": 40.761694,
            "longitude": -73.981806
        },
        "name": "Pita Yeero",
        "address": {
            "address1": "152 W 52nd St",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10019",
            "country": "US",
            "state": "NY",
            "display_address": [
                "152 W 52nd St",
                "New York, NY 10019"
            ]
        }
    },
    {
        "bid": "3sTSl6EcahJMJbfByygNnw",
        "rating": 4.5,
        "reviews": 50,
        "coordinates": {
            "latitude": 40.749352,
            "longitude": -73.890394
        },
        "name": "El Toum",
        "address": {
            "address1": "35-62 76th St",
            "address2": "",
            "address3": None,
            "city": "Jackson Heights",
            "zip_code": "11372",
            "country": "US",
            "state": "NY",
            "display_address": [
                "35-62 76th St",
                "Jackson Heights, NY 11372"
            ]
        }
    },
    {
        "bid": "NKI1VvfXYluRjnq4S6yEuw",
        "rating": 4.5,
        "reviews": 460,
        "coordinates": {
            "latitude": 40.72378,
            "longitude": -73.98849
        },
        "name": "Divya's Kitchen",
        "address": {
            "address1": "25 1st Ave",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10003",
            "country": "US",
            "state": "NY",
            "display_address": [
                "25 1st Ave",
                "New York, NY 10003"
            ]
        }
    },
    {
        "bid": "Tp3MF3DNXuW41A10PQ2nFw",
        "rating": 4.0,
        "reviews": 498,
        "coordinates": {
            "latitude": 40.7633557384716,
            "longitude": -73.9686296877489
        },
        "name": "Amali",
        "address": {
            "address1": "115 E 60th St",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10022",
            "country": "US",
            "state": "NY",
            "display_address": [
                "115 E 60th St",
                "New York, NY 10022"
            ]
        }
    },
    {
        "bid": "dy_xfi_3asaGjcVpndh1SA",
        "rating": 4.0,
        "reviews": 73,
        "coordinates": {
            "latitude": 40.764981,
            "longitude": -73.981702
        },
        "name": "IRIS Restaurant",
        "address": {
            "address1": "1740 Broadway",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10019",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1740 Broadway",
                "New York, NY 10019"
            ]
        }
    },
    {
        "bid": "bkYcT19Fyb95H_qjnVcIQw",
        "rating": 4.5,
        "reviews": 521,
        "coordinates": {
            "latitude": 40.8152626921391,
            "longitude": -74.1618162766099
        },
        "name": "The Bosphorus",
        "address": {
            "address1": "226 Franklin Ave",
            "address2": None,
            "address3": "",
            "city": "Nutley",
            "zip_code": "07110",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "226 Franklin Ave",
                "Nutley, NJ 07110"
            ]
        }
    },
    {
        "bid": "-D6LvH79fHSPK2menTihZw",
        "rating": 4.5,
        "reviews": 50,
        "coordinates": {
            "latitude": 40.720536,
            "longitude": -74.047015
        },
        "name": "Efes Mediterranean Grill",
        "address": {
            "address1": "515 Jersey Ave",
            "address2": "",
            "address3": None,
            "city": "Jersey City",
            "zip_code": "07302",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "515 Jersey Ave",
                "Jersey City, NJ 07302"
            ]
        }
    },
    {
        "bid": "YDHUVTkQ5ioHaPOMVwQjWQ",
        "rating": 4.0,
        "reviews": 183,
        "coordinates": {
            "latitude": 40.791129,
            "longitude": -73.973913
        },
        "name": "Dagon",
        "address": {
            "address1": "2454 Broadway",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10024",
            "country": "US",
            "state": "NY",
            "display_address": [
                "2454 Broadway",
                "New York, NY 10024"
            ]
        }
    },
    {
        "bid": "1p4dUaLyzIhN5n1lJnHSgA",
        "rating": 4.0,
        "reviews": 574,
        "coordinates": {
            "latitude": 40.7859082,
            "longitude": -73.9759551
        },
        "name": "Bustan",
        "address": {
            "address1": "487 Amsterdam Ave",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10024",
            "country": "US",
            "state": "NY",
            "display_address": [
                "487 Amsterdam Ave",
                "New York, NY 10024"
            ]
        }
    },
    {
        "bid": "SFqvhzfPs1FN3RqVwaKYaQ",
        "rating": 4.5,
        "reviews": 515,
        "coordinates": {
            "latitude": 40.862068,
            "longitude": -74.077831
        },
        "name": "Sofia's Mediterranean Grill",
        "address": {
            "address1": "220 Blvd",
            "address2": "",
            "address3": "",
            "city": "Hasbrouck Heights",
            "zip_code": "07604",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "220 Blvd",
                "Hasbrouck Heights, NJ 07604"
            ]
        }
    },
    {
        "bid": "Enp_vGOKBgsitskHoD42lQ",
        "rating": 4.0,
        "reviews": 30,
        "coordinates": {
            "latitude": 40.7099794,
            "longitude": -73.84893029999999
        },
        "name": "OBA Mediterranean Grill",
        "address": {
            "address1": "104-02 Metropolitan Ave",
            "address2": "",
            "address3": None,
            "city": "Flushing",
            "zip_code": "11375",
            "country": "US",
            "state": "NY",
            "display_address": [
                "104-02 Metropolitan Ave",
                "Flushing, NY 11375"
            ]
        }
    },
    {
        "bid": "UzJ35gU93WK_YMq6DyAb5Q",
        "rating": 4.5,
        "reviews": 47,
        "coordinates": {
            "latitude": 40.75976885306238,
            "longitude": -73.92021439999999
        },
        "name": "Cafe Turkiye",
        "address": {
            "address1": "37-05  Bdwy",
            "address2": None,
            "address3": "",
            "city": "Astoria",
            "zip_code": "11103",
            "country": "US",
            "state": "NY",
            "display_address": [
                "37-05  Bdwy",
                "Astoria, NY 11103"
            ]
        }
    },
    {
        "bid": "ciMe24uelCYS2qH3ldeSyQ",
        "rating": 4.5,
        "reviews": 69,
        "coordinates": {
            "latitude": 40.73696,
            "longitude": -74.03058
        },
        "name": "Plaka Souvlaki",
        "address": {
            "address1": "62 Newark St",
            "address2": "",
            "address3": None,
            "city": "Hoboken",
            "zip_code": "07030",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "62 Newark St",
                "Hoboken, NJ 07030"
            ]
        }
    },
    {
        "bid": "v0LGazMDlyPX5ceLYpZyTg",
        "rating": 4.0,
        "reviews": 417,
        "coordinates": {
            "latitude": 40.756948,
            "longitude": -73.9806443
        },
        "name": "Akdeniz Mediterranean Cuisine",
        "address": {
            "address1": "43 West 46th Street",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10036",
            "country": "US",
            "state": "NY",
            "display_address": [
                "43 West 46th Street",
                "New York, NY 10036"
            ]
        }
    },
    {
        "bid": "Lkz8ExozPGmYBvz-ZEtXOg",
        "rating": 4.5,
        "reviews": 194,
        "coordinates": {
            "latitude": 40.793897,
            "longitude": -73.807946
        },
        "name": "N\u00e4na Good Eats",
        "address": {
            "address1": "152-67A 10th Ave",
            "address2": None,
            "address3": "",
            "city": "Whitestone",
            "zip_code": "11357",
            "country": "US",
            "state": "NY",
            "display_address": [
                "152-67A 10th Ave",
                "Whitestone, NY 11357"
            ]
        }
    },
    {
        "bid": "7UJRw4Klt5yfE7q9vznEHA",
        "rating": 4.0,
        "reviews": 196,
        "coordinates": {
            "latitude": 40.7107199,
            "longitude": -73.9582771
        },
        "name": "Kabob Shack",
        "address": {
            "address1": "182 Havemeyer St",
            "address2": None,
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11211",
            "country": "US",
            "state": "NY",
            "display_address": [
                "182 Havemeyer St",
                "Brooklyn, NY 11211"
            ]
        }
    },
    {
        "bid": "O8XXOQ1crVOjGsz1ARKCFA",
        "rating": 4.0,
        "reviews": 220,
        "coordinates": {
            "latitude": 40.7864566,
            "longitude": -74.0454879
        },
        "name": "Stefanos Mediterranean Grille",
        "address": {
            "address1": "700 Plaza Dr",
            "address2": None,
            "address3": None,
            "city": "Secaucus",
            "zip_code": "07094",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "700 Plaza Dr",
                "Secaucus, NJ 07094"
            ]
        }
    },
    {
        "bid": "ugYhnKrr3Q1TVV15R0EEWQ",
        "rating": 4.0,
        "reviews": 456,
        "coordinates": {
            "latitude": 40.755991,
            "longitude": -73.980313
        },
        "name": "AnTalia NYC",
        "address": {
            "address1": "17 W 45th St",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10036",
            "country": "US",
            "state": "NY",
            "display_address": [
                "17 W 45th St",
                "New York, NY 10036"
            ]
        }
    },
    {
        "bid": "cHO3fHUonUE9IOW_5bj8qw",
        "rating": 4.5,
        "reviews": 21,
        "coordinates": {
            "latitude": 40.690726,
            "longitude": -73.983124
        },
        "name": "Hummus Inc",
        "address": {
            "address1": "445 Albee Square W",
            "address2": "DeKalb Market Hall",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11201",
            "country": "US",
            "state": "NY",
            "display_address": [
                "445 Albee Square W",
                "DeKalb Market Hall",
                "Brooklyn, NY 11201"
            ]
        }
    },
    {
        "bid": "Q2dKbHvXwmJuoaf1Yahfxw",
        "rating": 4.0,
        "reviews": 237,
        "coordinates": {
            "latitude": 40.70814,
            "longitude": -74.01779
        },
        "name": "Miramar",
        "address": {
            "address1": "21 S End Ave",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10280",
            "country": "US",
            "state": "NY",
            "display_address": [
                "21 S End Ave",
                "New York, NY 10280"
            ]
        }
    },
    {
        "bid": "47J3jLkclOMXExoPoIpnag",
        "rating": 4.5,
        "reviews": 210,
        "coordinates": {
            "latitude": 40.715385,
            "longitude": -73.944839
        },
        "name": "Hummus Market",
        "address": {
            "address1": "361 Graham Ave",
            "address2": None,
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11211",
            "country": "US",
            "state": "NY",
            "display_address": [
                "361 Graham Ave",
                "Brooklyn, NY 11211"
            ]
        }
    },
    {
        "bid": "pGByzum9iOjdnXj8VhQomA",
        "rating": 4.5,
        "reviews": 28,
        "coordinates": {
            "latitude": 40.759231,
            "longitude": -73.992676
        },
        "name": "Molyvos Restaurant",
        "address": {
            "address1": "402 West 43rd St",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10036",
            "country": "US",
            "state": "NY",
            "display_address": [
                "402 West 43rd St",
                "New York, NY 10036"
            ]
        }
    },
    {
        "bid": "nHLchRWrxxv5MWD8IHpYzg",
        "rating": 4.0,
        "reviews": 22,
        "coordinates": {
            "latitude": 40.74366,
            "longitude": -73.97941
        },
        "name": "Meze Mazi",
        "address": {
            "address1": "449 3rd Ave",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10016",
            "country": "US",
            "state": "NY",
            "display_address": [
                "449 3rd Ave",
                "New York, NY 10016"
            ]
        }
    },
    {
        "bid": "8mZ6fE9n_mK59mJ_MYtrSQ",
        "rating": 4.0,
        "reviews": 376,
        "coordinates": {
            "latitude": 40.64035,
            "longitude": -73.9667
        },
        "name": "Mimi's Hummus",
        "address": {
            "address1": "1209 Cortelyou Rd",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11218",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1209 Cortelyou Rd",
                "Brooklyn, NY 11218"
            ]
        }
    },
    {
        "bid": "FxOt8Exq5CA5izlDPFPoUg",
        "rating": 4.0,
        "reviews": 112,
        "coordinates": {
            "latitude": 40.78458,
            "longitude": -73.97706
        },
        "name": "Gazala's",
        "address": {
            "address1": "447 Amsterdam Ave",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10024",
            "country": "US",
            "state": "NY",
            "display_address": [
                "447 Amsterdam Ave",
                "New York, NY 10024"
            ]
        }
    },
    {
        "bid": "cBUlHFB1fk2q3WmP6o7gvA",
        "rating": 3.5,
        "reviews": 106,
        "coordinates": {
            "latitude": 40.70769,
            "longitude": -74.00767
        },
        "name": "ta\u00efm mediterranean kitchen - Maiden Lane",
        "address": {
            "address1": "75 Maiden Ln",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10038",
            "country": "US",
            "state": "NY",
            "display_address": [
                "75 Maiden Ln",
                "New York, NY 10038"
            ]
        }
    },
    {
        "bid": "L-IuiVoFMDSw2K6OAciP1g",
        "rating": 4.0,
        "reviews": 2562,
        "coordinates": {
            "latitude": 40.7302874,
            "longitude": -74.0004383
        },
        "name": "Mamoun's Falafel",
        "address": {
            "address1": "119 MacDougal St",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10012",
            "country": "US",
            "state": "NY",
            "display_address": [
                "119 MacDougal St",
                "New York, NY 10012"
            ]
        }
    },
    {
        "bid": "_-EQR2vNYg-b1eZwAgp6JQ",
        "rating": 4.0,
        "reviews": 989,
        "coordinates": {
            "latitude": 40.6308,
            "longitude": -74.02775
        },
        "name": "Tanoreen",
        "address": {
            "address1": "7523 3rd Ave",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11209",
            "country": "US",
            "state": "NY",
            "display_address": [
                "7523 3rd Ave",
                "Brooklyn, NY 11209"
            ]
        }
    },
    {
        "bid": "Pcpcv2T9OJiYXAeFr-026w",
        "rating": 3.5,
        "reviews": 13,
        "coordinates": {
            "latitude": 40.735075,
            "longitude": -73.993127
        },
        "name": "Reyna",
        "address": {
            "address1": "11 E 13th St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10003",
            "country": "US",
            "state": "NY",
            "display_address": [
                "11 E 13th St",
                "New York, NY 10003"
            ]
        }
    },
    {
        "bid": "YdKlXHJUtWPLEa0SfEOn9A",
        "rating": 4.5,
        "reviews": 161,
        "coordinates": {
            "latitude": 40.94008851850005,
            "longitude": -74.11989803700902
        },
        "name": "Ada Mediterranean Brasserie",
        "address": {
            "address1": "14-25 Plaza Rd N",
            "address2": None,
            "address3": "",
            "city": "Fair Lawn",
            "zip_code": "07410",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "14-25 Plaza Rd N",
                "Fair Lawn, NJ 07410"
            ]
        }
    },
    {
        "bid": "Itg3FiXNyf9NXKegy46Lwg",
        "rating": 4.5,
        "reviews": 177,
        "coordinates": {
            "latitude": 40.7266223,
            "longitude": -73.870707
        },
        "name": "Taste of Samarkand",
        "address": {
            "address1": "62-16 Woodhaven Blvd",
            "address2": None,
            "address3": "",
            "city": "Middle Village",
            "zip_code": "11374",
            "country": "US",
            "state": "NY",
            "display_address": [
                "62-16 Woodhaven Blvd",
                "Middle Village, NY 11374"
            ]
        }
    },
    {
        "bid": "lzUkaMCuxYWR1cL_q3ElsQ",
        "rating": 4.5,
        "reviews": 174,
        "coordinates": {
            "latitude": 40.72308,
            "longitude": -73.9452699
        },
        "name": "Dar 525",
        "address": {
            "address1": "168 Driggs Ave",
            "address2": None,
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11222",
            "country": "US",
            "state": "NY",
            "display_address": [
                "168 Driggs Ave",
                "Brooklyn, NY 11222"
            ]
        }
    },
    {
        "bid": "tKog0Ewz1roBME_kX1G6hg",
        "rating": 4.5,
        "reviews": 441,
        "coordinates": {
            "latitude": 40.732822,
            "longitude": -73.997152
        },
        "name": "Eva\u2019s x Cinco de Mayo",
        "address": {
            "address1": "11 W 8th St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10011",
            "country": "US",
            "state": "NY",
            "display_address": [
                "11 W 8th St",
                "New York, NY 10011"
            ]
        }
    },
    {
        "bid": "446l_JghlLeekhd7_blMag",
        "rating": 4.0,
        "reviews": 54,
        "coordinates": {
            "latitude": 40.70413,
            "longitude": -73.93309
        },
        "name": "Eyval",
        "address": {
            "address1": "25 Bogart St",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11206",
            "country": "US",
            "state": "NY",
            "display_address": [
                "25 Bogart St",
                "Brooklyn, NY 11206"
            ]
        }
    },
    {
        "bid": "tuhlWtnjoOn8C6NTUCnbPg",
        "rating": 4.0,
        "reviews": 38,
        "coordinates": {
            "latitude": 40.6795300180332,
            "longitude": -73.98681309999999
        },
        "name": "Victor",
        "address": {
            "address1": "285 Nevins St",
            "address2": None,
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11217",
            "country": "US",
            "state": "NY",
            "display_address": [
                "285 Nevins St",
                "Brooklyn, NY 11217"
            ]
        }
    },
    {
        "bid": "ZfVHyRKrP7OQnaUmItRK1A",
        "rating": 4.0,
        "reviews": 699,
        "coordinates": {
            "latitude": 40.7684923638382,
            "longitude": -73.9111769199371
        },
        "name": "Duzan Mediterranean Grill",
        "address": {
            "address1": "2411 Steinway St",
            "address2": None,
            "address3": "",
            "city": "Astoria",
            "zip_code": "11103",
            "country": "US",
            "state": "NY",
            "display_address": [
                "2411 Steinway St",
                "Astoria, NY 11103"
            ]
        }
    },
    {
        "bid": "3o0Jp9ttSpP1wu7Focs7xg",
        "rating": 4.0,
        "reviews": 1283,
        "coordinates": {
            "latitude": 40.728814,
            "longitude": -73.98845088123514
        },
        "name": "Mamoun's Falafel",
        "address": {
            "address1": "30 St Marks Pl",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10003",
            "country": "US",
            "state": "NY",
            "display_address": [
                "30 St Marks Pl",
                "New York, NY 10003"
            ]
        }
    },
    {
        "bid": "suTjDG7xDpA2-t64SbldXw",
        "rating": 4.0,
        "reviews": 59,
        "coordinates": {
            "latitude": 40.72161,
            "longitude": -73.95884
        },
        "name": "The Williamsburg Hotel Restaurant",
        "address": {
            "address1": "96 Wythe Ave",
            "address2": None,
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11249",
            "country": "US",
            "state": "NY",
            "display_address": [
                "96 Wythe Ave",
                "Brooklyn, NY 11249"
            ]
        }
    },
    {
        "bid": "228DO__YwYmliMx6Q5jTtw",
        "rating": 4.0,
        "reviews": 613,
        "coordinates": {
            "latitude": 40.75913,
            "longitude": -73.9918
        },
        "name": "Turco Mediterranean Grill",
        "address": {
            "address1": "604 9th Ave",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10036",
            "country": "US",
            "state": "NY",
            "display_address": [
                "604 9th Ave",
                "New York, NY 10036"
            ]
        }
    },
    {
        "bid": "IAVv4YRvo3ZlpxQX6ub1FA",
        "rating": 3.5,
        "reviews": 12,
        "coordinates": {
            "latitude": 40.65569,
            "longitude": -74.0069
        },
        "name": "Ayat - Brooklyn",
        "address": {
            "address1": "274 36th St",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11232",
            "country": "US",
            "state": "NY",
            "display_address": [
                "274 36th St",
                "Brooklyn, NY 11232"
            ]
        }
    },
    {
        "bid": "ouBGlW6dzHVNjohSkUkI0w",
        "rating": 4.0,
        "reviews": 13,
        "coordinates": {
            "latitude": 40.60611223626826,
            "longitude": -74.28896911717885
        },
        "name": "Moazz Mediterranean Grill",
        "address": {
            "address1": "928 St Georges Ave",
            "address2": "",
            "address3": None,
            "city": "Rahway",
            "zip_code": "07065",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "928 St Georges Ave",
                "Rahway, NJ 07065"
            ]
        }
    },
    {
        "bid": "1SaKutXcH38X0KvayyDHUA",
        "rating": 3.5,
        "reviews": 1436,
        "coordinates": {
            "latitude": 40.7383263,
            "longitude": -73.9880646
        },
        "name": "Barbounia",
        "address": {
            "address1": "250 Park Ave S",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10003",
            "country": "US",
            "state": "NY",
            "display_address": [
                "250 Park Ave S",
                "New York, NY 10003"
            ]
        }
    },
    {
        "bid": "4byAirxIA4OEgKHHgJfKLw",
        "rating": 4.5,
        "reviews": 162,
        "coordinates": {
            "latitude": 40.6638,
            "longitude": -73.98067
        },
        "name": "Zatar Cafe & Bistro",
        "address": {
            "address1": "1201 8th Ave",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11215",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1201 8th Ave",
                "Brooklyn, NY 11215"
            ]
        }
    },
    {
        "bid": "sR60I9PI_63noBQcGoIrbw",
        "rating": 4.5,
        "reviews": 509,
        "coordinates": {
            "latitude": 40.72123,
            "longitude": -73.98408
        },
        "name": "Pause Cafe",
        "address": {
            "address1": "3 Clinton St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10002",
            "country": "US",
            "state": "NY",
            "display_address": [
                "3 Clinton St",
                "New York, NY 10002"
            ]
        }
    },
    {
        "bid": "nu4IkeHHUQHeD4jTajbk4Q",
        "rating": 4.5,
        "reviews": 124,
        "coordinates": {
            "latitude": 40.74666,
            "longitude": -73.97722
        },
        "name": "Sophra Grill",
        "address": {
            "address1": "535 3rd Ave",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10016",
            "country": "US",
            "state": "NY",
            "display_address": [
                "535 3rd Ave",
                "New York, NY 10016"
            ]
        }
    },
    {
        "bid": "yXK9VSId2tqYNmk-31jAEQ",
        "rating": 4.0,
        "reviews": 53,
        "coordinates": {
            "latitude": 40.75885,
            "longitude": -73.97504
        },
        "name": "NAYA - 52 & Madison",
        "address": {
            "address1": "488 Madison Ave",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10022",
            "country": "US",
            "state": "NY",
            "display_address": [
                "488 Madison Ave",
                "New York, NY 10022"
            ]
        }
    },
    {
        "bid": "BC9DVugTCxNGzLr4ZhGINw",
        "rating": 4.0,
        "reviews": 550,
        "coordinates": {
            "latitude": 40.8281599,
            "longitude": -74.09734
        },
        "name": "Elia Mediterranean Restaurant",
        "address": {
            "address1": "240 Hackensack St",
            "address2": "",
            "address3": None,
            "city": "East Rutherford",
            "zip_code": "07073",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "240 Hackensack St",
                "East Rutherford, NJ 07073"
            ]
        }
    },
    {
        "bid": "HuU2IGPfQ23FTOGDQg0Ieg",
        "rating": 4.5,
        "reviews": 76,
        "coordinates": {
            "latitude": 40.719181,
            "longitude": -73.943149
        },
        "name": "Four Five Six",
        "address": {
            "address1": "199 Richardson St",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11222",
            "country": "US",
            "state": "NY",
            "display_address": [
                "199 Richardson St",
                "Brooklyn, NY 11222"
            ]
        }
    },
    {
        "bid": "RirFOsDfTvEfYOO4PPVJzQ",
        "rating": 4.0,
        "reviews": 179,
        "coordinates": {
            "latitude": 40.757031,
            "longitude": -73.9218943
        },
        "name": "Cevabdzinica Sarajevo",
        "address": {
            "address1": "3718 34th Ave",
            "address2": "",
            "address3": "",
            "city": "Long Island City",
            "zip_code": "11101",
            "country": "US",
            "state": "NY",
            "display_address": [
                "3718 34th Ave",
                "Long Island City, NY 11101"
            ]
        }
    },
    {
        "bid": "BSBCcMu6ups8bf8t8R29HA",
        "rating": 4.5,
        "reviews": 114,
        "coordinates": {
            "latitude": 40.92695,
            "longitude": -74.03388
        },
        "name": "Mado Restaurant",
        "address": {
            "address1": "570 Kinderkamack Rd",
            "address2": None,
            "address3": "",
            "city": "River Edge",
            "zip_code": "07661",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "570 Kinderkamack Rd",
                "River Edge, NJ 07661"
            ]
        }
    },
    {
        "bid": "arE6K4GreTjN3SJ3a4BfAA",
        "rating": 4.0,
        "reviews": 19,
        "coordinates": {
            "latitude": 40.78602342032438,
            "longitude": -74.01005487889051
        },
        "name": "Laila Mediterranean Cafe & Grill",
        "address": {
            "address1": "126 60th St",
            "address2": "",
            "address3": None,
            "city": "West New York",
            "zip_code": "07093",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "126 60th St",
                "West New York, NJ 07093"
            ]
        }
    },
    {
        "bid": "-r9RZMvgH7GPDOOek89Jzw",
        "rating": 3.5,
        "reviews": 235,
        "coordinates": {
            "latitude": 40.7270494,
            "longitude": -74.0031992
        },
        "name": "Lola Taverna",
        "address": {
            "address1": "210 6th Ave",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10014",
            "country": "US",
            "state": "NY",
            "display_address": [
                "210 6th Ave",
                "New York, NY 10014"
            ]
        }
    },
    {
        "bid": "LUKW4vzYqS9CVN_76Gj-jQ",
        "rating": 3.5,
        "reviews": 7,
        "coordinates": {
            "latitude": 40.68979,
            "longitude": -73.98496
        },
        "name": "ta\u00efm mediterranean kitchen - Downtown Brooklyn",
        "address": {
            "address1": "11 Hoyt St",
            "address2": None,
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11201",
            "country": "US",
            "state": "NY",
            "display_address": [
                "11 Hoyt St",
                "Brooklyn, NY 11201"
            ]
        }
    },
    {
        "bid": "Bt6RoIcazXayp1a8lMSvzA",
        "rating": 4.0,
        "reviews": 661,
        "coordinates": {
            "latitude": 40.7760977,
            "longitude": -73.9793291
        },
        "name": "Shalel Lounge",
        "address": {
            "address1": "65 W 70th St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10023",
            "country": "US",
            "state": "NY",
            "display_address": [
                "65 W 70th St",
                "New York, NY 10023"
            ]
        }
    },
    {
        "bid": "OhUwfEt_scdr6tiptSI8NQ",
        "rating": 4.0,
        "reviews": 416,
        "coordinates": {
            "latitude": 40.58356,
            "longitude": -73.94114
        },
        "name": "Liman Restaurant",
        "address": {
            "address1": "2710 Emmons Ave",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11235",
            "country": "US",
            "state": "NY",
            "display_address": [
                "2710 Emmons Ave",
                "Brooklyn, NY 11235"
            ]
        }
    },
    {
        "bid": "XD42_G0yu0ntWib6IGlzpQ",
        "rating": 4.0,
        "reviews": 44,
        "coordinates": {
            "latitude": 40.74881626533967,
            "longitude": -73.9386014819377
        },
        "name": "ta\u00efm mediterranean kitchen - Long Island City",
        "address": {
            "address1": "28-17 Jackson Ave",
            "address2": None,
            "address3": "",
            "city": "Long Island City",
            "zip_code": "11101",
            "country": "US",
            "state": "NY",
            "display_address": [
                "28-17 Jackson Ave",
                "Long Island City, NY 11101"
            ]
        }
    },
    {
        "bid": "ZBLttLnl7z-b_NRuzyRvww",
        "rating": 4.0,
        "reviews": 125,
        "coordinates": {
            "latitude": 40.80885,
            "longitude": -73.95935
        },
        "name": "Elysian Fields Cafe",
        "address": {
            "address1": "1207 Amsterdam Ave",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10027",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1207 Amsterdam Ave",
                "New York, NY 10027"
            ]
        }
    },
    {
        "bid": "mLN0p_NQVQf4ThJ_U3ktZw",
        "rating": 5.0,
        "reviews": 37,
        "coordinates": {
            "latitude": 40.80017,
            "longitude": -74.19706
        },
        "name": "Manouche",
        "address": {
            "address1": "176 Broad St",
            "address2": "",
            "address3": None,
            "city": "Bloomfield",
            "zip_code": "07003",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "176 Broad St",
                "Bloomfield, NJ 07003"
            ]
        }
    },
    {
        "bid": "uwx3yy7Wu5u55EiXRv03aQ",
        "rating": 4.0,
        "reviews": 346,
        "coordinates": {
            "latitude": 40.747742,
            "longitude": -74.028024
        },
        "name": "Ali Baba",
        "address": {
            "address1": "912 Washington St",
            "address2": "",
            "address3": "",
            "city": "Hoboken",
            "zip_code": "07030",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "912 Washington St",
                "Hoboken, NJ 07030"
            ]
        }
    },
    {
        "bid": "SClbV7TPTjJo6WYZBpErRg",
        "rating": 4.5,
        "reviews": 183,
        "coordinates": {
            "latitude": 40.7706521468765,
            "longitude": -73.9207250177398
        },
        "name": "Anassa Taverna Astoria",
        "address": {
            "address1": "28-10 Astoria Blvd",
            "address2": "",
            "address3": None,
            "city": "Astoria",
            "zip_code": "11102",
            "country": "US",
            "state": "NY",
            "display_address": [
                "28-10 Astoria Blvd",
                "Astoria, NY 11102"
            ]
        }
    },
    {
        "bid": "9XuL2AQt4AKMXEBbSsU75A",
        "rating": 4.0,
        "reviews": 198,
        "coordinates": {
            "latitude": 40.58147,
            "longitude": -74.0984299
        },
        "name": "Zara Cafe Grill",
        "address": {
            "address1": "1995 Hylan Blvd",
            "address2": None,
            "address3": "",
            "city": "Staten Island",
            "zip_code": "10306",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1995 Hylan Blvd",
                "Staten Island, NY 10306"
            ]
        }
    },
    {
        "bid": "32163sAKsk3y_HagU9oIUA",
        "rating": 4.0,
        "reviews": 116,
        "coordinates": {
            "latitude": 40.73669,
            "longitude": -73.997985
        },
        "name": "Salam Restaurant",
        "address": {
            "address1": "104 W 13th St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10011",
            "country": "US",
            "state": "NY",
            "display_address": [
                "104 W 13th St",
                "New York, NY 10011"
            ]
        }
    },
    {
        "bid": "K9Ur20N51Li3sAvaV9-6Ng",
        "rating": 4.5,
        "reviews": 84,
        "coordinates": {
            "latitude": 40.7573268,
            "longitude": -73.97666174194207
        },
        "name": "Casa Limone",
        "address": {
            "address1": "20 East 49th St",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10017",
            "country": "US",
            "state": "NY",
            "display_address": [
                "20 East 49th St",
                "New York, NY 10017"
            ]
        }
    },
    {
        "bid": "gftLm0T4RE97DkksJEDNzw",
        "rating": 5.0,
        "reviews": 3,
        "coordinates": {
            "latitude": 40.703831451074024,
            "longitude": -73.94110306706243
        },
        "name": "Turko\u2019s Grill",
        "address": {
            "address1": "110 Moore St",
            "address2": "Ste \u00a08",
            "address3": "Moore Street Market",
            "city": "New York",
            "zip_code": "11206",
            "country": "US",
            "state": "NY",
            "display_address": [
                "110 Moore St",
                "Ste \u00a08",
                "Moore Street Market",
                "New York, NY 11206"
            ]
        }
    },
    {
        "bid": "cfnJ8qBvl9oJJRoYXCEMNQ",
        "rating": 4.5,
        "reviews": 216,
        "coordinates": {
            "latitude": 40.2163565914325,
            "longitude": -74.0106643109353
        },
        "name": "REYLA",
        "address": {
            "address1": "603 Mattison Ave",
            "address2": None,
            "address3": "",
            "city": "Asbury Park",
            "zip_code": "07712",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "603 Mattison Ave",
                "Asbury Park, NJ 07712"
            ]
        }
    },
    {
        "bid": "u0-YeqDrlTYkoenXsQaSqg",
        "rating": 4.5,
        "reviews": 54,
        "coordinates": {
            "latitude": 40.77869457645689,
            "longitude": -73.95302561311347
        },
        "name": "The Hummus & Pita",
        "address": {
            "address1": "215 E 86th St",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10028",
            "country": "US",
            "state": "NY",
            "display_address": [
                "215 E 86th St",
                "New York, NY 10028"
            ]
        }
    },
    {
        "bid": "kzd10IXi3dTjoPw0TDj8tA",
        "rating": 4.0,
        "reviews": 154,
        "coordinates": {
            "latitude": 40.775666,
            "longitude": -73.953649
        },
        "name": "Osteria Nando",
        "address": {
            "address1": "1589 2nd Ave",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10028",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1589 2nd Ave",
                "New York, NY 10028"
            ]
        }
    },
    {
        "bid": "YNROFa4J25EujA2g6hl9mw",
        "rating": 4.5,
        "reviews": 81,
        "coordinates": {
            "latitude": 40.76128,
            "longitude": -73.96099
        },
        "name": "Sea Salt",
        "address": {
            "address1": "1123 1st Ave",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10065",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1123 1st Ave",
                "New York, NY 10065"
            ]
        }
    },
    {
        "bid": "mdhwe9pw_OD9DGPLZUmzKQ",
        "rating": 4.0,
        "reviews": 466,
        "coordinates": {
            "latitude": 40.7644212205497,
            "longitude": -73.9587869
        },
        "name": "Greek Eats",
        "address": {
            "address1": "1229 1st Ave",
            "address2": None,
            "address3": None,
            "city": "New York",
            "zip_code": "10065",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1229 1st Ave",
                "New York, NY 10065"
            ]
        }
    },
    {
        "bid": "rbb3TpbtzrBbzRxKOTxzEg",
        "rating": 4.0,
        "reviews": 236,
        "coordinates": {
            "latitude": 40.763121,
            "longitude": -73.977025
        },
        "name": "NAYA - 56 & 6th",
        "address": {
            "address1": "54 W 56th St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10019",
            "country": "US",
            "state": "NY",
            "display_address": [
                "54 W 56th St",
                "New York, NY 10019"
            ]
        }
    },
    {
        "bid": "MpAMVnHBg-E0OFd4QcDjeg",
        "rating": 5.0,
        "reviews": 17,
        "coordinates": {
            "latitude": 40.68060217522277,
            "longitude": -73.97439577813607
        },
        "name": "Shawarma Mia",
        "address": {
            "address1": "67 6th Ave",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11217",
            "country": "US",
            "state": "NY",
            "display_address": [
                "67 6th Ave",
                "Brooklyn, NY 11217"
            ]
        }
    },
    {
        "bid": "356XKWDc9lVUCBuEZ2HHiQ",
        "rating": 4.0,
        "reviews": 255,
        "coordinates": {
            "latitude": 40.737398,
            "longitude": -74.00796
        },
        "name": "Entwine",
        "address": {
            "address1": "765 Washington St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10014",
            "country": "US",
            "state": "NY",
            "display_address": [
                "765 Washington St",
                "New York, NY 10014"
            ]
        }
    },
    {
        "bid": "87WfLan3_7K_OYPYd5zUIA",
        "rating": 4.5,
        "reviews": 424,
        "coordinates": {
            "latitude": 40.788612,
            "longitude": -73.948737
        },
        "name": "La Shuk",
        "address": {
            "address1": "1569 Lexington Ave",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10029",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1569 Lexington Ave",
                "New York, NY 10029"
            ]
        }
    },
    {
        "bid": "mkDhPcUTXe57GAePH_xklg",
        "rating": 4.5,
        "reviews": 39,
        "coordinates": {
            "latitude": 40.893171134443364,
            "longitude": -73.97315110207789
        },
        "name": "Zula Grill",
        "address": {
            "address1": "51 E Palisade Ave",
            "address2": "",
            "address3": None,
            "city": "Englewood",
            "zip_code": "07631",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "51 E Palisade Ave",
                "Englewood, NJ 07631"
            ]
        }
    },
    {
        "bid": "XXHR59YE3PsMJKhaSGF82g",
        "rating": 4.0,
        "reviews": 61,
        "coordinates": {
            "latitude": 40.7092191,
            "longitude": -74.0137534
        },
        "name": "Skinos",
        "address": {
            "address1": "123 Washington St",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10006",
            "country": "US",
            "state": "NY",
            "display_address": [
                "123 Washington St",
                "New York, NY 10006"
            ]
        }
    },
    {
        "bid": "HdYmIA2jRBbKnU1mGJ9a3Q",
        "rating": 4.0,
        "reviews": 265,
        "coordinates": {
            "latitude": 40.6874192552749,
            "longitude": -73.9748689904809
        },
        "name": "The Quarter Brooklyn",
        "address": {
            "address1": "87 Lafayette Ave",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11217",
            "country": "US",
            "state": "NY",
            "display_address": [
                "87 Lafayette Ave",
                "Brooklyn, NY 11217"
            ]
        }
    },
    {
        "bid": "56qlj1cYlqNzmG0xllGg-w",
        "rating": 4.0,
        "reviews": 386,
        "coordinates": {
            "latitude": 40.70208865020039,
            "longitude": -73.9894541379247
        },
        "name": "Westville",
        "address": {
            "address1": "81 Washington St",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11201",
            "country": "US",
            "state": "NY",
            "display_address": [
                "81 Washington St",
                "Brooklyn, NY 11201"
            ]
        }
    },
    {
        "bid": "57B4MYJiEjEKeY2I4c5c0w",
        "rating": 3.5,
        "reviews": 247,
        "coordinates": {
            "latitude": 40.7325992907165,
            "longitude": -73.95777996715125
        },
        "name": "Kestane Kebab",
        "address": {
            "address1": "208 Franklin St",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11222",
            "country": "US",
            "state": "NY",
            "display_address": [
                "208 Franklin St",
                "Brooklyn, NY 11222"
            ]
        }
    },
    {
        "bid": "Ri67Ia7k0bBmgTCLvlbRBQ",
        "rating": 4.5,
        "reviews": 104,
        "coordinates": {
            "latitude": 40.74303,
            "longitude": -73.97986
        },
        "name": "Accent Restaurant & Bar",
        "address": {
            "address1": "429 3rd Ave",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10016",
            "country": "US",
            "state": "NY",
            "display_address": [
                "429 3rd Ave",
                "New York, NY 10016"
            ]
        }
    },
    {
        "bid": "wtfEOjfOWVuugf-SuCC5yA",
        "rating": 4.0,
        "reviews": 425,
        "coordinates": {
            "latitude": 40.7643,
            "longitude": -73.971721
        },
        "name": "Avra Madison",
        "address": {
            "address1": "14 E 60th St",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10022",
            "country": "US",
            "state": "NY",
            "display_address": [
                "14 E 60th St",
                "New York, NY 10022"
            ]
        }
    },
    {
        "bid": "NmzDoAerQUdvMNT90gk4Xw",
        "rating": 4.0,
        "reviews": 46,
        "coordinates": {
            "latitude": 40.75655,
            "longitude": -73.97996
        },
        "name": "Addictive NYC",
        "address": {
            "address1": "19 West 46th St",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10036",
            "country": "US",
            "state": "NY",
            "display_address": [
                "19 West 46th St",
                "New York, NY 10036"
            ]
        }
    },
    {
        "bid": "nXV1FSzW8FnHwNgbTzRlVg",
        "rating": 4.5,
        "reviews": 21,
        "coordinates": {
            "latitude": 40.845256569408,
            "longitude": -73.8657185062766
        },
        "name": "Tasty Choice",
        "address": {
            "address1": "704 Morris Park Ave",
            "address2": "",
            "address3": None,
            "city": "The Bronx",
            "zip_code": "10462",
            "country": "US",
            "state": "NY",
            "display_address": [
                "704 Morris Park Ave",
                "The Bronx, NY 10462"
            ]
        }
    },
    {
        "bid": "gGmdlS8WO_7bFe5_qJGJJg",
        "rating": 4.5,
        "reviews": 170,
        "coordinates": {
            "latitude": 40.704999,
            "longitude": -74.295171
        },
        "name": "Souvlaqueria",
        "address": {
            "address1": "2701 Morris Ave",
            "address2": "",
            "address3": None,
            "city": "Union",
            "zip_code": "07083",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "2701 Morris Ave",
                "Union, NJ 07083"
            ]
        }
    },
    {
        "bid": "jhs35REmv8Yo9-Z27KQJSA",
        "rating": 4.5,
        "reviews": 24,
        "coordinates": {
            "latitude": 40.71156,
            "longitude": -74.01533
        },
        "name": "NAYA - Brookfield Place",
        "address": {
            "address1": "225 Liberty St",
            "address2": "Fl 2",
            "address3": "",
            "city": "New York",
            "zip_code": "10281",
            "country": "US",
            "state": "NY",
            "display_address": [
                "225 Liberty St",
                "Fl 2",
                "New York, NY 10281"
            ]
        }
    },
    {
        "bid": "w4fMUsgKFNV0EbokrRSuYA",
        "rating": 4.0,
        "reviews": 6,
        "coordinates": {
            "latitude": 40.68013401387461,
            "longitude": -73.97780481064486
        },
        "name": "Homemade by Miriam",
        "address": {
            "address1": "81 5th Ave",
            "address2": None,
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11217",
            "country": "US",
            "state": "NY",
            "display_address": [
                "81 5th Ave",
                "Brooklyn, NY 11217"
            ]
        }
    },
    {
        "bid": "fX_sAL8vz2jE4A8r6qG2IQ",
        "rating": 3.5,
        "reviews": 19,
        "coordinates": {
            "latitude": 40.76312,
            "longitude": -73.7704
        },
        "name": "Wild Fig",
        "address": {
            "address1": "41-17 Bell Blvd",
            "address2": "",
            "address3": None,
            "city": "Bayside",
            "zip_code": "11361",
            "country": "US",
            "state": "NY",
            "display_address": [
                "41-17 Bell Blvd",
                "Bayside, NY 11361"
            ]
        }
    },
    {
        "bid": "6emR8SU0UlcKI2o-0yO7Wg",
        "rating": 4.0,
        "reviews": 111,
        "coordinates": {
            "latitude": 40.71972,
            "longitude": -74.00397
        },
        "name": "Antique Garage Tribeca",
        "address": {
            "address1": "313 Church St",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10013",
            "country": "US",
            "state": "NY",
            "display_address": [
                "313 Church St",
                "New York, NY 10013"
            ]
        }
    },
    {
        "bid": "9VLCikK2J1lqgnb9MOI-GQ",
        "rating": 4.0,
        "reviews": 17,
        "coordinates": {
            "latitude": 40.88709,
            "longitude": -73.90465
        },
        "name": "Taste of the Palace",
        "address": {
            "address1": "436 W 238th St",
            "address2": "",
            "address3": None,
            "city": "The Bronx",
            "zip_code": "10463",
            "country": "US",
            "state": "NY",
            "display_address": [
                "436 W 238th St",
                "The Bronx, NY 10463"
            ]
        }
    },
    {
        "bid": "RqCMsa0IuHWhML0BEjW8_w",
        "rating": 4.0,
        "reviews": 782,
        "coordinates": {
            "latitude": 40.7718614234522,
            "longitude": -73.9816256082283
        },
        "name": "Boulud Sud",
        "address": {
            "address1": "20 W 64th St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10023",
            "country": "US",
            "state": "NY",
            "display_address": [
                "20 W 64th St",
                "New York, NY 10023"
            ]
        }
    },
    {
        "bid": "blXVGUTB-4epYW9KFsQJ_g",
        "rating": 4.0,
        "reviews": 598,
        "coordinates": {
            "latitude": 40.7697614,
            "longitude": -73.9881055
        },
        "name": "The Greek Kitchen",
        "address": {
            "address1": "889 10th Ave",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10019",
            "country": "US",
            "state": "NY",
            "display_address": [
                "889 10th Ave",
                "New York, NY 10019"
            ]
        }
    },
    {
        "bid": "eW7kDF_1PT0CBbKA0sjLfA",
        "rating": 4.5,
        "reviews": 265,
        "coordinates": {
            "latitude": 40.74385,
            "longitude": -73.92113
        },
        "name": "Souk El Shater",
        "address": {
            "address1": "43-03 Queens Blvd",
            "address2": "",
            "address3": "",
            "city": "Sunnyside",
            "zip_code": "11104",
            "country": "US",
            "state": "NY",
            "display_address": [
                "43-03 Queens Blvd",
                "Sunnyside, NY 11104"
            ]
        }
    },
    {
        "bid": "Qz5E5sPtETWD3kwEUsBZpw",
        "rating": 4.0,
        "reviews": 535,
        "coordinates": {
            "latitude": 40.753857,
            "longitude": -73.827635
        },
        "name": "Kabul Kabab House",
        "address": {
            "address1": "42-51 Main St",
            "address2": "",
            "address3": "",
            "city": "Flushing",
            "zip_code": "11355",
            "country": "US",
            "state": "NY",
            "display_address": [
                "42-51 Main St",
                "Flushing, NY 11355"
            ]
        }
    },
    {
        "bid": "vYLO6I4-xETxJc5to07GPw",
        "rating": 4.0,
        "reviews": 139,
        "coordinates": {
            "latitude": 40.713658,
            "longitude": -73.957576
        },
        "name": "Ten Hope",
        "address": {
            "address1": "10 Hope St",
            "address2": None,
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11211",
            "country": "US",
            "state": "NY",
            "display_address": [
                "10 Hope St",
                "Brooklyn, NY 11211"
            ]
        }
    },
    {
        "bid": "nksLmvyhPeMDeaA2BPaC4A",
        "rating": 4.0,
        "reviews": 75,
        "coordinates": {
            "latitude": 40.76054,
            "longitude": -73.98099
        },
        "name": "Avra Rockefeller Center",
        "address": {
            "address1": "1271 6th Ave",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10020",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1271 6th Ave",
                "New York, NY 10020"
            ]
        }
    },
    {
        "bid": "IFZ3_d01uflGixWrrD8_gg",
        "rating": 4.0,
        "reviews": 551,
        "coordinates": {
            "latitude": 40.76515,
            "longitude": -73.98813
        },
        "name": "Ariana Afghan Kebab Restaurant",
        "address": {
            "address1": "787 9th Ave",
            "address2": "Apt 3N",
            "address3": "",
            "city": "New York",
            "zip_code": "10019",
            "country": "US",
            "state": "NY",
            "display_address": [
                "787 9th Ave",
                "Apt 3N",
                "New York, NY 10019"
            ]
        }
    },
    {
        "bid": "gRskMlB-wyrJE4YqzOz0Yw",
        "rating": 4.0,
        "reviews": 75,
        "coordinates": {
            "latitude": 40.8930099,
            "longitude": -74.002633
        },
        "name": "Rose Restaurant",
        "address": {
            "address1": "1150 Teaneck Rd",
            "address2": "",
            "address3": "",
            "city": "Teaneck",
            "zip_code": "07666",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "1150 Teaneck Rd",
                "Teaneck, NJ 07666"
            ]
        }
    },
    {
        "bid": "g6R8iwi__IDy8plQy0v9WQ",
        "rating": 3.5,
        "reviews": 745,
        "coordinates": {
            "latitude": 40.7231802723335,
            "longitude": -73.9946175625656
        },
        "name": "Caf\u00e9 Gitane",
        "address": {
            "address1": "242 Mott St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10012",
            "country": "US",
            "state": "NY",
            "display_address": [
                "242 Mott St",
                "New York, NY 10012"
            ]
        }
    },
    {
        "bid": "9gLtCmnBfIziLm9FyPQxBw",
        "rating": 4.5,
        "reviews": 72,
        "coordinates": {
            "latitude": 40.730769,
            "longitude": -74.278412
        },
        "name": "Chutzpah Kitchen",
        "address": {
            "address1": "175 Maplewood Ave",
            "address2": None,
            "address3": "",
            "city": "Maplewood",
            "zip_code": "07040",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "175 Maplewood Ave",
                "Maplewood, NJ 07040"
            ]
        }
    },
    {
        "bid": "_JIidp30qxD3bfpP3DSMTA",
        "rating": 4.0,
        "reviews": 150,
        "coordinates": {
            "latitude": 40.81881,
            "longitude": -73.97747
        },
        "name": "Taverna Veranda",
        "address": {
            "address1": "725 River Rd",
            "address2": "",
            "address3": None,
            "city": "Edgewater",
            "zip_code": "07020",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "725 River Rd",
                "Edgewater, NJ 07020"
            ]
        }
    },
    {
        "bid": "dzI6MzwKbrhJN5dEeUbX0w",
        "rating": 4.0,
        "reviews": 692,
        "coordinates": {
            "latitude": 40.73928,
            "longitude": -73.99605
        },
        "name": "The Hummus & Pita",
        "address": {
            "address1": "585 6th Ave",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10011",
            "country": "US",
            "state": "NY",
            "display_address": [
                "585 6th Ave",
                "New York, NY 10011"
            ]
        }
    },
    {
        "bid": "euqvuleuiGyMffTR23eeYg",
        "rating": 4.5,
        "reviews": 242,
        "coordinates": {
            "latitude": 40.7212932028146,
            "longitude": -73.997309692204
        },
        "name": "Zooba",
        "address": {
            "address1": "100 Kenmare St",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10012",
            "country": "US",
            "state": "NY",
            "display_address": [
                "100 Kenmare St",
                "New York, NY 10012"
            ]
        }
    },
    {
        "bid": "a96iMO6bSkMHOZ4Wrv-Lcg",
        "rating": 4.0,
        "reviews": 52,
        "coordinates": {
            "latitude": 40.7158953,
            "longitude": -73.987321
        },
        "name": "Manousheh Grand",
        "address": {
            "address1": "403 Grand St",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10002",
            "country": "US",
            "state": "NY",
            "display_address": [
                "403 Grand St",
                "New York, NY 10002"
            ]
        }
    },
    {
        "bid": "mBq4lSBxUSqCiHwHUB7-wA",
        "rating": 4.5,
        "reviews": 37,
        "coordinates": {
            "latitude": 40.64569,
            "longitude": -73.97283
        },
        "name": "Cafe Fes",
        "address": {
            "address1": "709 Church Ave",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11218",
            "country": "US",
            "state": "NY",
            "display_address": [
                "709 Church Ave",
                "Brooklyn, NY 11218"
            ]
        }
    },
    {
        "bid": "sBJMzX4aLOQKOFbONQN5Hg",
        "rating": 4.0,
        "reviews": 5,
        "coordinates": {
            "latitude": 40.7536552,
            "longitude": -73.9996342
        },
        "name": "Soom Soom",
        "address": {
            "address1": "398 10th Ave",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10001",
            "country": "US",
            "state": "NY",
            "display_address": [
                "398 10th Ave",
                "New York, NY 10001"
            ]
        }
    },
    {
        "bid": "FVGTLWis-xBCrLmprgVXEg",
        "rating": 4.0,
        "reviews": 189,
        "coordinates": {
            "latitude": 40.7464441,
            "longitude": -73.9802022
        },
        "name": "Miraj Healthy Grill",
        "address": {
            "address1": "120 E 34th St",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10016",
            "country": "US",
            "state": "NY",
            "display_address": [
                "120 E 34th St",
                "New York, NY 10016"
            ]
        }
    },
    {
        "bid": "Vpldj9c3EDzCl0Z5ANfkhg",
        "rating": 4.0,
        "reviews": 19,
        "coordinates": {
            "latitude": 40.854541,
            "longitude": -73.888083
        },
        "name": "Avenue Gyro",
        "address": {
            "address1": "2356 Arthur Ave",
            "address2": "",
            "address3": None,
            "city": "The Bronx",
            "zip_code": "10458",
            "country": "US",
            "state": "NY",
            "display_address": [
                "2356 Arthur Ave",
                "The Bronx, NY 10458"
            ]
        }
    },
    {
        "bid": "8ZedF0hYAvys8tb7ZtHGtQ",
        "rating": 4.0,
        "reviews": 103,
        "coordinates": {
            "latitude": 40.812386,
            "longitude": -73.988309
        },
        "name": "Lulu Lounge & Bistro",
        "address": {
            "address1": "360 Old RIver Rd",
            "address2": None,
            "address3": "",
            "city": "Edgewater",
            "zip_code": "07020",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "360 Old RIver Rd",
                "Edgewater, NJ 07020"
            ]
        }
    },
    {
        "bid": "bNn8eQFyfVecKPczLxXa8w",
        "rating": 4.5,
        "reviews": 158,
        "coordinates": {
            "latitude": 40.82777,
            "longitude": -74.10371
        },
        "name": "Kabob On The Cliff",
        "address": {
            "address1": "66 Park Ave",
            "address2": "",
            "address3": None,
            "city": "Rutherford",
            "zip_code": "07070",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "66 Park Ave",
                "Rutherford, NJ 07070"
            ]
        }
    },
    {
        "bid": "wxfJbez06DzOilWFQ7hYlw",
        "rating": 5.0,
        "reviews": 11,
        "coordinates": {
            "latitude": 40.74688273135135,
            "longitude": -73.58836540234115
        },
        "name": "FandoQ",
        "address": {
            "address1": "1610 Old Country Rd",
            "address2": None,
            "address3": "",
            "city": "Westbury",
            "zip_code": "11590",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1610 Old Country Rd",
                "Westbury, NY 11590"
            ]
        }
    },
    {
        "bid": "lxHKbp0hReRBPZcq4fUUow",
        "rating": 4.0,
        "reviews": 538,
        "coordinates": {
            "latitude": 40.75848,
            "longitude": -73.96612
        },
        "name": "NAYA - Mezze & Grill",
        "address": {
            "address1": "1057 2nd Ave",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10022",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1057 2nd Ave",
                "New York, NY 10022"
            ]
        }
    },
    {
        "bid": "lKgTNYp-oFL_hTddicAjzw",
        "rating": 4.0,
        "reviews": 149,
        "coordinates": {
            "latitude": 40.72192791798716,
            "longitude": -73.99651188343245
        },
        "name": "Cava",
        "address": {
            "address1": "50 Spring St",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10012",
            "country": "US",
            "state": "NY",
            "display_address": [
                "50 Spring St",
                "New York, NY 10012"
            ]
        }
    },
    {
        "bid": "3k9_mItrIx7xQfLbE5dplw",
        "rating": 4.5,
        "reviews": 115,
        "coordinates": {
            "latitude": 40.72675,
            "longitude": -74.07624
        },
        "name": "Samakmak Seafood",
        "address": {
            "address1": "772 Westside Ave",
            "address2": None,
            "address3": "",
            "city": "Jersey City",
            "zip_code": "07306",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "772 Westside Ave",
                "Jersey City, NJ 07306"
            ]
        }
    },
    {
        "bid": "Qw3v8TwKBxpuZ9I27itPvg",
        "rating": 3.5,
        "reviews": 459,
        "coordinates": {
            "latitude": 40.720615,
            "longitude": -73.8456149
        },
        "name": "OBA Mediterranean Gyro & Grill",
        "address": {
            "address1": "70-35 Austin St",
            "address2": "",
            "address3": None,
            "city": "Forest Hills",
            "zip_code": "11375",
            "country": "US",
            "state": "NY",
            "display_address": [
                "70-35 Austin St",
                "Forest Hills, NY 11375"
            ]
        }
    },
    {
        "bid": "tG3ojlIvdbf79RXrO2oGKQ",
        "rating": 4.0,
        "reviews": 42,
        "coordinates": {
            "latitude": 40.7088103,
            "longitude": -74.0108584
        },
        "name": "Gyrohouse NYC",
        "address": {
            "address1": "Cedar St and Broadway",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10003",
            "country": "US",
            "state": "NY",
            "display_address": [
                "Cedar St and Broadway",
                "New York, NY 10003"
            ]
        }
    },
    {
        "bid": "iQpkfCech11N5I6e9ur8Cg",
        "rating": 3.5,
        "reviews": 739,
        "coordinates": {
            "latitude": 40.7713706622218,
            "longitude": -74.01331616192549
        },
        "name": "Molos",
        "address": {
            "address1": "1 Pershing Rd",
            "address2": "",
            "address3": "",
            "city": "Weehawken",
            "zip_code": "07086",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "1 Pershing Rd",
                "Weehawken, NJ 07086"
            ]
        }
    },
    {
        "bid": "hEzQ_p7TcfYaolI_LU4JEQ",
        "rating": 4.5,
        "reviews": 194,
        "coordinates": {
            "latitude": 40.9789750167089,
            "longitude": -74.1227492719528
        },
        "name": "Kabob On The Cliff",
        "address": {
            "address1": "23 Godwin Ave",
            "address2": "",
            "address3": "",
            "city": "Ridgewood",
            "zip_code": "07450",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "23 Godwin Ave",
                "Ridgewood, NJ 07450"
            ]
        }
    },
    {
        "bid": "U1MkaYLx7PL8qZbgi4BsCQ",
        "rating": 4.5,
        "reviews": 200,
        "coordinates": {
            "latitude": 40.7405335797211,
            "longitude": -74.17134963295875
        },
        "name": "The Green Chicpea",
        "address": {
            "address1": "59 Halsey St",
            "address2": "",
            "address3": "",
            "city": "Newark",
            "zip_code": "07102",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "59 Halsey St",
                "Newark, NJ 07102"
            ]
        }
    },
    {
        "bid": "wPx4aNffBizdYmCG-WLKpQ",
        "rating": 4.5,
        "reviews": 526,
        "coordinates": {
            "latitude": 40.77079,
            "longitude": -73.90268
        },
        "name": "Loukoumi Taverna",
        "address": {
            "address1": "45-07 Ditmars Blvd",
            "address2": "",
            "address3": "",
            "city": "Astoria",
            "zip_code": "11105",
            "country": "US",
            "state": "NY",
            "display_address": [
                "45-07 Ditmars Blvd",
                "Astoria, NY 11105"
            ]
        }
    },
    {
        "bid": "7wGbOqUja5xMBYjiSUyX6Q",
        "rating": 4.5,
        "reviews": 26,
        "coordinates": {
            "latitude": 40.75162,
            "longitude": -73.99745
        },
        "name": "NAYA - Moynihan Train Hall",
        "address": {
            "address1": "383 W 31st St",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10001",
            "country": "US",
            "state": "NY",
            "display_address": [
                "383 W 31st St",
                "New York, NY 10001"
            ]
        }
    },
    {
        "bid": "ApbLKC5c3xoYn5XOJ85Y3g",
        "rating": 4.0,
        "reviews": 445,
        "coordinates": {
            "latitude": 40.76254,
            "longitude": -73.926199
        },
        "name": "Aliada",
        "address": {
            "address1": "2919 Broadway",
            "address2": "",
            "address3": "",
            "city": "Astoria",
            "zip_code": "11106",
            "country": "US",
            "state": "NY",
            "display_address": [
                "2919 Broadway",
                "Astoria, NY 11106"
            ]
        }
    },
    {
        "bid": "tXZOJhUUknjTRRo9j4ckZg",
        "rating": 4.0,
        "reviews": 462,
        "coordinates": {
            "latitude": 40.75568479045403,
            "longitude": -73.99444701949656
        },
        "name": "Farida Central Asian Cuisine & Grill - Midtown",
        "address": {
            "address1": "498 9th Ave",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10018",
            "country": "US",
            "state": "NY",
            "display_address": [
                "498 9th Ave",
                "New York, NY 10018"
            ]
        }
    },
    {
        "bid": "iZIJKQeJ7oSXHzxCmUyhZQ",
        "rating": 4.0,
        "reviews": 102,
        "coordinates": {
            "latitude": 40.7427447283466,
            "longitude": -73.9188283760369
        },
        "name": "Sofra Mediterranean Grill",
        "address": {
            "address1": "45-8 46th St",
            "address2": "",
            "address3": None,
            "city": "Sunnyside",
            "zip_code": "11104",
            "country": "US",
            "state": "NY",
            "display_address": [
                "45-8 46th St",
                "Sunnyside, NY 11104"
            ]
        }
    },
    {
        "bid": "MdFV5IBcX-Ni6I4Zy1EqIw",
        "rating": 4.0,
        "reviews": 346,
        "coordinates": {
            "latitude": 40.8028109023738,
            "longitude": -73.9641991912535
        },
        "name": "Marlow Bistro",
        "address": {
            "address1": "1018 Amsterdam Ave",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10025",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1018 Amsterdam Ave",
                "New York, NY 10025"
            ]
        }
    },
    {
        "bid": "0LhrOS_zzu-MlIwmN9ljoA",
        "rating": 4.0,
        "reviews": 89,
        "coordinates": {
            "latitude": 40.85054324050193,
            "longitude": -73.9374584504511
        },
        "name": "Aladdin Grill and Rice",
        "address": {
            "address1": "736 W 181st St",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10033",
            "country": "US",
            "state": "NY",
            "display_address": [
                "736 W 181st St",
                "New York, NY 10033"
            ]
        }
    },
    {
        "bid": "vA0ssUIUXrZLr_hsYpkH6A",
        "rating": 4.0,
        "reviews": 37,
        "coordinates": {
            "latitude": 40.75352,
            "longitude": -74.00012
        },
        "name": "Naked Tomato",
        "address": {
            "address1": "20 Hudson Yards",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10001",
            "country": "US",
            "state": "NY",
            "display_address": [
                "20 Hudson Yards",
                "New York, NY 10001"
            ]
        }
    },
    {
        "bid": "5hyFH-JfrlBhgPDmvelkIA",
        "rating": 3.5,
        "reviews": 220,
        "coordinates": {
            "latitude": 40.778538,
            "longitude": -73.980709
        },
        "name": "North Miznon",
        "address": {
            "address1": "161 W 72nd St",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10023",
            "country": "US",
            "state": "NY",
            "display_address": [
                "161 W 72nd St",
                "New York, NY 10023"
            ]
        }
    },
    {
        "bid": "TS2mqGtNhOzMKcSqJvrBPg",
        "rating": 4.5,
        "reviews": 294,
        "coordinates": {
            "latitude": 40.71907,
            "longitude": -73.94337
        },
        "name": "Ringolevio",
        "address": {
            "address1": "490 Humboldt St",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11222",
            "country": "US",
            "state": "NY",
            "display_address": [
                "490 Humboldt St",
                "Brooklyn, NY 11222"
            ]
        }
    },
    {
        "bid": "DhBhEWMVLDxYF14a1znUvA",
        "rating": 4.0,
        "reviews": 294,
        "coordinates": {
            "latitude": 40.710871611836815,
            "longitude": -73.95371897659477
        },
        "name": "Lighthouse",
        "address": {
            "address1": "145 Borinquen Pl",
            "address2": None,
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11211",
            "country": "US",
            "state": "NY",
            "display_address": [
                "145 Borinquen Pl",
                "Brooklyn, NY 11211"
            ]
        }
    },
    {
        "bid": "CQM9G4AkyeiRI5QJrX43Dg",
        "rating": 4.5,
        "reviews": 6,
        "coordinates": {
            "latitude": 40.12702546302211,
            "longitude": -74.22169448426679
        },
        "name": "Ha\u2019Misada Mediterranean Kitchen",
        "address": {
            "address1": "5325 US 9",
            "address2": "",
            "address3": None,
            "city": "Howell Township",
            "zip_code": "07731",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "5325 US 9",
                "Howell Township, NJ 07731"
            ]
        }
    },
    {
        "bid": "sI4N411hfsslUJnTkEfqWw",
        "rating": 4.0,
        "reviews": 374,
        "coordinates": {
            "latitude": 40.760929,
            "longitude": -73.994827
        },
        "name": "M\u00e9m\u00e9 Mediterranean",
        "address": {
            "address1": "607 10th Ave",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10036",
            "country": "US",
            "state": "NY",
            "display_address": [
                "607 10th Ave",
                "New York, NY 10036"
            ]
        }
    },
    {
        "bid": "XC9sIr46whDBzAhjZ6kOng",
        "rating": 5.0,
        "reviews": 2,
        "coordinates": {
            "latitude": 40.73205,
            "longitude": -74.00215
        },
        "name": "The Salty Snapper",
        "address": {
            "address1": "10 Jones St",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10014",
            "country": "US",
            "state": "NY",
            "display_address": [
                "10 Jones St",
                "New York, NY 10014"
            ]
        }
    },
    {
        "bid": "H87m0azdhuw5uo6Y166uUg",
        "rating": 4.5,
        "reviews": 437,
        "coordinates": {
            "latitude": 40.765385,
            "longitude": -73.978002
        },
        "name": "Loi Estiatorio",
        "address": {
            "address1": "132 W 58th St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10019",
            "country": "US",
            "state": "NY",
            "display_address": [
                "132 W 58th St",
                "New York, NY 10019"
            ]
        }
    },
    {
        "bid": "sgIdJLSXnnMZy2sjm5GUeQ",
        "rating": 3.5,
        "reviews": 238,
        "coordinates": {
            "latitude": 40.721146,
            "longitude": -73.994904
        },
        "name": "Rintintin",
        "address": {
            "address1": "14 Spring St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10012",
            "country": "US",
            "state": "NY",
            "display_address": [
                "14 Spring St",
                "New York, NY 10012"
            ]
        }
    },
    {
        "bid": "Nw6xKTE7HjMO_SczJQSusg",
        "rating": 4.0,
        "reviews": 107,
        "coordinates": {
            "latitude": 40.6599190284601,
            "longitude": -73.9984598379188
        },
        "name": "Taksim",
        "address": {
            "address1": "776 4th Ave",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11232",
            "country": "US",
            "state": "NY",
            "display_address": [
                "776 4th Ave",
                "Brooklyn, NY 11232"
            ]
        }
    },
    {
        "bid": "Lst7wAYH_Dlxocz3nYPnow",
        "rating": 3.5,
        "reviews": 749,
        "coordinates": {
            "latitude": 40.7238251309896,
            "longitude": -74.0032896944427
        },
        "name": "Pera Soho",
        "address": {
            "address1": "54 Thompson St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10012",
            "country": "US",
            "state": "NY",
            "display_address": [
                "54 Thompson St",
                "New York, NY 10012"
            ]
        }
    },
    {
        "bid": "yZx1kHlBHXwEBZLkX0PRhA",
        "rating": 4.5,
        "reviews": 85,
        "coordinates": {
            "latitude": 40.72242,
            "longitude": -73.98397
        },
        "name": "Plado Tasting Bar",
        "address": {
            "address1": "192 E 2nd St",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10009",
            "country": "US",
            "state": "NY",
            "display_address": [
                "192 E 2nd St",
                "New York, NY 10009"
            ]
        }
    },
    {
        "bid": "aGmh7n-HXgcIPs5xFhK2Tw",
        "rating": 4.0,
        "reviews": 69,
        "coordinates": {
            "latitude": 40.7047891351813,
            "longitude": -73.9024043465156
        },
        "name": "Bosna Express",
        "address": {
            "address1": "791 Fairview Ave",
            "address2": "",
            "address3": "",
            "city": "Ridgewood",
            "zip_code": "11385",
            "country": "US",
            "state": "NY",
            "display_address": [
                "791 Fairview Ave",
                "Ridgewood, NY 11385"
            ]
        }
    },
    {
        "bid": "Nxpx7DhlL8pt07DtGZV50w",
        "rating": 4.5,
        "reviews": 4,
        "coordinates": {
            "latitude": 40.714832574405996,
            "longitude": -73.9593933204047
        },
        "name": "Westville",
        "address": {
            "address1": "658 Driggs Ave",
            "address2": None,
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11211",
            "country": "US",
            "state": "NY",
            "display_address": [
                "658 Driggs Ave",
                "Brooklyn, NY 11211"
            ]
        }
    },
    {
        "bid": "Xo1_Fgsczd91kRD_7To0AQ",
        "rating": 5.0,
        "reviews": 16,
        "coordinates": {
            "latitude": 40.72909977484794,
            "longitude": -74.0068805
        },
        "name": "Taste of Greece",
        "address": {
            "address1": "396 Hudson St",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10014",
            "country": "US",
            "state": "NY",
            "display_address": [
                "396 Hudson St",
                "New York, NY 10014"
            ]
        }
    },
    {
        "bid": "WUu7ZxH0y5Fp1G1hLrFxRQ",
        "rating": 4.0,
        "reviews": 375,
        "coordinates": {
            "latitude": 40.8230585448331,
            "longitude": -73.9759795390396
        },
        "name": "Marmaris Cafe",
        "address": {
            "address1": "820 River Rd",
            "address2": "",
            "address3": "",
            "city": "Edgewater",
            "zip_code": "07020",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "820 River Rd",
                "Edgewater, NJ 07020"
            ]
        }
    },
    {
        "bid": "PbxDOYOjYobnHFEH6I8PuQ",
        "rating": 4.5,
        "reviews": 93,
        "coordinates": {
            "latitude": 40.65629,
            "longitude": -74.00807
        },
        "name": "Kotti Berliner D\u00f6ner Kebab",
        "address": {
            "address1": "220 36th St",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11232",
            "country": "US",
            "state": "NY",
            "display_address": [
                "220 36th St",
                "Brooklyn, NY 11232"
            ]
        }
    },
    {
        "bid": "fcZslhOdQJgRdi04UMf0PA",
        "rating": 4.5,
        "reviews": 388,
        "coordinates": {
            "latitude": 40.825389122148536,
            "longitude": -73.98308252883554
        },
        "name": "Cinar Turkish Restaurant",
        "address": {
            "address1": "677 Palisade Ave",
            "address2": "",
            "address3": "",
            "city": "Cliffside Park",
            "zip_code": "07010",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "677 Palisade Ave",
                "Cliffside Park, NJ 07010"
            ]
        }
    },
    {
        "bid": "8BNkZCUfF8h1iCpjk87y5g",
        "rating": 4.0,
        "reviews": 371,
        "coordinates": {
            "latitude": 40.7710007,
            "longitude": -73.9509195
        },
        "name": "Yefsi Estiatorio",
        "address": {
            "address1": "1481 York Ave",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10075",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1481 York Ave",
                "New York, NY 10075"
            ]
        }
    },
    {
        "bid": "MNMUY9w0K8oE7f6wx0qgUQ",
        "rating": 4.5,
        "reviews": 49,
        "coordinates": {
            "latitude": 41.02408,
            "longitude": -74.20972
        },
        "name": "Harmony Mediterranean Grill Restaurant",
        "address": {
            "address1": "842 Franklin Ave",
            "address2": None,
            "address3": "",
            "city": "Franklin Lakes",
            "zip_code": "07417",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "842 Franklin Ave",
                "Franklin Lakes, NJ 07417"
            ]
        }
    },
    {
        "bid": "CvG5Y99Auw8KWryzV1e1PA",
        "rating": 4.0,
        "reviews": 92,
        "coordinates": {
            "latitude": 40.75473,
            "longitude": -73.99739
        },
        "name": "Kyma Hudson Yards",
        "address": {
            "address1": "445 W 35th St",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10001",
            "country": "US",
            "state": "NY",
            "display_address": [
                "445 W 35th St",
                "New York, NY 10001"
            ]
        }
    },
    {
        "bid": "Mj7vjrQOGaBhgjolyjBmZw",
        "rating": 4.5,
        "reviews": 192,
        "coordinates": {
            "latitude": 40.65736,
            "longitude": -73.67204
        },
        "name": "B Greek Kitchen",
        "address": {
            "address1": "323 Merrick Rd",
            "address2": None,
            "address3": "",
            "city": "Lynbrook",
            "zip_code": "11563",
            "country": "US",
            "state": "NY",
            "display_address": [
                "323 Merrick Rd",
                "Lynbrook, NY 11563"
            ]
        }
    },
    {
        "bid": "Jqnm2_8Rt70YYQBhhFLwGQ",
        "rating": 4.0,
        "reviews": 209,
        "coordinates": {
            "latitude": 40.75120261756701,
            "longitude": -73.9812521886868
        },
        "name": "Omar's Mediterranean Cuisine",
        "address": {
            "address1": "20 E 39th St",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10016",
            "country": "US",
            "state": "NY",
            "display_address": [
                "20 E 39th St",
                "New York, NY 10016"
            ]
        }
    },
    {
        "bid": "NQB1u8QCWve7YbV_eYr6Cg",
        "rating": 4.5,
        "reviews": 222,
        "coordinates": {
            "latitude": 40.7248632552638,
            "longitude": -74.3068842217326
        },
        "name": "Pita on Essex",
        "address": {
            "address1": "182 Essex St",
            "address2": "",
            "address3": None,
            "city": "Millburn",
            "zip_code": "07041",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "182 Essex St",
                "Millburn, NJ 07041"
            ]
        }
    },
    {
        "bid": "b8z8IeXsw7DS_SrNHMpFeA",
        "rating": 4.5,
        "reviews": 223,
        "coordinates": {
            "latitude": 40.78223454156657,
            "longitude": -74.01223822279246
        },
        "name": "Hudson Kebab House",
        "address": {
            "address1": "5402 Park Ave",
            "address2": None,
            "address3": "",
            "city": "West New York",
            "zip_code": "07093",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "5402 Park Ave",
                "West New York, NJ 07093"
            ]
        }
    },
    {
        "bid": "B1FK_po7uwvJG5xbZj6n3g",
        "rating": 3.0,
        "reviews": 24,
        "coordinates": {
            "latitude": 40.71897,
            "longitude": -74.00102
        },
        "name": "ilili Box",
        "address": {
            "address1": "265 Canal St",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10013",
            "country": "US",
            "state": "NY",
            "display_address": [
                "265 Canal St",
                "New York, NY 10013"
            ]
        }
    },
    {
        "bid": "FTF1I88dMYi3VmU8e06wKQ",
        "rating": 4.0,
        "reviews": 17,
        "coordinates": {
            "latitude": 40.708085,
            "longitude": -73.898083
        },
        "name": "MUM Mediterranean Cuisine",
        "address": {
            "address1": "66-28 Fresh Pond Rd",
            "address2": None,
            "address3": "",
            "city": "Queens",
            "zip_code": "11385",
            "country": "US",
            "state": "NY",
            "display_address": [
                "66-28 Fresh Pond Rd",
                "Queens, NY 11385"
            ]
        }
    },
    {
        "bid": "Znj2D9i2Rsc_PqaJhE_kFw",
        "rating": 4.0,
        "reviews": 611,
        "coordinates": {
            "latitude": 40.8916,
            "longitude": -74.15694
        },
        "name": "Al Basha Restaurant",
        "address": {
            "address1": "1076 Main St",
            "address2": "",
            "address3": "",
            "city": "Paterson",
            "zip_code": "07503",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "1076 Main St",
                "Paterson, NJ 07503"
            ]
        }
    },
    {
        "bid": "YfPBA6dgcZGvM6E3tCgo0g",
        "rating": 4.0,
        "reviews": 147,
        "coordinates": {
            "latitude": 40.79782,
            "longitude": -74.34158
        },
        "name": "Mezza",
        "address": {
            "address1": "277 Eisenhower Pkwy",
            "address2": None,
            "address3": "",
            "city": "Livingston",
            "zip_code": "07039",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "277 Eisenhower Pkwy",
                "Livingston, NJ 07039"
            ]
        }
    },
    {
        "bid": "ZXiT7FuFAkmjg4pXYxb06A",
        "rating": 3.5,
        "reviews": 365,
        "coordinates": {
            "latitude": 40.73339,
            "longitude": -73.99306
        },
        "name": "Village Taverna",
        "address": {
            "address1": "81 University Pl",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10003",
            "country": "US",
            "state": "NY",
            "display_address": [
                "81 University Pl",
                "New York, NY 10003"
            ]
        }
    },
    {
        "bid": "_DBhCb0k5CM_nEE7FO7QTg",
        "rating": 4.5,
        "reviews": 92,
        "coordinates": {
            "latitude": 40.7185,
            "longitude": -73.9452
        },
        "name": "Pheasant",
        "address": {
            "address1": "445 Graham Ave",
            "address2": None,
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11211",
            "country": "US",
            "state": "NY",
            "display_address": [
                "445 Graham Ave",
                "Brooklyn, NY 11211"
            ]
        }
    },
    {
        "bid": "KFSnzS0kVqKbCdMdtLWDtA",
        "rating": 4.5,
        "reviews": 54,
        "coordinates": {
            "latitude": 40.929816,
            "longitude": -74.034651
        },
        "name": "Kilim Mediterranean Cuisine",
        "address": {
            "address1": "645 Kinderkamack Rd",
            "address2": None,
            "address3": "",
            "city": "River Edge",
            "zip_code": "07661",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "645 Kinderkamack Rd",
                "River Edge, NJ 07661"
            ]
        }
    },
    {
        "bid": "ZG953qDRSrVap2QKm2OG1g",
        "rating": 4.0,
        "reviews": 197,
        "coordinates": {
            "latitude": 40.67194,
            "longitude": -73.9771899
        },
        "name": "Pita Pan",
        "address": {
            "address1": "167 7th Ave",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11215",
            "country": "US",
            "state": "NY",
            "display_address": [
                "167 7th Ave",
                "Brooklyn, NY 11215"
            ]
        }
    },
    {
        "bid": "A86kFwnL4wI3iaYMyv9NLw",
        "rating": 4.5,
        "reviews": 219,
        "coordinates": {
            "latitude": 40.97981,
            "longitude": -74.11874
        },
        "name": "Pardis Persian Grill",
        "address": {
            "address1": "47 E Ridgewood Ave",
            "address2": "",
            "address3": None,
            "city": "Ridgewood",
            "zip_code": "07450",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "47 E Ridgewood Ave",
                "Ridgewood, NJ 07450"
            ]
        }
    },
    {
        "bid": "ZjU9qd-RR55cEEKufmdN5Q",
        "rating": 4.0,
        "reviews": 364,
        "coordinates": {
            "latitude": 40.731616260076336,
            "longitude": -73.98947915459632
        },
        "name": "Cath\u00e9drale Restaurant",
        "address": {
            "address1": "112 E 11th St",
            "address2": "",
            "address3": None,
            "city": "New York City",
            "zip_code": "10003",
            "country": "US",
            "state": "NY",
            "display_address": [
                "112 E 11th St",
                "New York City, NY 10003"
            ]
        }
    },
    {
        "bid": "yhsKjDECX6nmwdg_cECdIA",
        "rating": 4.0,
        "reviews": 10,
        "coordinates": {
            "latitude": 40.7530863748875,
            "longitude": -73.98702132051842
        },
        "name": "NAYA - Garment District",
        "address": {
            "address1": "1400 Broadway",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10018",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1400 Broadway",
                "New York, NY 10018"
            ]
        }
    },
    {
        "bid": "Om6KGbN524K6pu9IkPT0Rg",
        "rating": 4.0,
        "reviews": 218,
        "coordinates": {
            "latitude": 40.69924,
            "longitude": -73.926797
        },
        "name": "Maite",
        "address": {
            "address1": "159 Central Ave",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11221",
            "country": "US",
            "state": "NY",
            "display_address": [
                "159 Central Ave",
                "Brooklyn, NY 11221"
            ]
        }
    },
    {
        "bid": "_HDL2GbVd6OsbBYDUWx8Zg",
        "rating": 4.0,
        "reviews": 218,
        "coordinates": {
            "latitude": 40.74088865307254,
            "longitude": -73.98549001165841
        },
        "name": "Cava",
        "address": {
            "address1": "325 Park Ave S",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10010",
            "country": "US",
            "state": "NY",
            "display_address": [
                "325 Park Ave S",
                "New York, NY 10010"
            ]
        }
    },
    {
        "bid": "vx2JV9juVzSBRGWHOZCTAQ",
        "rating": 4.0,
        "reviews": 583,
        "coordinates": {
            "latitude": 40.7672794037324,
            "longitude": -73.9838727571167
        },
        "name": "ABA Turkish Restaurant",
        "address": {
            "address1": "325 W 57th St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10019",
            "country": "US",
            "state": "NY",
            "display_address": [
                "325 W 57th St",
                "New York, NY 10019"
            ]
        }
    },
    {
        "bid": "8Y5Ytn30Wup9sNf2n99s1A",
        "rating": 3.5,
        "reviews": 729,
        "coordinates": {
            "latitude": 40.7198301,
            "longitude": -74.0000708
        },
        "name": "NOMO Kitchen",
        "address": {
            "address1": "9 Crosby St",
            "address2": "",
            "address3": "NOMO SOHO Hotel",
            "city": "New York",
            "zip_code": "10013",
            "country": "US",
            "state": "NY",
            "display_address": [
                "9 Crosby St",
                "NOMO SOHO Hotel",
                "New York, NY 10013"
            ]
        }
    },
    {
        "bid": "Zj4ckoc80oa2Cy3HRbhfPQ",
        "rating": 3.5,
        "reviews": 311,
        "coordinates": {
            "latitude": 40.755739,
            "longitude": -73.587622
        },
        "name": "Mediterranean Kebab House",
        "address": {
            "address1": "190 Post Ave",
            "address2": "",
            "address3": "",
            "city": "Westbury",
            "zip_code": "11590",
            "country": "US",
            "state": "NY",
            "display_address": [
                "190 Post Ave",
                "Westbury, NY 11590"
            ]
        }
    },
    {
        "bid": "Llx0Vmfl2SD5shBArtmwvQ",
        "rating": 4.5,
        "reviews": 91,
        "coordinates": {
            "latitude": 40.41955483,
            "longitude": -74.08879983
        },
        "name": "Grill 36",
        "address": {
            "address1": "571 NJ-36",
            "address2": None,
            "address3": "",
            "city": "Belford",
            "zip_code": "07718",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "571 NJ-36",
                "Belford, NJ 07718"
            ]
        }
    },
    {
        "bid": "2HZ4UGqSzbb91nWui7VYLg",
        "rating": 4.0,
        "reviews": 298,
        "coordinates": {
            "latitude": 40.7406298582957,
            "longitude": -73.9929678154494
        },
        "name": "Periyali",
        "address": {
            "address1": "35 W 20th St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10011",
            "country": "US",
            "state": "NY",
            "display_address": [
                "35 W 20th St",
                "New York, NY 10011"
            ]
        }
    },
    {
        "bid": "K0UNoqk1PczdaiZfoMRbEA",
        "rating": 4.0,
        "reviews": 248,
        "coordinates": {
            "latitude": 40.887465130647726,
            "longitude": -73.90755915766862
        },
        "name": "Greek Express",
        "address": {
            "address1": "3733 Riverdale Ave",
            "address2": "",
            "address3": "",
            "city": "Bronx",
            "zip_code": "10463",
            "country": "US",
            "state": "NY",
            "display_address": [
                "3733 Riverdale Ave",
                "Bronx, NY 10463"
            ]
        }
    },
    {
        "bid": "1ZstLMeTotRyA8xo8Xa77w",
        "rating": 4.0,
        "reviews": 518,
        "coordinates": {
            "latitude": 40.7219978459617,
            "longitude": -73.9961312441527
        },
        "name": "ta\u00efm mediterranean kitchen - Nolita",
        "address": {
            "address1": "45 Spring St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10012",
            "country": "US",
            "state": "NY",
            "display_address": [
                "45 Spring St",
                "New York, NY 10012"
            ]
        }
    },
    {
        "bid": "mhej-hf7RV5aKNqr5f7NSw",
        "rating": 4.0,
        "reviews": 10,
        "coordinates": {
            "latitude": 40.79675483715128,
            "longitude": -74.35312807964837
        },
        "name": "Cinar Mediterranean",
        "address": {
            "address1": "575 W Mt Pleasant Ave",
            "address2": "",
            "address3": None,
            "city": "Livingston",
            "zip_code": "07039",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "575 W Mt Pleasant Ave",
                "Livingston, NJ 07039"
            ]
        }
    },
    {
        "bid": "GkLBngSr1pik32Pxgmi4GA",
        "rating": 4.0,
        "reviews": 205,
        "coordinates": {
            "latitude": 40.7967797859828,
            "longitude": -74.4756235490738
        },
        "name": "Mediterranean Grill",
        "address": {
            "address1": "119 Morris St",
            "address2": "",
            "address3": None,
            "city": "Morristown",
            "zip_code": "07960",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "119 Morris St",
                "Morristown, NJ 07960"
            ]
        }
    },
    {
        "bid": "-QIPdiq5ILg_EJqdVoCqEA",
        "rating": 4.0,
        "reviews": 643,
        "coordinates": {
            "latitude": 40.76256,
            "longitude": -73.98941
        },
        "name": "Istanbul Kebab House",
        "address": {
            "address1": "712 9th Ave",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10019",
            "country": "US",
            "state": "NY",
            "display_address": [
                "712 9th Ave",
                "New York, NY 10019"
            ]
        }
    },
    {
        "bid": "cB--XW2ULfhSLDYAyd2u2g",
        "rating": 4.0,
        "reviews": 36,
        "coordinates": {
            "latitude": 40.707491,
            "longitude": -73.802458
        },
        "name": "Zaitun Halal",
        "address": {
            "address1": "8769 Parsons Blvd",
            "address2": None,
            "address3": "",
            "city": "Queens",
            "zip_code": "11432",
            "country": "US",
            "state": "NY",
            "display_address": [
                "8769 Parsons Blvd",
                "Queens, NY 11432"
            ]
        }
    },
    {
        "bid": "TxHx1fb8O_MsfQB_ODdTQg",
        "rating": 4.0,
        "reviews": 678,
        "coordinates": {
            "latitude": 40.780044,
            "longitude": -73.98027
        },
        "name": "Hummus Place",
        "address": {
            "address1": "305 Amsterdam Ave",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10023",
            "country": "US",
            "state": "NY",
            "display_address": [
                "305 Amsterdam Ave",
                "New York, NY 10023"
            ]
        }
    },
    {
        "bid": "hzo8OAofK8R80asFSJGmWA",
        "rating": 4.5,
        "reviews": 98,
        "coordinates": {
            "latitude": 40.2168406,
            "longitude": -74.0128671
        },
        "name": "Sami's Mediterranean Street Food",
        "address": {
            "address1": "300 Main St",
            "address2": "",
            "address3": None,
            "city": "Asbury Park",
            "zip_code": "07712",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "300 Main St",
                "Asbury Park, NJ 07712"
            ]
        }
    },
    {
        "bid": "RNOoa_KlIgbDt_7ahVhw1A",
        "rating": 4.0,
        "reviews": 246,
        "coordinates": {
            "latitude": 40.6257479292404,
            "longitude": -74.024335230917
        },
        "name": "Istanbul Bay",
        "address": {
            "address1": "8002 5th Ave",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11209",
            "country": "US",
            "state": "NY",
            "display_address": [
                "8002 5th Ave",
                "Brooklyn, NY 11209"
            ]
        }
    },
    {
        "bid": "0Wtbotu9gVN0uTSHLLovLQ",
        "rating": 4.5,
        "reviews": 201,
        "coordinates": {
            "latitude": 40.7239878,
            "longitude": -74.307399
        },
        "name": "EVOO & Lemon",
        "address": {
            "address1": "45 Main St",
            "address2": "",
            "address3": None,
            "city": "Millburn",
            "zip_code": "07041",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "45 Main St",
                "Millburn, NJ 07041"
            ]
        }
    },
    {
        "bid": "3uJ-wOpTZHd4dsIjMbmYgQ",
        "rating": 4.0,
        "reviews": 439,
        "coordinates": {
            "latitude": 40.7193085,
            "longitude": -74.0095971
        },
        "name": "Thalassa Restaurant",
        "address": {
            "address1": "179 Franklin St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10013",
            "country": "US",
            "state": "NY",
            "display_address": [
                "179 Franklin St",
                "New York, NY 10013"
            ]
        }
    },
    {
        "bid": "wmCzFx6rc0b6ubjIbL9CZA",
        "rating": 5.0,
        "reviews": 10,
        "coordinates": {
            "latitude": 40.85554048419,
            "longitude": -73.9777560532093
        },
        "name": "Mediterranean Gourmet",
        "address": {
            "address1": "490 Main St",
            "address2": None,
            "address3": "",
            "city": "Fort Lee",
            "zip_code": "07024",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "490 Main St",
                "Fort Lee, NJ 07024"
            ]
        }
    },
    {
        "bid": "3FzpZE56CHuipiY_JDT3EA",
        "rating": 3.5,
        "reviews": 296,
        "coordinates": {
            "latitude": 40.76648,
            "longitude": -73.91251
        },
        "name": "Zyara Restaurant",
        "address": {
            "address1": "25-53 Steinway St",
            "address2": "",
            "address3": None,
            "city": "Astoria",
            "zip_code": "11103",
            "country": "US",
            "state": "NY",
            "display_address": [
                "25-53 Steinway St",
                "Astoria, NY 11103"
            ]
        }
    },
    {
        "bid": "fVJUSwTsWqFnarBHCy5Ydw",
        "rating": 4.0,
        "reviews": 295,
        "coordinates": {
            "latitude": 40.7700691,
            "longitude": -73.7933807
        },
        "name": "Kalamaki GR",
        "address": {
            "address1": "2906 172nd St",
            "address2": "",
            "address3": "",
            "city": "Flushing",
            "zip_code": "11358",
            "country": "US",
            "state": "NY",
            "display_address": [
                "2906 172nd St",
                "Flushing, NY 11358"
            ]
        }
    },
    {
        "bid": "TY_552E3MOX3h1n4k48chA",
        "rating": 5.0,
        "reviews": 1,
        "coordinates": {
            "latitude": 40.74806,
            "longitude": -73.98596
        },
        "name": "NAYA",
        "address": {
            "address1": "10 W 33rd St",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10001",
            "country": "US",
            "state": "NY",
            "display_address": [
                "10 W 33rd St",
                "New York, NY 10001"
            ]
        }
    },
    {
        "bid": "zRDWP2wdcxhbtkeibtC90w",
        "rating": 4.5,
        "reviews": 98,
        "coordinates": {
            "latitude": 40.89195,
            "longitude": -74.14243
        },
        "name": "Al-Basha",
        "address": {
            "address1": "387 Crooks Ave",
            "address2": "",
            "address3": None,
            "city": "Paterson",
            "zip_code": "07503",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "387 Crooks Ave",
                "Paterson, NJ 07503"
            ]
        }
    },
    {
        "bid": "eOxGkxi5hEY426ww5qk3GA",
        "rating": 4.0,
        "reviews": 145,
        "coordinates": {
            "latitude": 40.68151,
            "longitude": -73.95591
        },
        "name": "Golda",
        "address": {
            "address1": "504 Franklin Ave",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11238",
            "country": "US",
            "state": "NY",
            "display_address": [
                "504 Franklin Ave",
                "Brooklyn, NY 11238"
            ]
        }
    },
    {
        "bid": "02O4wsjm26kwTC-DqcY43g",
        "rating": 4.0,
        "reviews": 77,
        "coordinates": {
            "latitude": 40.676504373940546,
            "longitude": -74.28998210110811
        },
        "name": "Opa Grill",
        "address": {
            "address1": "550 Blvd",
            "address2": None,
            "address3": "",
            "city": "Kenilworth",
            "zip_code": "07033",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "550 Blvd",
                "Kenilworth, NJ 07033"
            ]
        }
    },
    {
        "bid": "6NOZNW3d3VxkwyjPXVKiwA",
        "rating": 4.5,
        "reviews": 291,
        "coordinates": {
            "latitude": 40.908623,
            "longitude": -74.402723
        },
        "name": "Fasil Mediterranean Restaurant",
        "address": {
            "address1": "308 Wootton St",
            "address2": "Ste 1",
            "address3": "",
            "city": "Boonton",
            "zip_code": "07005",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "308 Wootton St",
                "Ste 1",
                "Boonton, NJ 07005"
            ]
        }
    },
    {
        "bid": "htoeGFLUzB37wQee7A2qRQ",
        "rating": 4.0,
        "reviews": 112,
        "coordinates": {
            "latitude": 40.6933499872684,
            "longitude": -73.9663421
        },
        "name": "The Halal Spot",
        "address": {
            "address1": "474 Myrtle Ave",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11205",
            "country": "US",
            "state": "NY",
            "display_address": [
                "474 Myrtle Ave",
                "Brooklyn, NY 11205"
            ]
        }
    },
    {
        "bid": "TWTRkJZboGubnY-LQKwWPA",
        "rating": 4.0,
        "reviews": 13,
        "coordinates": {
            "latitude": 40.62501,
            "longitude": -73.96184
        },
        "name": "Istanblue Kebab House",
        "address": {
            "address1": "1416 Ave J",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11230",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1416 Ave J",
                "Brooklyn, NY 11230"
            ]
        }
    },
    {
        "bid": "fZlzC9C8-Kx7q_BsIMQbhw",
        "rating": 4.5,
        "reviews": 187,
        "coordinates": {
            "latitude": 40.33163,
            "longitude": -74.306559
        },
        "name": "Grill Point Mediterranean Cuisine and Caf\u00e9",
        "address": {
            "address1": "415 Route 9",
            "address2": None,
            "address3": "",
            "city": "Englishtown",
            "zip_code": "07746",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "415 Route 9",
                "Englishtown, NJ 07746"
            ]
        }
    },
    {
        "bid": "Vr6XgO_ej3NHoSkV3ywYbg",
        "rating": 4.5,
        "reviews": 47,
        "coordinates": {
            "latitude": 40.73922,
            "longitude": -74.17216
        },
        "name": "Pita square",
        "address": {
            "address1": "95 Halsey St",
            "address2": None,
            "address3": "",
            "city": "Newark",
            "zip_code": "07102",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "95 Halsey St",
                "Newark, NJ 07102"
            ]
        }
    },
    {
        "bid": "lwfCl81r5a0mjxDNxNGC9w",
        "rating": 4.0,
        "reviews": 778,
        "coordinates": {
            "latitude": 40.72583,
            "longitude": -73.99299
        },
        "name": "Il Buco",
        "address": {
            "address1": "47 Bond St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10012",
            "country": "US",
            "state": "NY",
            "display_address": [
                "47 Bond St",
                "New York, NY 10012"
            ]
        }
    },
    {
        "bid": "43mQbsfP4ZiCN0z8SM475Q",
        "rating": 5.0,
        "reviews": 290,
        "coordinates": {
            "latitude": 40.6844885741496,
            "longitude": -74.1073497064864
        },
        "name": "Cafe Talya",
        "address": {
            "address1": "218 Ave B",
            "address2": "",
            "address3": "",
            "city": "Bayonne",
            "zip_code": "07002",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "218 Ave B",
                "Bayonne, NJ 07002"
            ]
        }
    },
    {
        "bid": "BEYmqrP1_TC0nhnTGKkkJg",
        "rating": 4.0,
        "reviews": 654,
        "coordinates": {
            "latitude": 40.7769826,
            "longitude": -73.9788067
        },
        "name": "Ella Social",
        "address": {
            "address1": "249 Columbus Ave",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10023",
            "country": "US",
            "state": "NY",
            "display_address": [
                "249 Columbus Ave",
                "New York, NY 10023"
            ]
        }
    },
    {
        "bid": "BPyt7S9TdcR1u571iacg7g",
        "rating": 3.5,
        "reviews": 1653,
        "coordinates": {
            "latitude": 40.752819,
            "longitude": -73.984587
        },
        "name": "The Kati Roll Company",
        "address": {
            "address1": "49 W 39th St",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10018",
            "country": "US",
            "state": "NY",
            "display_address": [
                "49 W 39th St",
                "New York, NY 10018"
            ]
        }
    },
    {
        "bid": "qKEkkVCbTLpmsIZXTjZStA",
        "rating": 4.0,
        "reviews": 70,
        "coordinates": {
            "latitude": 40.779839,
            "longitude": -73.8027676
        },
        "name": "To Steki",
        "address": {
            "address1": "20-14 Francis Lewis Blvd",
            "address2": "",
            "address3": None,
            "city": "Whitestone",
            "zip_code": "11357",
            "country": "US",
            "state": "NY",
            "display_address": [
                "20-14 Francis Lewis Blvd",
                "Whitestone, NY 11357"
            ]
        }
    },
    {
        "bid": "abS0tvhl3R3LyvUE0TM6fA",
        "rating": 4.0,
        "reviews": 44,
        "coordinates": {
            "latitude": 40.6693439358512,
            "longitude": -74.1138902306557
        },
        "name": "Tarboosh",
        "address": {
            "address1": "645 Broadway",
            "address2": "",
            "address3": None,
            "city": "Bayonne",
            "zip_code": "07002",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "645 Broadway",
                "Bayonne, NJ 07002"
            ]
        }
    },
    {
        "bid": "AIrNQUhEfFIWlRxfoPDZng",
        "rating": 5.0,
        "reviews": 24,
        "coordinates": {
            "latitude": 40.677688826887206,
            "longitude": -73.98267563095392
        },
        "name": "Rana Fifteen",
        "address": {
            "address1": "209 4th Ave",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11217",
            "country": "US",
            "state": "NY",
            "display_address": [
                "209 4th Ave",
                "Brooklyn, NY 11217"
            ]
        }
    },
    {
        "bid": "pRH85QftIfFhX549uSelwg",
        "rating": 4.5,
        "reviews": 212,
        "coordinates": {
            "latitude": 40.895431397770906,
            "longitude": -74.50338669588766
        },
        "name": "ALEV Mediterranean Grill",
        "address": {
            "address1": "76 Rte 46",
            "address2": None,
            "address3": None,
            "city": "Rockaway",
            "zip_code": "07866",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "76 Rte 46",
                "Rockaway, NJ 07866"
            ]
        }
    },
    {
        "bid": "WojnO4OcLHo8EBIRgJrGsQ",
        "rating": 3.5,
        "reviews": 162,
        "coordinates": {
            "latitude": 40.7560462224459,
            "longitude": -73.9703554478851
        },
        "name": "Dill & Parsley",
        "address": {
            "address1": "829 3rd Ave",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10022",
            "country": "US",
            "state": "NY",
            "display_address": [
                "829 3rd Ave",
                "New York, NY 10022"
            ]
        }
    },
    {
        "bid": "BsdB6DhfvSq7ZZs-_u0RpA",
        "rating": 4.5,
        "reviews": 855,
        "coordinates": {
            "latitude": 40.60956,
            "longitude": -73.96209
        },
        "name": "Taci\u2019s Beyti",
        "address": {
            "address1": "1953 Coney Island Ave",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11223",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1953 Coney Island Ave",
                "Brooklyn, NY 11223"
            ]
        }
    },
    {
        "bid": "rN6aJdO620g0icLnytl_GA",
        "rating": 5.0,
        "reviews": 12,
        "coordinates": {
            "latitude": 40.672205,
            "longitude": -73.9501378
        },
        "name": "Tammam Cafe",
        "address": {
            "address1": "735 Nostrand Ave",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11216",
            "country": "US",
            "state": "NY",
            "display_address": [
                "735 Nostrand Ave",
                "Brooklyn, NY 11216"
            ]
        }
    },
    {
        "bid": "D1Si3LYL2e_iEIDejZmRhA",
        "rating": 4.5,
        "reviews": 18,
        "coordinates": {
            "latitude": 40.701776,
            "longitude": -73.923065
        },
        "name": "Palmetto",
        "address": {
            "address1": "309 Knickerbocker Ave",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11237",
            "country": "US",
            "state": "NY",
            "display_address": [
                "309 Knickerbocker Ave",
                "Brooklyn, NY 11237"
            ]
        }
    },
    {
        "bid": "Dl_p-042GDITzMHaOrm_xw",
        "rating": 4.5,
        "reviews": 149,
        "coordinates": {
            "latitude": 40.418312,
            "longitude": -74.410951
        },
        "name": "Casablanca",
        "address": {
            "address1": "318 Rues Ln",
            "address2": None,
            "address3": "",
            "city": "East Brunswick",
            "zip_code": "08816",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "318 Rues Ln",
                "East Brunswick, NJ 08816"
            ]
        }
    },
    {
        "bid": "sWu1aVnImXl91Aq-nLpc-Q",
        "rating": 4.5,
        "reviews": 51,
        "coordinates": {
            "latitude": 40.8305159062116,
            "longitude": -74.2059417646501
        },
        "name": "Le Souk - Montclair",
        "address": {
            "address1": "51 Watchung Plz",
            "address2": "",
            "address3": None,
            "city": "Montclair",
            "zip_code": "07042",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "51 Watchung Plz",
                "Montclair, NJ 07042"
            ]
        }
    },
    {
        "bid": "TQva_biHxS_lTgYDi52BlQ",
        "rating": 3.5,
        "reviews": 118,
        "coordinates": {
            "latitude": 40.6925169,
            "longitude": -73.98860726029167
        },
        "name": "CAVA",
        "address": {
            "address1": "345 Adams St",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11201",
            "country": "US",
            "state": "NY",
            "display_address": [
                "345 Adams St",
                "Brooklyn, NY 11201"
            ]
        }
    },
    {
        "bid": "t6klR5QA2oAWhKFZulBnkQ",
        "rating": 3.5,
        "reviews": 413,
        "coordinates": {
            "latitude": 40.7399165772502,
            "longitude": -74.00337108644193
        },
        "name": "Istanbul Turkish Cafe",
        "address": {
            "address1": "310 West 14th St",
            "address2": "",
            "address3": "",
            "city": "NY",
            "zip_code": "10014",
            "country": "US",
            "state": "NY",
            "display_address": [
                "310 West 14th St",
                "NY, NY 10014"
            ]
        }
    },
    {
        "bid": "kKSZT7BJ5VH6hCaGlJ52tg",
        "rating": 4.0,
        "reviews": 836,
        "coordinates": {
            "latitude": 40.765901,
            "longitude": -73.918718
        },
        "name": "Ovelia",
        "address": {
            "address1": "3401 30th Ave",
            "address2": "",
            "address3": "",
            "city": "Astoria",
            "zip_code": "11103",
            "country": "US",
            "state": "NY",
            "display_address": [
                "3401 30th Ave",
                "Astoria, NY 11103"
            ]
        }
    },
    {
        "bid": "NMVRHrkdp68twl4CWo1I5A",
        "rating": 4.0,
        "reviews": 1106,
        "coordinates": {
            "latitude": 40.7597589,
            "longitude": -73.99142128424079
        },
        "name": "Marseille",
        "address": {
            "address1": "630 9th Ave",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10036",
            "country": "US",
            "state": "NY",
            "display_address": [
                "630 9th Ave",
                "New York, NY 10036"
            ]
        }
    },
    {
        "bid": "JT-0_-OqmBLYzEvRhU-__w",
        "rating": 4.5,
        "reviews": 730,
        "coordinates": {
            "latitude": 40.709937,
            "longitude": -73.8483058920307
        },
        "name": "Nick\u2019s Bistro",
        "address": {
            "address1": "104-20 Metropolitan Ave",
            "address2": None,
            "address3": "",
            "city": "Forest Hills",
            "zip_code": "11375",
            "country": "US",
            "state": "NY",
            "display_address": [
                "104-20 Metropolitan Ave",
                "Forest Hills, NY 11375"
            ]
        }
    },
    {
        "bid": "RgEtvACRayQhRPnEs_kkIw",
        "rating": 3.5,
        "reviews": 461,
        "coordinates": {
            "latitude": 40.7545262,
            "longitude": -73.9660484
        },
        "name": "Ethos Gallery 51st",
        "address": {
            "address1": "905 1st Ave",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10022",
            "country": "US",
            "state": "NY",
            "display_address": [
                "905 1st Ave",
                "New York, NY 10022"
            ]
        }
    },
    {
        "bid": "Vx-X9dRYvecFALrpxo2w5g",
        "rating": 4.0,
        "reviews": 142,
        "coordinates": {
            "latitude": 40.6658802,
            "longitude": -74.1170519
        },
        "name": "Teddy's Place",
        "address": {
            "address1": "5 W 25th St",
            "address2": "",
            "address3": "",
            "city": "Bayonne",
            "zip_code": "07002",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "5 W 25th St",
                "Bayonne, NJ 07002"
            ]
        }
    },
    {
        "bid": "Tvxh4vWev1ak-WztOzus-g",
        "rating": 4.0,
        "reviews": 54,
        "coordinates": {
            "latitude": 40.6247,
            "longitude": -74.1448
        },
        "name": "Lebanese Eatery",
        "address": {
            "address1": "1686 Forest Ave",
            "address2": None,
            "address3": None,
            "city": "Staten Island",
            "zip_code": "10302",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1686 Forest Ave",
                "Staten Island, NY 10302"
            ]
        }
    },
    {
        "bid": "CCBy_QYHbTtPrAKHS3pqHg",
        "rating": 5.0,
        "reviews": 293,
        "coordinates": {
            "latitude": 40.7172335,
            "longitude": -73.94504
        },
        "name": "Pita Palace",
        "address": {
            "address1": "413 Graham Ave",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11211",
            "country": "US",
            "state": "NY",
            "display_address": [
                "413 Graham Ave",
                "Brooklyn, NY 11211"
            ]
        }
    },
    {
        "bid": "Vc7mD9Kgghvj0v9_1ffvgQ",
        "rating": 4.0,
        "reviews": 154,
        "coordinates": {
            "latitude": 40.8288126386936,
            "longitude": -73.9865172563261
        },
        "name": "Beyoglu Grill",
        "address": {
            "address1": "703 Anderson Ave",
            "address2": "",
            "address3": "",
            "city": "Cliffside Park",
            "zip_code": "07010",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "703 Anderson Ave",
                "Cliffside Park, NJ 07010"
            ]
        }
    },
    {
        "bid": "W2oXEcatfm7DZqhmjHE2DQ",
        "rating": 4.5,
        "reviews": 65,
        "coordinates": {
            "latitude": 40.7479623,
            "longitude": -73.7613954
        },
        "name": "Sevan Restaurant & Catering",
        "address": {
            "address1": "21607 Horace Harding Expy",
            "address2": "",
            "address3": "",
            "city": "Oakland Gardens",
            "zip_code": "11364",
            "country": "US",
            "state": "NY",
            "display_address": [
                "21607 Horace Harding Expy",
                "Oakland Gardens, NY 11364"
            ]
        }
    },
    {
        "bid": "l_BiOLZXNcV5HVWeDwXN4g",
        "rating": 4.5,
        "reviews": 12,
        "coordinates": {
            "latitude": 40.694001929623546,
            "longitude": -73.98495549543546
        },
        "name": "Naya - Brooklyn",
        "address": {
            "address1": "15 MetroTech Ctr",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11201",
            "country": "US",
            "state": "NY",
            "display_address": [
                "15 MetroTech Ctr",
                "Brooklyn, NY 11201"
            ]
        }
    },
    {
        "bid": "q7U2GCMWIZxIqWeMDml0LQ",
        "rating": 4.5,
        "reviews": 388,
        "coordinates": {
            "latitude": 40.76053,
            "longitude": -73.98992
        },
        "name": "Pure Ktchn",
        "address": {
            "address1": "352 West 46th St",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10036",
            "country": "US",
            "state": "NY",
            "display_address": [
                "352 West 46th St",
                "New York, NY 10036"
            ]
        }
    },
    {
        "bid": "BaTKfMmDlXpz4vGc0VqMEw",
        "rating": 3.5,
        "reviews": 27,
        "coordinates": {
            "latitude": 40.7335,
            "longitude": -73.99907
        },
        "name": "Shmon\u00e9",
        "address": {
            "address1": "61 W 8th St",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10011",
            "country": "US",
            "state": "NY",
            "display_address": [
                "61 W 8th St",
                "New York, NY 10011"
            ]
        }
    },
    {
        "bid": "eVkDtKkyw0FLsthMuQtVjg",
        "rating": 3.5,
        "reviews": 72,
        "coordinates": {
            "latitude": 40.705665,
            "longitude": -74.0088055
        },
        "name": "Cava",
        "address": {
            "address1": "63 Wall St",
            "address2": None,
            "address3": None,
            "city": "New York",
            "zip_code": "10005",
            "country": "US",
            "state": "NY",
            "display_address": [
                "63 Wall St",
                "New York, NY 10005"
            ]
        }
    },
    {
        "bid": "xEnNFXtMLDF5kZDxfaCJgA",
        "rating": 4.0,
        "reviews": 10284,
        "coordinates": {
            "latitude": 40.761861,
            "longitude": -73.979306
        },
        "name": "The Halal Guys",
        "address": {
            "address1": "W 53rd Street And 6th Ave",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10019",
            "country": "US",
            "state": "NY",
            "display_address": [
                "W 53rd Street And 6th Ave",
                "New York, NY 10019"
            ]
        }
    },
    {
        "bid": "vNPFbYK3KeplZHr_0rRfSw",
        "rating": 4.5,
        "reviews": 87,
        "coordinates": {
            "latitude": 40.801181,
            "longitude": -73.9648225
        },
        "name": "Zaad Restaurants",
        "address": {
            "address1": "963 Amsterdam Ave",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10025",
            "country": "US",
            "state": "NY",
            "display_address": [
                "963 Amsterdam Ave",
                "New York, NY 10025"
            ]
        }
    },
    {
        "bid": "bR2IOg3D1l3G4TzKYbEwfA",
        "rating": 3.5,
        "reviews": 45,
        "coordinates": {
            "latitude": 40.6665,
            "longitude": -73.98174
        },
        "name": "ta\u00efm mediterranean kitchen - Park Slope",
        "address": {
            "address1": "341 7th Ave",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11215",
            "country": "US",
            "state": "NY",
            "display_address": [
                "341 7th Ave",
                "Brooklyn, NY 11215"
            ]
        }
    },
    {
        "bid": "loSweBJLwWJsIYf3H2_LVg",
        "rating": 5.0,
        "reviews": 4,
        "coordinates": {
            "latitude": 40.76655,
            "longitude": -73.92031
        },
        "name": "Nisi Estiatorio",
        "address": {
            "address1": "32-07 30th Ave",
            "address2": "",
            "address3": None,
            "city": "Queens",
            "zip_code": "11102",
            "country": "US",
            "state": "NY",
            "display_address": [
                "32-07 30th Ave",
                "Queens, NY 11102"
            ]
        }
    },
    {
        "bid": "fz2iLhfd1W9hQcbx106CmA",
        "rating": 5.0,
        "reviews": 2,
        "coordinates": {
            "latitude": 40.881970809568905,
            "longitude": -73.8816575
        },
        "name": "Halal Grill Bros",
        "address": {
            "address1": "3476 Jerome Ave",
            "address2": "",
            "address3": None,
            "city": "The Bronx",
            "zip_code": "10467",
            "country": "US",
            "state": "NY",
            "display_address": [
                "3476 Jerome Ave",
                "The Bronx, NY 10467"
            ]
        }
    },
    {
        "bid": "mw-2zyzteB8CAnkWzNZqXw",
        "rating": 4.0,
        "reviews": 284,
        "coordinates": {
            "latitude": 40.74356,
            "longitude": -73.95412
        },
        "name": "Vernon Grille",
        "address": {
            "address1": "48-20 Vernon Blvd",
            "address2": None,
            "address3": "",
            "city": "Long Island City",
            "zip_code": "11101",
            "country": "US",
            "state": "NY",
            "display_address": [
                "48-20 Vernon Blvd",
                "Long Island City, NY 11101"
            ]
        }
    },
    {
        "bid": "uL709qg0IGe4KsNZk_AjxQ",
        "rating": 4.5,
        "reviews": 162,
        "coordinates": {
            "latitude": 40.7159199,
            "longitude": -73.9558
        },
        "name": "Lion's Milk",
        "address": {
            "address1": "104 Roebling St",
            "address2": None,
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11211",
            "country": "US",
            "state": "NY",
            "display_address": [
                "104 Roebling St",
                "Brooklyn, NY 11211"
            ]
        }
    },
    {
        "bid": "_EUAkkC5oKm4sClY4hlbig",
        "rating": 5.0,
        "reviews": 1,
        "coordinates": {
            "latitude": 40.73391315565979,
            "longitude": -73.9888773443734
        },
        "name": "Pita Yeero",
        "address": {
            "address1": "124 E 14th St",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10003",
            "country": "US",
            "state": "NY",
            "display_address": [
                "124 E 14th St",
                "New York, NY 10003"
            ]
        }
    },
    {
        "bid": "BE0Qp1dhAlclB45kD_8C1g",
        "rating": 3.5,
        "reviews": 168,
        "coordinates": {
            "latitude": 40.73959241186023,
            "longitude": -73.789946741312
        },
        "name": "Shirazi Kabob House",
        "address": {
            "address1": "183-10 Horace Harding Expy",
            "address2": None,
            "address3": None,
            "city": "Fresh Meadows",
            "zip_code": "11365",
            "country": "US",
            "state": "NY",
            "display_address": [
                "183-10 Horace Harding Expy",
                "Fresh Meadows, NY 11365"
            ]
        }
    },
    {
        "bid": "n_KosOPSHS81Yq0D6X3peQ",
        "rating": 4.0,
        "reviews": 239,
        "coordinates": {
            "latitude": 40.81452,
            "longitude": -73.95966
        },
        "name": "Falafel On Broadway",
        "address": {
            "address1": "3151 Broadway",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10027",
            "country": "US",
            "state": "NY",
            "display_address": [
                "3151 Broadway",
                "New York, NY 10027"
            ]
        }
    },
    {
        "bid": "AZlESP2AjvhafvMZH7jStg",
        "rating": 4.0,
        "reviews": 22,
        "coordinates": {
            "latitude": 40.623369312122264,
            "longitude": -74.03140005490675
        },
        "name": "Istanbul Park",
        "address": {
            "address1": "8602 3rd Ave",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11209",
            "country": "US",
            "state": "NY",
            "display_address": [
                "8602 3rd Ave",
                "Brooklyn, NY 11209"
            ]
        }
    },
    {
        "bid": "6LJl5ZhPMmGZ5F1oe-6kEw",
        "rating": 4.5,
        "reviews": 119,
        "coordinates": {
            "latitude": 40.75119,
            "longitude": -73.97436
        },
        "name": "Le Botaniste",
        "address": {
            "address1": "666 Third Ave",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10017",
            "country": "US",
            "state": "NY",
            "display_address": [
                "666 Third Ave",
                "New York, NY 10017"
            ]
        }
    },
    {
        "bid": "x6_1vzeCH9YvbvIBmSr2iA",
        "rating": 4.0,
        "reviews": 258,
        "coordinates": {
            "latitude": 40.71966,
            "longitude": -73.96046
        },
        "name": "DOC Wine Bar",
        "address": {
            "address1": "83 N 7th St",
            "address2": None,
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11249",
            "country": "US",
            "state": "NY",
            "display_address": [
                "83 N 7th St",
                "Brooklyn, NY 11249"
            ]
        }
    },
    {
        "bid": "rI2AEfnQVvnFoWn2De96Qg",
        "rating": 4.0,
        "reviews": 354,
        "coordinates": {
            "latitude": 40.6542780937095,
            "longitude": -73.8390364032719
        },
        "name": "Saffron Restaurant",
        "address": {
            "address1": "16150 Cross Bay Blvd",
            "address2": "",
            "address3": "",
            "city": "Howard Beach",
            "zip_code": "11414",
            "country": "US",
            "state": "NY",
            "display_address": [
                "16150 Cross Bay Blvd",
                "Howard Beach, NY 11414"
            ]
        }
    },
    {
        "bid": "lMyJ9lrwRddpsOR_WeMSww",
        "rating": 4.0,
        "reviews": 553,
        "coordinates": {
            "latitude": 40.7212996,
            "longitude": -74.0457456
        },
        "name": "Gypsy Grill",
        "address": {
            "address1": "187 Newark Ave",
            "address2": "",
            "address3": "",
            "city": "Jersey City",
            "zip_code": "07302",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "187 Newark Ave",
                "Jersey City, NJ 07302"
            ]
        }
    },
    {
        "bid": "ECdicKREKfRrF3dTyJ73wg",
        "rating": 4.5,
        "reviews": 87,
        "coordinates": {
            "latitude": 40.65639,
            "longitude": -74.304
        },
        "name": "Oasis Restaurant",
        "address": {
            "address1": "21 N Union Ave",
            "address2": None,
            "address3": "",
            "city": "Cranford",
            "zip_code": "07016",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "21 N Union Ave",
                "Cranford, NJ 07016"
            ]
        }
    },
    {
        "bid": "cZ4TwM7VnDhgNB6kapneSg",
        "rating": 3.5,
        "reviews": 1092,
        "coordinates": {
            "latitude": 40.73404,
            "longitude": -74.0083499
        },
        "name": "Casa La Femme",
        "address": {
            "address1": "140 Charles St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10014",
            "country": "US",
            "state": "NY",
            "display_address": [
                "140 Charles St",
                "New York, NY 10014"
            ]
        }
    },
    {
        "bid": "f-VGR1nNnyBXL7Iknh7Anw",
        "rating": 4.5,
        "reviews": 170,
        "coordinates": {
            "latitude": 40.7663,
            "longitude": -74.41962
        },
        "name": "Grillera Mediterranean Cuisine",
        "address": {
            "address1": "91 Park Ave",
            "address2": "",
            "address3": "",
            "city": "Madison",
            "zip_code": "07940",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "91 Park Ave",
                "Madison, NJ 07940"
            ]
        }
    },
    {
        "bid": "xbzUfm4PjqyKMg1eZTLo6A",
        "rating": 3.5,
        "reviews": 8,
        "coordinates": {
            "latitude": 40.7422335269512,
            "longitude": -74.1735648249168
        },
        "name": "Halal Mama",
        "address": {
            "address1": "160 University Ave",
            "address2": "",
            "address3": None,
            "city": "Newark",
            "zip_code": "07102",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "160 University Ave",
                "Newark, NJ 07102"
            ]
        }
    },
    {
        "bid": "AzHbXpKevHaeHPhJHE8UnQ",
        "rating": 4.0,
        "reviews": 148,
        "coordinates": {
            "latitude": 40.767964,
            "longitude": -73.911346
        },
        "name": "Little Morocco",
        "address": {
            "address1": "2439 Steinway St",
            "address2": "",
            "address3": "",
            "city": "Astoria",
            "zip_code": "11103",
            "country": "US",
            "state": "NY",
            "display_address": [
                "2439 Steinway St",
                "Astoria, NY 11103"
            ]
        }
    },
    {
        "bid": "KpBfFpjzsGvvqAzCasVW0g",
        "rating": 3.5,
        "reviews": 1366,
        "coordinates": {
            "latitude": 40.7353962496717,
            "longitude": -74.0031888223197
        },
        "name": "Extra Virgin",
        "address": {
            "address1": "259 W 4th St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10014",
            "country": "US",
            "state": "NY",
            "display_address": [
                "259 W 4th St",
                "New York, NY 10014"
            ]
        }
    },
    {
        "bid": "CfJvKDmmsj7zHX5J077byA",
        "rating": 4.5,
        "reviews": 183,
        "coordinates": {
            "latitude": 40.6322,
            "longitude": -73.73849
        },
        "name": "Lucky Boy Restaurant",
        "address": {
            "address1": "636 Rockaway Tpke",
            "address2": "",
            "address3": "",
            "city": "Lawrence",
            "zip_code": "11559",
            "country": "US",
            "state": "NY",
            "display_address": [
                "636 Rockaway Tpke",
                "Lawrence, NY 11559"
            ]
        }
    },
    {
        "bid": "XwxGe5lDUtrZTr37JU6z-Q",
        "rating": 4.0,
        "reviews": 35,
        "coordinates": {
            "latitude": 40.8086721255731,
            "longitude": -73.9520373567939
        },
        "name": "Sido Grill",
        "address": {
            "address1": "2288 Frederick Douglass Blvd",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10027",
            "country": "US",
            "state": "NY",
            "display_address": [
                "2288 Frederick Douglass Blvd",
                "New York, NY 10027"
            ]
        }
    },
    {
        "bid": "yo_WAOnE2pPHCQduq_V_ZA",
        "rating": 3.5,
        "reviews": 212,
        "coordinates": {
            "latitude": 40.8054568,
            "longitude": -73.96429
        },
        "name": "Symposium",
        "address": {
            "address1": "544 W 113th St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10025",
            "country": "US",
            "state": "NY",
            "display_address": [
                "544 W 113th St",
                "New York, NY 10025"
            ]
        }
    },
    {
        "bid": "wzbta6vcz3YNLZDhgrzy1w",
        "rating": 3.5,
        "reviews": 427,
        "coordinates": {
            "latitude": 40.75434,
            "longitude": -73.96851
        },
        "name": "Sip Sak",
        "address": {
            "address1": "928 2nd Ave",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10022",
            "country": "US",
            "state": "NY",
            "display_address": [
                "928 2nd Ave",
                "New York, NY 10022"
            ]
        }
    },
    {
        "bid": "A0GVSLdYCEIr-yLZnqhJkg",
        "rating": 4.5,
        "reviews": 281,
        "coordinates": {
            "latitude": 40.731202,
            "longitude": -73.859833
        },
        "name": "Marani",
        "address": {
            "address1": "97-26 63rd Rd",
            "address2": "",
            "address3": "",
            "city": "Rego Park",
            "zip_code": "11374",
            "country": "US",
            "state": "NY",
            "display_address": [
                "97-26 63rd Rd",
                "Rego Park, NY 11374"
            ]
        }
    },
    {
        "bid": "qmz0EiyIss8qkiWFYn94aw",
        "rating": 4.5,
        "reviews": 4,
        "coordinates": {
            "latitude": 40.70050811767578,
            "longitude": -73.9001693725586
        },
        "name": "Saint Pita",
        "address": {
            "address1": None,
            "address2": None,
            "address3": None,
            "city": "Ridgewood",
            "zip_code": "11385",
            "country": "US",
            "state": "NY",
            "display_address": [
                "Ridgewood, NY 11385"
            ]
        }
    },
    {
        "bid": "T4C0dk_umVQ1ntSPn-ruvg",
        "rating": 4.0,
        "reviews": 46,
        "coordinates": {
            "latitude": 40.65895,
            "longitude": -74.1228299
        },
        "name": "A-1 Grill",
        "address": {
            "address1": "351 Broadway",
            "address2": "",
            "address3": None,
            "city": "Bayonne",
            "zip_code": "07002",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "351 Broadway",
                "Bayonne, NJ 07002"
            ]
        }
    },
    {
        "bid": "MsHq3T338AoyWmfpC_4pNw",
        "rating": 5.0,
        "reviews": 9,
        "coordinates": {
            "latitude": 40.8632823,
            "longitude": -74.0896315
        },
        "name": "Pidde",
        "address": {
            "address1": "115 Terhune Ave",
            "address2": None,
            "address3": "",
            "city": "Lodi",
            "zip_code": "07644",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "115 Terhune Ave",
                "Lodi, NJ 07644"
            ]
        }
    },
    {
        "bid": "cSYjsFxahSmWpZ75gotRsw",
        "rating": 4.0,
        "reviews": 4,
        "coordinates": {
            "latitude": 40.579615362923526,
            "longitude": -73.9724933787383
        },
        "name": "Sahara Turkish Grill",
        "address": {
            "address1": "530 Neptune Ave",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11224",
            "country": "US",
            "state": "NY",
            "display_address": [
                "530 Neptune Ave",
                "Brooklyn, NY 11224"
            ]
        }
    },
    {
        "bid": "oOiaIo6fvUW_SMqGs3dgew",
        "rating": 4.5,
        "reviews": 16,
        "coordinates": {
            "latitude": 40.767695,
            "longitude": -73.9642
        },
        "name": "The Roadside Grill",
        "address": {
            "address1": "68th St and Lexington Ave",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10021",
            "country": "US",
            "state": "NY",
            "display_address": [
                "68th St and Lexington Ave",
                "New York, NY 10021"
            ]
        }
    },
    {
        "bid": "l74csFd6zx4vj5lneHJSSQ",
        "rating": 4.0,
        "reviews": 174,
        "coordinates": {
            "latitude": 40.66123,
            "longitude": -73.96057
        },
        "name": "Kulushkat",
        "address": {
            "address1": "1137B Washington Ave",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11225",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1137B Washington Ave",
                "Brooklyn, NY 11225"
            ]
        }
    },
    {
        "bid": "adVj40JtqlP9ZS64ZY0SsQ",
        "rating": 4.5,
        "reviews": 440,
        "coordinates": {
            "latitude": 40.8425165,
            "longitude": -74.2078669
        },
        "name": "Mishmish Cafe",
        "address": {
            "address1": "631 Valley Rd",
            "address2": None,
            "address3": "",
            "city": "Montclair",
            "zip_code": "07043",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "631 Valley Rd",
                "Montclair, NJ 07043"
            ]
        }
    },
    {
        "bid": "c7JWprE_D3Hc8MhDLOPscA",
        "rating": 4.5,
        "reviews": 163,
        "coordinates": {
            "latitude": 40.795101,
            "longitude": -73.69853
        },
        "name": "Herb&Olive",
        "address": {
            "address1": "172 Plandome Rd",
            "address2": None,
            "address3": None,
            "city": "Manhasset",
            "zip_code": "11030",
            "country": "US",
            "state": "NY",
            "display_address": [
                "172 Plandome Rd",
                "Manhasset, NY 11030"
            ]
        }
    },
    {
        "bid": "vGQRmWKrR_x-JAyeCT5F1A",
        "rating": 4.0,
        "reviews": 204,
        "coordinates": {
            "latitude": 40.826335,
            "longitude": -73.943519
        },
        "name": "Tsion Cafe",
        "address": {
            "address1": "763 St Nicholas Ave",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10031",
            "country": "US",
            "state": "NY",
            "display_address": [
                "763 St Nicholas Ave",
                "New York, NY 10031"
            ]
        }
    },
    {
        "bid": "IQYQz1svn6HxgnUP6wCTBw",
        "rating": 4.0,
        "reviews": 50,
        "coordinates": {
            "latitude": 40.7372072,
            "longitude": -74.1728457
        },
        "name": "Turkish Pita Place",
        "address": {
            "address1": "150 Halsey St",
            "address2": None,
            "address3": "",
            "city": "Newark",
            "zip_code": "07102",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "150 Halsey St",
                "Newark, NJ 07102"
            ]
        }
    },
    {
        "bid": "Nzalb1MxWXe0LC41POy4Qw",
        "rating": 4.0,
        "reviews": 236,
        "coordinates": {
            "latitude": 40.76563,
            "longitude": -73.95711
        },
        "name": "Yia Yia's- Homemade Greek Food",
        "address": {
            "address1": "404 E 69th St",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10021",
            "country": "US",
            "state": "NY",
            "display_address": [
                "404 E 69th St",
                "New York, NY 10021"
            ]
        }
    },
    {
        "bid": "rz5C7UpA338OKU_LCQS3rg",
        "rating": 4.0,
        "reviews": 56,
        "coordinates": {
            "latitude": 40.679426,
            "longitude": -73.863661
        },
        "name": "Momo's Mediterranean Grill",
        "address": {
            "address1": "25 & 29 101st Ave",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11208",
            "country": "US",
            "state": "NY",
            "display_address": [
                "25 & 29 101st Ave",
                "Brooklyn, NY 11208"
            ]
        }
    },
    {
        "bid": "ciTxjagt7NYojaBjOqwKSQ",
        "rating": 4.5,
        "reviews": 235,
        "coordinates": {
            "latitude": 40.84203896421774,
            "longitude": -73.70739799792128
        },
        "name": "Bosphorus Cafe Grill",
        "address": {
            "address1": "138 Shore Rd",
            "address2": "",
            "address3": "",
            "city": "Port Washington",
            "zip_code": "11050",
            "country": "US",
            "state": "NY",
            "display_address": [
                "138 Shore Rd",
                "Port Washington, NY 11050"
            ]
        }
    },
    {
        "bid": "uNGGMtJj4BMlLG5E44YgRA",
        "rating": 5.0,
        "reviews": 9,
        "coordinates": {
            "latitude": 40.73746,
            "longitude": -74.03203
        },
        "name": "D\u00f6ner Xpress",
        "address": {
            "address1": "153 1st St",
            "address2": None,
            "address3": None,
            "city": "Hoboken",
            "zip_code": "07030",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "153 1st St",
                "Hoboken, NJ 07030"
            ]
        }
    },
    {
        "bid": "rZxnzjyGdvifVbfSKHGh1w",
        "rating": 4.5,
        "reviews": 8,
        "coordinates": {
            "latitude": 40.75911745849965,
            "longitude": -73.97952700204347
        },
        "name": "Samesa",
        "address": {
            "address1": "30 Rockefeller Plz",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10112",
            "country": "US",
            "state": "NY",
            "display_address": [
                "30 Rockefeller Plz",
                "New York, NY 10112"
            ]
        }
    },
    {
        "bid": "EaBfDaigEFng3HRKlfH88A",
        "rating": 4.5,
        "reviews": 275,
        "coordinates": {
            "latitude": 40.81584,
            "longitude": -73.991
        },
        "name": "Dayi'nin Yeri",
        "address": {
            "address1": "333 Palisade Ave",
            "address2": "",
            "address3": "",
            "city": "Cliffside Park",
            "zip_code": "07010",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "333 Palisade Ave",
                "Cliffside Park, NJ 07010"
            ]
        }
    },
    {
        "bid": "WbbDoqux9A1shUIOkQ10rA",
        "rating": 4.5,
        "reviews": 12,
        "coordinates": {
            "latitude": 41.077311102621834,
            "longitude": -73.85807867116358
        },
        "name": "Pita House",
        "address": {
            "address1": "27 N Broadway",
            "address2": "",
            "address3": None,
            "city": "Tarrytown",
            "zip_code": "10591",
            "country": "US",
            "state": "NY",
            "display_address": [
                "27 N Broadway",
                "Tarrytown, NY 10591"
            ]
        }
    },
    {
        "bid": "HYW2O2qycmFiGUNt_TlyPA",
        "rating": 4.0,
        "reviews": 263,
        "coordinates": {
            "latitude": 40.774947,
            "longitude": -73.911846
        },
        "name": "Shawarmania",
        "address": {
            "address1": "22-49 31st St",
            "address2": "",
            "address3": "",
            "city": "Astoria",
            "zip_code": "11105",
            "country": "US",
            "state": "NY",
            "display_address": [
                "22-49 31st St",
                "Astoria, NY 11105"
            ]
        }
    },
    {
        "bid": "SzH79XjUPoTYBnE3dybRsw",
        "rating": 4.0,
        "reviews": 141,
        "coordinates": {
            "latitude": 40.65287,
            "longitude": -73.97631
        },
        "name": "Della",
        "address": {
            "address1": "1238 Prospect Ave",
            "address2": "",
            "address3": "Reeve Place",
            "city": "Brooklyn",
            "zip_code": "11218",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1238 Prospect Ave",
                "Reeve Place",
                "Brooklyn, NY 11218"
            ]
        }
    },
    {
        "bid": "vgETsjEQ_gGMq70y9-AS1g",
        "rating": 4.5,
        "reviews": 38,
        "coordinates": {
            "latitude": 40.8594879,
            "longitude": -73.6212532
        },
        "name": "Sami's Kabab House",
        "address": {
            "address1": "284 Glen St",
            "address2": None,
            "address3": None,
            "city": "Glen Cove",
            "zip_code": "11542",
            "country": "US",
            "state": "NY",
            "display_address": [
                "284 Glen St",
                "Glen Cove, NY 11542"
            ]
        }
    },
    {
        "bid": "H_UFhvanxK2xk2a_iqPUmw",
        "rating": 5.0,
        "reviews": 12,
        "coordinates": {
            "latitude": 40.62522200000001,
            "longitude": -74.13644030273211
        },
        "name": "Shawafel House",
        "address": {
            "address1": "1419 Forest Ave",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10302",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1419 Forest Ave",
                "New York, NY 10302"
            ]
        }
    },
    {
        "bid": "T5_Opljb8Sal39-mLSskoA",
        "rating": 4.0,
        "reviews": 467,
        "coordinates": {
            "latitude": 40.798068,
            "longitude": -73.665939
        },
        "name": "Limani",
        "address": {
            "address1": "1043 Northern Blvd",
            "address2": "",
            "address3": "",
            "city": "Roslyn",
            "zip_code": "11576",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1043 Northern Blvd",
                "Roslyn, NY 11576"
            ]
        }
    },
    {
        "bid": "aTFkjo0scqmOgsFF5kuGXg",
        "rating": 4.0,
        "reviews": 493,
        "coordinates": {
            "latitude": 40.7331,
            "longitude": -73.99596
        },
        "name": "Claudette",
        "address": {
            "address1": "24 5th Ave",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10011",
            "country": "US",
            "state": "NY",
            "display_address": [
                "24 5th Ave",
                "New York, NY 10011"
            ]
        }
    },
    {
        "bid": "iCnGXNAAuXM6PGrOPdVxlg",
        "rating": 4.5,
        "reviews": 29,
        "coordinates": {
            "latitude": 40.39489,
            "longitude": -74.56188
        },
        "name": "Kapadokya Mediterranean Grill",
        "address": {
            "address1": "4071 US-1",
            "address2": None,
            "address3": "",
            "city": "Monmouth Junction",
            "zip_code": "08852",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "4071 US-1",
                "Monmouth Junction, NJ 08852"
            ]
        }
    },
    {
        "bid": "0NeZwlGoUQ3WCA35jmdUPw",
        "rating": 4.5,
        "reviews": 458,
        "coordinates": {
            "latitude": 40.656101,
            "longitude": -74.3041573
        },
        "name": "Ambeli Greek Taverna",
        "address": {
            "address1": "29 N Union Ave",
            "address2": "",
            "address3": "",
            "city": "Cranford",
            "zip_code": "07016",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "29 N Union Ave",
                "Cranford, NJ 07016"
            ]
        }
    },
    {
        "bid": "PiDidGDx15RYgiQFKeFZSg",
        "rating": 4.5,
        "reviews": 414,
        "coordinates": {
            "latitude": 40.66476,
            "longitude": -73.98648
        },
        "name": "Athena Mediterranean Cuisine",
        "address": {
            "address1": "535 6th Ave",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11215",
            "country": "US",
            "state": "NY",
            "display_address": [
                "535 6th Ave",
                "Brooklyn, NY 11215"
            ]
        }
    },
    {
        "bid": "HVKKciOXD4k9VWXqgM9hqw",
        "rating": 4.0,
        "reviews": 179,
        "coordinates": {
            "latitude": 40.65865,
            "longitude": -73.98222
        },
        "name": "Bedawi Cafe",
        "address": {
            "address1": "266 Prospect Park W",
            "address2": None,
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11215",
            "country": "US",
            "state": "NY",
            "display_address": [
                "266 Prospect Park W",
                "Brooklyn, NY 11215"
            ]
        }
    },
    {
        "bid": "odvX2rYmaoa8zIVFpuK2Dw",
        "rating": 4.5,
        "reviews": 147,
        "coordinates": {
            "latitude": 41.25524761071848,
            "longitude": -74.36035209063562
        },
        "name": "Opa Greek Grill",
        "address": {
            "address1": "10 Oakland Ave",
            "address2": "",
            "address3": None,
            "city": "Warwick",
            "zip_code": "10990",
            "country": "US",
            "state": "NY",
            "display_address": [
                "10 Oakland Ave",
                "Warwick, NY 10990"
            ]
        }
    },
    {
        "bid": "hU1ajPmHi-kU6iNbowoEZg",
        "rating": 3.5,
        "reviews": 265,
        "coordinates": {
            "latitude": 40.75384139204255,
            "longitude": -74.00107612944777
        },
        "name": "Estiatorio Milos",
        "address": {
            "address1": "20 Hudson Yards",
            "address2": "Fl 5",
            "address3": None,
            "city": "New York",
            "zip_code": "10001",
            "country": "US",
            "state": "NY",
            "display_address": [
                "20 Hudson Yards",
                "Fl 5",
                "New York, NY 10001"
            ]
        }
    },
    {
        "bid": "W7Uu092SbjLOi9P2ojQG5g",
        "rating": 4.0,
        "reviews": 112,
        "coordinates": {
            "latitude": 40.7020652420097,
            "longitude": -73.6446119472384
        },
        "name": "Anatolia",
        "address": {
            "address1": "183 Hempstead Ave",
            "address2": "",
            "address3": "",
            "city": "West Hempstead",
            "zip_code": "11552",
            "country": "US",
            "state": "NY",
            "display_address": [
                "183 Hempstead Ave",
                "West Hempstead, NY 11552"
            ]
        }
    },
    {
        "bid": "g5RU0f6w4V7o4xjlKrDetA",
        "rating": 4.0,
        "reviews": 748,
        "coordinates": {
            "latitude": 40.58387,
            "longitude": -73.94463
        },
        "name": "Opera Cafe",
        "address": {
            "address1": "2255 Emmons Ave",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11235",
            "country": "US",
            "state": "NY",
            "display_address": [
                "2255 Emmons Ave",
                "Brooklyn, NY 11235"
            ]
        }
    },
    {
        "bid": "D_Rjd2js4_lkk51Obvlveg",
        "rating": 4.5,
        "reviews": 40,
        "coordinates": {
            "latitude": 40.7209634,
            "longitude": -73.9586038582844
        },
        "name": "K'Far",
        "address": {
            "address1": "97 Wythe Ave",
            "address2": None,
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11249",
            "country": "US",
            "state": "NY",
            "display_address": [
                "97 Wythe Ave",
                "Brooklyn, NY 11249"
            ]
        }
    },
    {
        "bid": "5ZG_cpkQ8djxt0f33yMXKA",
        "rating": 4.5,
        "reviews": 569,
        "coordinates": {
            "latitude": 40.940180026078,
            "longitude": -74.0307347374599
        },
        "name": "A Taste of Greece",
        "address": {
            "address1": "935 Kinderkamack Rd",
            "address2": "",
            "address3": "",
            "city": "River Edge",
            "zip_code": "07661",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "935 Kinderkamack Rd",
                "River Edge, NJ 07661"
            ]
        }
    },
    {
        "bid": "cgrlTabSk00yLlUQJXYnKg",
        "rating": 4.5,
        "reviews": 27,
        "coordinates": {
            "latitude": 40.345261756840465,
            "longitude": -74.30728581356672
        },
        "name": "Istanbul Bay Premium",
        "address": {
            "address1": "190 US-9",
            "address2": "",
            "address3": None,
            "city": "Englishtown",
            "zip_code": "07726",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "190 US-9",
                "Englishtown, NJ 07726"
            ]
        }
    },
    {
        "bid": "Dik0ClbTvM9g0PbOHI_mig",
        "rating": 5.0,
        "reviews": 13,
        "coordinates": {
            "latitude": 40.74822,
            "longitude": -73.98874
        },
        "name": "Chamoun's Way",
        "address": {
            "address1": "888 6th Ave",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10001",
            "country": "US",
            "state": "NY",
            "display_address": [
                "888 6th Ave",
                "New York, NY 10001"
            ]
        }
    },
    {
        "bid": "1-68ToR8aceyr4y1bgjxtw",
        "rating": 4.5,
        "reviews": 148,
        "coordinates": {
            "latitude": 40.2408045463001,
            "longitude": -74.3058150261641
        },
        "name": "Zaytouna Mediterranean Grill",
        "address": {
            "address1": "13 Village Ctr Dr",
            "address2": "",
            "address3": None,
            "city": "Freehold",
            "zip_code": "07728",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "13 Village Ctr Dr",
                "Freehold, NJ 07728"
            ]
        }
    },
    {
        "bid": "u2Uw0v1Rqepv0X6nOyICxA",
        "rating": 3.5,
        "reviews": 389,
        "coordinates": {
            "latitude": 40.762037,
            "longitude": -73.9660633
        },
        "name": "Anassa Taverna NYC",
        "address": {
            "address1": "200 E 60th St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10022",
            "country": "US",
            "state": "NY",
            "display_address": [
                "200 E 60th St",
                "New York, NY 10022"
            ]
        }
    },
    {
        "bid": "1FoeTuqJyPqhSCXjUNsWpA",
        "rating": 4.5,
        "reviews": 134,
        "coordinates": {
            "latitude": 40.6499129612948,
            "longitude": -74.3394414496156
        },
        "name": "Famous Kabab Cuisine",
        "address": {
            "address1": "231 South Ave E",
            "address2": None,
            "address3": "",
            "city": "Westfield",
            "zip_code": "07090",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "231 South Ave E",
                "Westfield, NJ 07090"
            ]
        }
    },
    {
        "bid": "GktRnSCBAsboHj9Hh-U66g",
        "rating": 4.0,
        "reviews": 72,
        "coordinates": {
            "latitude": 40.7239479,
            "longitude": -74.010406
        },
        "name": "GRECA",
        "address": {
            "address1": "452 Washington St",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10013",
            "country": "US",
            "state": "NY",
            "display_address": [
                "452 Washington St",
                "New York, NY 10013"
            ]
        }
    },
    {
        "bid": "diW0VnV5sZQQpTamlVXjGg",
        "rating": 4.0,
        "reviews": 120,
        "coordinates": {
            "latitude": 40.65843,
            "longitude": -73.98171
        },
        "name": "Greek Xpress",
        "address": {
            "address1": "263 Prospect Park W",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11215",
            "country": "US",
            "state": "NY",
            "display_address": [
                "263 Prospect Park W",
                "Brooklyn, NY 11215"
            ]
        }
    },
    {
        "bid": "TfAz2OqY4xWMHHh5H1OmrQ",
        "rating": 5.0,
        "reviews": 162,
        "coordinates": {
            "latitude": 40.68178,
            "longitude": -73.90916
        },
        "name": "Pita Point",
        "address": {
            "address1": "508 Marion St",
            "address2": None,
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11233",
            "country": "US",
            "state": "NY",
            "display_address": [
                "508 Marion St",
                "Brooklyn, NY 11233"
            ]
        }
    },
    {
        "bid": "5bSlJVk2QpIe7Uxp1pgnmw",
        "rating": 4.5,
        "reviews": 125,
        "coordinates": {
            "latitude": 40.82398,
            "longitude": -73.98921
        },
        "name": "Saray Cuisine",
        "address": {
            "address1": "575 Anderson Ave",
            "address2": None,
            "address3": "",
            "city": "Cliffside Park",
            "zip_code": "07010",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "575 Anderson Ave",
                "Cliffside Park, NJ 07010"
            ]
        }
    },
    {
        "bid": "X155pxtcrY7l7Awh5zzm7g",
        "rating": 3.5,
        "reviews": 112,
        "coordinates": {
            "latitude": 40.690063,
            "longitude": -73.994621
        },
        "name": "Tripoli Restaurant",
        "address": {
            "address1": "156 Atlantic Ave",
            "address2": "",
            "address3": "Lower Level",
            "city": "Brooklyn",
            "zip_code": "11201",
            "country": "US",
            "state": "NY",
            "display_address": [
                "156 Atlantic Ave",
                "Lower Level",
                "Brooklyn, NY 11201"
            ]
        }
    },
    {
        "bid": "Gi8HGtzVrxTg02IBXpSClw",
        "rating": 3.5,
        "reviews": 465,
        "coordinates": {
            "latitude": 40.77013,
            "longitude": -73.95774
        },
        "name": "A La Turka",
        "address": {
            "address1": "1417 2nd Ave",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10021",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1417 2nd Ave",
                "New York, NY 10021"
            ]
        }
    },
    {
        "bid": "goxRP7RFyv3tGBqp6x7dYg",
        "rating": 5.0,
        "reviews": 2,
        "coordinates": {
            "latitude": 40.70138,
            "longitude": -73.92195
        },
        "name": "Pita Grill",
        "address": {
            "address1": "1480 Dekalb Ave",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "11237",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1480 Dekalb Ave",
                "New York, NY 11237"
            ]
        }
    },
    {
        "bid": "jTvExXa9M8QqS_Wn_4KB5g",
        "rating": 4.0,
        "reviews": 16,
        "coordinates": {
            "latitude": 40.7423867,
            "longitude": -73.9364439
        },
        "name": "Harissa Grill",
        "address": {
            "address1": "30-30 47th Ave",
            "address2": "",
            "address3": "",
            "city": "Long Island City",
            "zip_code": "11101",
            "country": "US",
            "state": "NY",
            "display_address": [
                "30-30 47th Ave",
                "Long Island City, NY 11101"
            ]
        }
    },
    {
        "bid": "46FE_VjZJ0CBsmN9_TYMiA",
        "rating": 4.0,
        "reviews": 167,
        "coordinates": {
            "latitude": 40.7906581,
            "longitude": -74.0228635
        },
        "name": "Kebab Istanbul",
        "address": {
            "address1": "5819 Kennedy Blvd W",
            "address2": "",
            "address3": "",
            "city": "North Bergen",
            "zip_code": "07047",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "5819 Kennedy Blvd W",
                "North Bergen, NJ 07047"
            ]
        }
    },
    {
        "bid": "YeqyPlYPuYd39rZargcW2A",
        "rating": 4.5,
        "reviews": 117,
        "coordinates": {
            "latitude": 41.0574545,
            "longitude": -74.141461
        },
        "name": "Smyrna Mediterranean Cafe & Grill",
        "address": {
            "address1": "21 E Main St",
            "address2": None,
            "address3": None,
            "city": "Ramsey",
            "zip_code": "07446",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "21 E Main St",
                "Ramsey, NJ 07446"
            ]
        }
    },
    {
        "bid": "d8QUxd7xfKS4-SUk-uPX4g",
        "rating": 4.5,
        "reviews": 156,
        "coordinates": {
            "latitude": 40.7091391,
            "longitude": -73.9372268
        },
        "name": "Newtown",
        "address": {
            "address1": "55 Waterbury St",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11206",
            "country": "US",
            "state": "NY",
            "display_address": [
                "55 Waterbury St",
                "Brooklyn, NY 11206"
            ]
        }
    },
    {
        "bid": "jpw7iGUzsj_AECKt351X8w",
        "rating": 4.0,
        "reviews": 581,
        "coordinates": {
            "latitude": 40.7199624,
            "longitude": -73.9885666
        },
        "name": "Wolfnights - The Gourmet Wrap",
        "address": {
            "address1": "99 Rivington St",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10002",
            "country": "US",
            "state": "NY",
            "display_address": [
                "99 Rivington St",
                "New York, NY 10002"
            ]
        }
    },
    {
        "bid": "jt_mFVGnAcPx27vIz4o29A",
        "rating": 3.5,
        "reviews": 1455,
        "coordinates": {
            "latitude": 40.74067,
            "longitude": -74.00708
        },
        "name": "Fig & Olive",
        "address": {
            "address1": "420 W 13th St",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10014",
            "country": "US",
            "state": "NY",
            "display_address": [
                "420 W 13th St",
                "New York, NY 10014"
            ]
        }
    },
    {
        "bid": "e2iz_3wMcX55JDBV575Nzg",
        "rating": 4.5,
        "reviews": 105,
        "coordinates": {
            "latitude": 40.74352333,
            "longitude": -74.15543167
        },
        "name": "Juicy Platters - Harrison",
        "address": {
            "address1": "406 Bergen St",
            "address2": None,
            "address3": "",
            "city": "Harrison",
            "zip_code": "07029",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "406 Bergen St",
                "Harrison, NJ 07029"
            ]
        }
    },
    {
        "bid": "glccbDYpXzsozu7truCf5w",
        "rating": 4.0,
        "reviews": 738,
        "coordinates": {
            "latitude": 40.58651815799407,
            "longitude": -73.95187849999999
        },
        "name": "Nargis Cafe",
        "address": {
            "address1": "1655 Sheepshead Bay Rd",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11235",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1655 Sheepshead Bay Rd",
                "Brooklyn, NY 11235"
            ]
        }
    },
    {
        "bid": "tFmwt_NWIRtjdWs5xKfwew",
        "rating": 5.0,
        "reviews": 1,
        "coordinates": {
            "latitude": 40.76253356913991,
            "longitude": -73.97660198800082
        },
        "name": "White Olive",
        "address": {
            "address1": "39 W 55th St",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10019",
            "country": "US",
            "state": "NY",
            "display_address": [
                "39 W 55th St",
                "New York, NY 10019"
            ]
        }
    },
    {
        "bid": "6KzJ3JEOQ4QrVbrrRtBxQw",
        "rating": 4.0,
        "reviews": 960,
        "coordinates": {
            "latitude": 40.765745,
            "longitude": -73.77185875889714
        },
        "name": "Avli The Little Greek Tavern",
        "address": {
            "address1": "38-31 Bell Blvd",
            "address2": "",
            "address3": "",
            "city": "Bayside",
            "zip_code": "11361",
            "country": "US",
            "state": "NY",
            "display_address": [
                "38-31 Bell Blvd",
                "Bayside, NY 11361"
            ]
        }
    },
    {
        "bid": "AIcyWYtw8_lP0P3qHu2_8g",
        "rating": 4.5,
        "reviews": 70,
        "coordinates": {
            "latitude": 40.622725,
            "longitude": -74.028674
        },
        "name": "Ay Kebab",
        "address": {
            "address1": "8602 4th Ave",
            "address2": None,
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11209",
            "country": "US",
            "state": "NY",
            "display_address": [
                "8602 4th Ave",
                "Brooklyn, NY 11209"
            ]
        }
    },
    {
        "bid": "79IGaMRIborpfemhCx_-nA",
        "rating": 5.0,
        "reviews": 2,
        "coordinates": {
            "latitude": 40.612377,
            "longitude": -74.158859
        },
        "name": "J&J Mediterranean Grill",
        "address": {
            "address1": "1471 Richmond Ave",
            "address2": "",
            "address3": "",
            "city": "Bulls Head",
            "zip_code": "10314",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1471 Richmond Ave",
                "Bulls Head, NY 10314"
            ]
        }
    },
    {
        "bid": "sxUxnWmWN7IbjNswAkTGcg",
        "rating": 4.0,
        "reviews": 287,
        "coordinates": {
            "latitude": 40.79895833,
            "longitude": -74.4816
        },
        "name": "Fig & Lily Garden",
        "address": {
            "address1": "2 Cattano Ave",
            "address2": "",
            "address3": None,
            "city": "Morristown",
            "zip_code": "07960",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "2 Cattano Ave",
                "Morristown, NJ 07960"
            ]
        }
    },
    {
        "bid": "ju0UobdUZQWfyxWJEnoviQ",
        "rating": 4.0,
        "reviews": 155,
        "coordinates": {
            "latitude": 40.8543220213677,
            "longitude": -73.8641628382638
        },
        "name": "Ez Grill NYC",
        "address": {
            "address1": "790 Lydig Ave",
            "address2": "",
            "address3": "",
            "city": "Bronx",
            "zip_code": "10462",
            "country": "US",
            "state": "NY",
            "display_address": [
                "790 Lydig Ave",
                "Bronx, NY 10462"
            ]
        }
    },
    {
        "bid": "jjqQ-2OTsnJiqiKyk5f__Q",
        "rating": 3.5,
        "reviews": 12,
        "coordinates": {
            "latitude": 40.61246,
            "longitude": -73.97882
        },
        "name": "Si n\u2019shpi",
        "address": {
            "address1": "2307 65th St",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11204",
            "country": "US",
            "state": "NY",
            "display_address": [
                "2307 65th St",
                "Brooklyn, NY 11204"
            ]
        }
    },
    {
        "bid": "h_X1VLP4eVHmaQW6yAAbBg",
        "rating": 4.0,
        "reviews": 411,
        "coordinates": {
            "latitude": 40.7750966778383,
            "longitude": -73.9116586888159
        },
        "name": "Truva Cafe and Grill",
        "address": {
            "address1": "22-41 31st St",
            "address2": "",
            "address3": "",
            "city": "Astoria",
            "zip_code": "11105",
            "country": "US",
            "state": "NY",
            "display_address": [
                "22-41 31st St",
                "Astoria, NY 11105"
            ]
        }
    },
    {
        "bid": "iruQwZNn9eyfnc2Z1vGsOQ",
        "rating": 4.0,
        "reviews": 298,
        "coordinates": {
            "latitude": 40.656353871374,
            "longitude": -74.3035939394892
        },
        "name": "Old City Cafe & Grill",
        "address": {
            "address1": "20 N Union Ave",
            "address2": "",
            "address3": "",
            "city": "Cranford",
            "zip_code": "07016",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "20 N Union Ave",
                "Cranford, NJ 07016"
            ]
        }
    },
    {
        "bid": "pgBTcBEyhewkFCeGwmHX1w",
        "rating": 4.0,
        "reviews": 34,
        "coordinates": {
            "latitude": 40.660142,
            "longitude": -74.2188366
        },
        "name": "Tequila Bistro",
        "address": {
            "address1": "824 Pearl St",
            "address2": "",
            "address3": "",
            "city": "Elizabeth",
            "zip_code": "07202",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "824 Pearl St",
                "Elizabeth, NJ 07202"
            ]
        }
    },
    {
        "bid": "ABSjgmTE7RjlgUUPpIPR4g",
        "rating": 3.0,
        "reviews": 103,
        "coordinates": {
            "latitude": 40.765811920166,
            "longitude": -73.9702758789062
        },
        "name": "Amaranth Restaurant",
        "address": {
            "address1": "21 E 62nd St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10021",
            "country": "US",
            "state": "NY",
            "display_address": [
                "21 E 62nd St",
                "New York, NY 10021"
            ]
        }
    },
    {
        "bid": "0c6Xt-P2x40DbMW7tMVDgw",
        "rating": 4.0,
        "reviews": 360,
        "coordinates": {
            "latitude": 40.75895,
            "longitude": -73.77538
        },
        "name": "Veranda Restaurant & Cafe",
        "address": {
            "address1": "208-01 Northern Blvd",
            "address2": "",
            "address3": "",
            "city": "Bayside",
            "zip_code": "11361",
            "country": "US",
            "state": "NY",
            "display_address": [
                "208-01 Northern Blvd",
                "Bayside, NY 11361"
            ]
        }
    },
    {
        "bid": "fkDgH1Y24jXb9uoDR4yRww",
        "rating": 4.0,
        "reviews": 30,
        "coordinates": {
            "latitude": 40.8539505004883,
            "longitude": -73.8892364501953
        },
        "name": "Gurra Cafe",
        "address": {
            "address1": "2325 Arthur Ave",
            "address2": "",
            "address3": "",
            "city": "Bronx",
            "zip_code": "10458",
            "country": "US",
            "state": "NY",
            "display_address": [
                "2325 Arthur Ave",
                "Bronx, NY 10458"
            ]
        }
    },
    {
        "bid": "vf-5-9SA-2Yd0R7q4cI-wg",
        "rating": 4.0,
        "reviews": 139,
        "coordinates": {
            "latitude": 40.73583984375,
            "longitude": -74.0074844360352
        },
        "name": "Turks & Frogs",
        "address": {
            "address1": "323 W 11th St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10014",
            "country": "US",
            "state": "NY",
            "display_address": [
                "323 W 11th St",
                "New York, NY 10014"
            ]
        }
    },
    {
        "bid": "kgJwblaytYITxd9KhtqzKA",
        "rating": 4.0,
        "reviews": 168,
        "coordinates": {
            "latitude": 40.74073,
            "longitude": -73.99104
        },
        "name": "Merakia",
        "address": {
            "address1": "5 W 21st St",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10010",
            "country": "US",
            "state": "NY",
            "display_address": [
                "5 W 21st St",
                "New York, NY 10010"
            ]
        }
    },
    {
        "bid": "xmGAivndfLoQ4PuwR_gInw",
        "rating": 3.5,
        "reviews": 33,
        "coordinates": {
            "latitude": 40.75321,
            "longitude": -73.69378
        },
        "name": "Wild Fig",
        "address": {
            "address1": "1468 Union Tpke",
            "address2": "",
            "address3": None,
            "city": "North New Hyde Park",
            "zip_code": "11040",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1468 Union Tpke",
                "North New Hyde Park, NY 11040"
            ]
        }
    },
    {
        "bid": "Nj20jEI5OB813dBdSk8WOA",
        "rating": 4.0,
        "reviews": 258,
        "coordinates": {
            "latitude": 40.928312,
            "longitude": -73.80863
        },
        "name": "Elia Taverna",
        "address": {
            "address1": "502 New Rochelle Rd",
            "address2": "",
            "address3": "",
            "city": "Bronxville",
            "zip_code": "10708",
            "country": "US",
            "state": "NY",
            "display_address": [
                "502 New Rochelle Rd",
                "Bronxville, NY 10708"
            ]
        }
    },
    {
        "bid": "dv9duLvAyuTMtfsF08fm0w",
        "rating": 4.0,
        "reviews": 42,
        "coordinates": {
            "latitude": 40.6309121,
            "longitude": -74.2525104
        },
        "name": "Cairo Falafel - Formerly Falafel Feast",
        "address": {
            "address1": "106 N Wood Ave",
            "address2": None,
            "address3": "",
            "city": "Linden",
            "zip_code": "07036",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "106 N Wood Ave",
                "Linden, NJ 07036"
            ]
        }
    },
    {
        "bid": "W0y5T70yOebE_QWSQAXwdQ",
        "rating": 4.5,
        "reviews": 18,
        "coordinates": {
            "latitude": 40.58103,
            "longitude": -73.96007
        },
        "name": "Hi Food Cafe",
        "address": {
            "address1": "3078 Coney Island Ave",
            "address2": None,
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11235",
            "country": "US",
            "state": "NY",
            "display_address": [
                "3078 Coney Island Ave",
                "Brooklyn, NY 11235"
            ]
        }
    },
    {
        "bid": "2xvtE7LjFBQDEPErxNT72Q",
        "rating": 3.5,
        "reviews": 12,
        "coordinates": {
            "latitude": 40.706378,
            "longitude": -74.006629
        },
        "name": "Dill & Parsley",
        "address": {
            "address1": "110 Maiden Ln",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10005",
            "country": "US",
            "state": "NY",
            "display_address": [
                "110 Maiden Ln",
                "New York, NY 10005"
            ]
        }
    },
    {
        "bid": "deJwwVdY2L88MAMKxE5S7A",
        "rating": 4.0,
        "reviews": 375,
        "coordinates": {
            "latitude": 40.7621880914364,
            "longitude": -73.9255477918848
        },
        "name": "King of Falafel & Shawarma - Restaurant",
        "address": {
            "address1": "30-15 Broadway",
            "address2": "",
            "address3": "",
            "city": "Astoria",
            "zip_code": "11106",
            "country": "US",
            "state": "NY",
            "display_address": [
                "30-15 Broadway",
                "Astoria, NY 11106"
            ]
        }
    },
    {
        "bid": "GLIuWsvvQxmpvgZ4iAbjoA",
        "rating": 4.0,
        "reviews": 395,
        "coordinates": {
            "latitude": 40.78609881017206,
            "longitude": -73.648815
        },
        "name": "Ravagh Persian Grill",
        "address": {
            "address1": "210 Mineola Ave",
            "address2": "",
            "address3": "",
            "city": "Roslyn Heights",
            "zip_code": "11577",
            "country": "US",
            "state": "NY",
            "display_address": [
                "210 Mineola Ave",
                "Roslyn Heights, NY 11577"
            ]
        }
    },
    {
        "bid": "bG9Tsue1s3VFOo3Cx6-wvw",
        "rating": 4.5,
        "reviews": 188,
        "coordinates": {
            "latitude": 40.8511112,
            "longitude": -74.0850838
        },
        "name": "The Kebabci",
        "address": {
            "address1": "259 Valley Blvd",
            "address2": "",
            "address3": None,
            "city": "Wood-Ridge",
            "zip_code": "07075",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "259 Valley Blvd",
                "Wood-Ridge, NJ 07075"
            ]
        }
    },
    {
        "bid": "bOvproFZLh7WAzGn-rUWXQ",
        "rating": 4.5,
        "reviews": 482,
        "coordinates": {
            "latitude": 40.72457,
            "longitude": -73.55003
        },
        "name": "Sufiya's Grill - East Meadow",
        "address": {
            "address1": "2320 Hempstead Tpke",
            "address2": None,
            "address3": "",
            "city": "East Meadow",
            "zip_code": "11554",
            "country": "US",
            "state": "NY",
            "display_address": [
                "2320 Hempstead Tpke",
                "East Meadow, NY 11554"
            ]
        }
    },
    {
        "bid": "JIWCAWQnRVevwhbyADcLgg",
        "rating": 4.0,
        "reviews": 344,
        "coordinates": {
            "latitude": 40.62523,
            "longitude": -74.00211
        },
        "name": "Meze",
        "address": {
            "address1": "6601 13th Ave",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11219",
            "country": "US",
            "state": "NY",
            "display_address": [
                "6601 13th Ave",
                "Brooklyn, NY 11219"
            ]
        }
    },
    {
        "bid": "_LSCH5kz6iW9eu71tgiR1A",
        "rating": 4.5,
        "reviews": 265,
        "coordinates": {
            "latitude": 40.23719,
            "longitude": -74.03707
        },
        "name": "The Greek Spot",
        "address": {
            "address1": "1013 NJ-35",
            "address2": "",
            "address3": None,
            "city": "Ocean Township",
            "zip_code": "07712",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "1013 NJ-35",
                "Ocean Township, NJ 07712"
            ]
        }
    },
    {
        "bid": "YvTqr7SBCestzWyi5iCaLw",
        "rating": 3.5,
        "reviews": 228,
        "coordinates": {
            "latitude": 40.70753,
            "longitude": -73.93965
        },
        "name": "Bushwick Pita Palace",
        "address": {
            "address1": "243 Bushwick Ave",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11206",
            "country": "US",
            "state": "NY",
            "display_address": [
                "243 Bushwick Ave",
                "Brooklyn, NY 11206"
            ]
        }
    },
    {
        "bid": "KS4b_4sZGuXJds6ZQ3XdAw",
        "rating": 4.5,
        "reviews": 195,
        "coordinates": {
            "latitude": 40.2637220795906,
            "longitude": -74.0449957836091
        },
        "name": "Cafe 28",
        "address": {
            "address1": "835 W Park Ave",
            "address2": "",
            "address3": None,
            "city": "Ocean Township",
            "zip_code": "07712",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "835 W Park Ave",
                "Ocean Township, NJ 07712"
            ]
        }
    },
    {
        "bid": "clm70d0msOsl81_lUUbUmw",
        "rating": 4.5,
        "reviews": 21,
        "coordinates": {
            "latitude": 40.65878,
            "longitude": -73.67666
        },
        "name": "IN-N-OUT GRILL",
        "address": {
            "address1": "429 Merrick Rd",
            "address2": None,
            "address3": "",
            "city": "Lynbrook",
            "zip_code": "11563",
            "country": "US",
            "state": "NY",
            "display_address": [
                "429 Merrick Rd",
                "Lynbrook, NY 11563"
            ]
        }
    },
    {
        "bid": "1JgYhJfYdTUFej6rL1_scA",
        "rating": 4.0,
        "reviews": 23,
        "coordinates": {
            "latitude": 40.79095,
            "longitude": -74.00493
        },
        "name": "Le Chateau",
        "address": {
            "address1": "6701 Park Ave",
            "address2": "",
            "address3": "",
            "city": "West New York",
            "zip_code": "07093",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "6701 Park Ave",
                "West New York, NJ 07093"
            ]
        }
    },
    {
        "bid": "DKAVCg08eo2JTaS8HhSgrA",
        "rating": 4.0,
        "reviews": 829,
        "coordinates": {
            "latitude": 40.740146996903825,
            "longitude": -74.0303276273842
        },
        "name": "Mamoun's Falafel",
        "address": {
            "address1": "300 Washington St",
            "address2": "",
            "address3": "",
            "city": "Hoboken",
            "zip_code": "07030",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "300 Washington St",
                "Hoboken, NJ 07030"
            ]
        }
    },
    {
        "bid": "fJhzNx7t2QybrYudxULGoA",
        "rating": 4.0,
        "reviews": 447,
        "coordinates": {
            "latitude": 40.7661182,
            "longitude": -73.7721149
        },
        "name": "Maria's Mediterranean",
        "address": {
            "address1": "38-11 Bell Blvd",
            "address2": None,
            "address3": "",
            "city": "Bayside",
            "zip_code": "11361",
            "country": "US",
            "state": "NY",
            "display_address": [
                "38-11 Bell Blvd",
                "Bayside, NY 11361"
            ]
        }
    },
    {
        "bid": "m8Ytb_3eYIiWla68Lk2fFA",
        "rating": 4.0,
        "reviews": 232,
        "coordinates": {
            "latitude": 40.7596400253254,
            "longitude": -73.9623098820448
        },
        "name": "Under The Bridge",
        "address": {
            "address1": "1079 1st Ave",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10022",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1079 1st Ave",
                "New York, NY 10022"
            ]
        }
    },
    {
        "bid": "62dhOUChlqsVkszPxqwq9Q",
        "rating": 4.0,
        "reviews": 473,
        "coordinates": {
            "latitude": 40.7750206,
            "longitude": -73.9133301
        },
        "name": "Stamatis Restaurant",
        "address": {
            "address1": "2909 23rd Ave",
            "address2": "",
            "address3": "",
            "city": "Astoria",
            "zip_code": "11105",
            "country": "US",
            "state": "NY",
            "display_address": [
                "2909 23rd Ave",
                "Astoria, NY 11105"
            ]
        }
    },
    {
        "bid": "My17Ud2T_tXy_9ND9aezpQ",
        "rating": 4.0,
        "reviews": 393,
        "coordinates": {
            "latitude": 40.7301,
            "longitude": -73.863538
        },
        "name": "Black Sea Fish & Grill",
        "address": {
            "address1": "95-36 Queens Blvd",
            "address2": "",
            "address3": "",
            "city": "Rego Park",
            "zip_code": "11374",
            "country": "US",
            "state": "NY",
            "display_address": [
                "95-36 Queens Blvd",
                "Rego Park, NY 11374"
            ]
        }
    },
    {
        "bid": "o3h2s7A-F5Uf-9Bz7YCYmg",
        "rating": 5.0,
        "reviews": 60,
        "coordinates": {
            "latitude": 41.027348,
            "longitude": -73.62405870613438
        },
        "name": "Greenwich Flavor by Myrna's",
        "address": {
            "address1": "148 Mason St",
            "address2": "",
            "address3": None,
            "city": "Greenwich",
            "zip_code": "06830",
            "country": "US",
            "state": "CT",
            "display_address": [
                "148 Mason St",
                "Greenwich, CT 06830"
            ]
        }
    },
    {
        "bid": "s1xqkhsCZYfZBMPEZF7mRA",
        "rating": 4.0,
        "reviews": 33,
        "coordinates": {
            "latitude": 40.6288737,
            "longitude": -73.7369829
        },
        "name": "Ahuva's Grill Express",
        "address": {
            "address1": "480 Rockaway Tpke",
            "address2": "",
            "address3": "",
            "city": "Lawrence",
            "zip_code": "11559",
            "country": "US",
            "state": "NY",
            "display_address": [
                "480 Rockaway Tpke",
                "Lawrence, NY 11559"
            ]
        }
    },
    {
        "bid": "K2QvVZ1mXc1xZdA0NLlf9Q",
        "rating": 4.5,
        "reviews": 53,
        "coordinates": {
            "latitude": 40.6788993574647,
            "longitude": -73.9272566922721
        },
        "name": "Mama Kitchen",
        "address": {
            "address1": "7 Rochester Ave",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11233",
            "country": "US",
            "state": "NY",
            "display_address": [
                "7 Rochester Ave",
                "Brooklyn, NY 11233"
            ]
        }
    },
    {
        "bid": "uNuuJAK0VR1Rs2BKTcgTJg",
        "rating": 4.0,
        "reviews": 181,
        "coordinates": {
            "latitude": 40.62302,
            "longitude": -74.03089
        },
        "name": "Elia Restaurant",
        "address": {
            "address1": "8611 3rd Ave",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11209",
            "country": "US",
            "state": "NY",
            "display_address": [
                "8611 3rd Ave",
                "Brooklyn, NY 11209"
            ]
        }
    },
    {
        "bid": "eq_jhDw9D38RAhyv09axTg",
        "rating": 4.0,
        "reviews": 287,
        "coordinates": {
            "latitude": 40.792959,
            "longitude": -73.968184
        },
        "name": "Effy's Cafe",
        "address": {
            "address1": "104 W 96th St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10025",
            "country": "US",
            "state": "NY",
            "display_address": [
                "104 W 96th St",
                "New York, NY 10025"
            ]
        }
    },
    {
        "bid": "fKl-XzMrRQyW9tjg9mhIGA",
        "rating": 4.0,
        "reviews": 122,
        "coordinates": {
            "latitude": 40.79783,
            "longitude": -74.0657
        },
        "name": "Sinbad Cafe & Grill",
        "address": {
            "address1": "20 Meadowlands Pkwy",
            "address2": "",
            "address3": "",
            "city": "Secaucus",
            "zip_code": "07094",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "20 Meadowlands Pkwy",
                "Secaucus, NJ 07094"
            ]
        }
    },
    {
        "bid": "Ey29dYV1gAtalkwPH8k1vg",
        "rating": 4.0,
        "reviews": 468,
        "coordinates": {
            "latitude": 40.76446,
            "longitude": -73.77174
        },
        "name": "Taverna Kyclades - Bayside",
        "address": {
            "address1": "39-28 Bell Blvd",
            "address2": "",
            "address3": None,
            "city": "Bayside",
            "zip_code": "11361",
            "country": "US",
            "state": "NY",
            "display_address": [
                "39-28 Bell Blvd",
                "Bayside, NY 11361"
            ]
        }
    },
    {
        "bid": "hmNxdAbt0tiGm8_vPdXCSA",
        "rating": 4.0,
        "reviews": 223,
        "coordinates": {
            "latitude": 40.768066,
            "longitude": -73.959243
        },
        "name": "Afghan Kebab House II",
        "address": {
            "address1": "1345 2nd Ave",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10021",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1345 2nd Ave",
                "New York, NY 10021"
            ]
        }
    },
    {
        "bid": "A8LwhOf0Me5b6Grkw7koMw",
        "rating": 4.5,
        "reviews": 3,
        "coordinates": {
            "latitude": 40.8937,
            "longitude": -74.20838
        },
        "name": "Woodland Park Charcoal Grill & Deli",
        "address": {
            "address1": "1048 McBride Ave",
            "address2": None,
            "address3": "",
            "city": "Woodland Park",
            "zip_code": "07424",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "1048 McBride Ave",
                "Woodland Park, NJ 07424"
            ]
        }
    },
    {
        "bid": "5KS-ksuI0fNHmqb7DtjUEw",
        "rating": 5.0,
        "reviews": 82,
        "coordinates": {
            "latitude": 40.296506,
            "longitude": -74.358173
        },
        "name": "The Baklava Lady",
        "address": {
            "address1": "34 Main St",
            "address2": "",
            "address3": None,
            "city": "Englishtown",
            "zip_code": "07726",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "34 Main St",
                "Englishtown, NJ 07726"
            ]
        }
    },
    {
        "bid": "TdAjlHUnsMyFsJheue8aRQ",
        "rating": 3.5,
        "reviews": 284,
        "coordinates": {
            "latitude": 40.74143,
            "longitude": -73.97854
        },
        "name": "Sahara's Turkish Cuisine",
        "address": {
            "address1": "513 2nd Ave",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10016",
            "country": "US",
            "state": "NY",
            "display_address": [
                "513 2nd Ave",
                "New York, NY 10016"
            ]
        }
    },
    {
        "bid": "GO3mXsVHHgpL5u-ROAJ51Q",
        "rating": 4.5,
        "reviews": 340,
        "coordinates": {
            "latitude": 40.82858,
            "longitude": -74.47958
        },
        "name": "Carmel Haifa",
        "address": {
            "address1": "682 Speedwell Ave",
            "address2": "",
            "address3": "",
            "city": "Morris Plains",
            "zip_code": "07950",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "682 Speedwell Ave",
                "Morris Plains, NJ 07950"
            ]
        }
    },
    {
        "bid": "D4f6htB176SAxS1q0rZX3A",
        "rating": 4.0,
        "reviews": 237,
        "coordinates": {
            "latitude": 40.829162,
            "longitude": -73.98592
        },
        "name": "Avos Grill",
        "address": {
            "address1": "720 Anderson Ave",
            "address2": "Ste 4",
            "address3": "",
            "city": "Cliffside Park",
            "zip_code": "07010",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "720 Anderson Ave",
                "Ste 4",
                "Cliffside Park, NJ 07010"
            ]
        }
    },
    {
        "bid": "C8l_BzSx1U5Ht8OIcxI8jg",
        "rating": 4.0,
        "reviews": 173,
        "coordinates": {
            "latitude": 40.6652262,
            "longitude": -73.73060439999999
        },
        "name": "Halal Bros Grill",
        "address": {
            "address1": "247-14 South Conduit Ave",
            "address2": "",
            "address3": None,
            "city": "Queens",
            "zip_code": "11422",
            "country": "US",
            "state": "NY",
            "display_address": [
                "247-14 South Conduit Ave",
                "Queens, NY 11422"
            ]
        }
    },
    {
        "bid": "BcGGXQ2E2lQA_nYCGCLcCg",
        "rating": 4.0,
        "reviews": 220,
        "coordinates": {
            "latitude": 40.6574379,
            "longitude": -73.5476667
        },
        "name": "Sufiya's Grill - Merrick",
        "address": {
            "address1": "2057 Merrick Rd",
            "address2": "",
            "address3": None,
            "city": "Merrick",
            "zip_code": "11566",
            "country": "US",
            "state": "NY",
            "display_address": [
                "2057 Merrick Rd",
                "Merrick, NY 11566"
            ]
        }
    },
    {
        "bid": "zQjaTAxYSKpNNj0F4kgjXQ",
        "rating": 4.5,
        "reviews": 111,
        "coordinates": {
            "latitude": 40.84839,
            "longitude": -73.9324
        },
        "name": "Chicken Ranch",
        "address": {
            "address1": "315 Audubon Ave",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10033",
            "country": "US",
            "state": "NY",
            "display_address": [
                "315 Audubon Ave",
                "New York, NY 10033"
            ]
        }
    },
    {
        "bid": "Lv-AInevkl29-9TOvvYLSA",
        "rating": 4.5,
        "reviews": 115,
        "coordinates": {
            "latitude": 40.8469435327016,
            "longitude": -74.082661940591
        },
        "name": "Sparta Taverna",
        "address": {
            "address1": "202 Hackensack St",
            "address2": None,
            "address3": "",
            "city": "Wood-Ridge",
            "zip_code": "07075",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "202 Hackensack St",
                "Wood-Ridge, NJ 07075"
            ]
        }
    },
    {
        "bid": "trPF0KIleGw5SxiG0uNLKg",
        "rating": 3.5,
        "reviews": 169,
        "coordinates": {
            "latitude": 40.7372248917818,
            "longitude": -73.9907332509756
        },
        "name": "Rainbow Falafel",
        "address": {
            "address1": "26 E 17th St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10003",
            "country": "US",
            "state": "NY",
            "display_address": [
                "26 E 17th St",
                "New York, NY 10003"
            ]
        }
    },
    {
        "bid": "TemMTqYoDJ53doNF-PCKZA",
        "rating": 4.0,
        "reviews": 288,
        "coordinates": {
            "latitude": 40.5778011,
            "longitude": -73.9557381
        },
        "name": "Cafe Kashkar",
        "address": {
            "address1": "1141 Brighton Beach Ave",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11235",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1141 Brighton Beach Ave",
                "Brooklyn, NY 11235"
            ]
        }
    },
    {
        "bid": "S-wgHMUZ_eODGFabjSSpMQ",
        "rating": 4.5,
        "reviews": 203,
        "coordinates": {
            "latitude": 40.7451551,
            "longitude": -74.2554328
        },
        "name": "Jackie and Son",
        "address": {
            "address1": "134 S Orange Ave",
            "address2": "",
            "address3": None,
            "city": "South Orange",
            "zip_code": "07079",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "134 S Orange Ave",
                "South Orange, NJ 07079"
            ]
        }
    },
    {
        "bid": "PXNYHyYlMIeW-tHAJfeWrA",
        "rating": 4.0,
        "reviews": 21,
        "coordinates": {
            "latitude": 40.7517080181873,
            "longitude": -73.9794427706933
        },
        "name": "Dill & Parsley",
        "address": {
            "address1": "295 Madison Ave",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10017",
            "country": "US",
            "state": "NY",
            "display_address": [
                "295 Madison Ave",
                "New York, NY 10017"
            ]
        }
    },
    {
        "bid": "zm7BScbpr6Tv9zcnnOYjcQ",
        "rating": 4.5,
        "reviews": 95,
        "coordinates": {
            "latitude": 40.82341,
            "longitude": -73.98964
        },
        "name": "Hakki Baba",
        "address": {
            "address1": "555 Anderson Ave",
            "address2": "",
            "address3": "",
            "city": "Cliffside Park",
            "zip_code": "07010",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "555 Anderson Ave",
                "Cliffside Park, NJ 07010"
            ]
        }
    },
    {
        "bid": "SnKjKXsPmJmiz3RcSugWyw",
        "rating": 4.0,
        "reviews": 28,
        "coordinates": {
            "latitude": 40.77435,
            "longitude": -73.98081
        },
        "name": "The Migrant Kitchen - Upper West Side",
        "address": {
            "address1": "157 Columbus Ave",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10023",
            "country": "US",
            "state": "NY",
            "display_address": [
                "157 Columbus Ave",
                "New York, NY 10023"
            ]
        }
    },
    {
        "bid": "32CvgNcoc5A1lj7ioLzUQQ",
        "rating": 4.0,
        "reviews": 578,
        "coordinates": {
            "latitude": 40.80223,
            "longitude": -73.64676
        },
        "name": "Kyma",
        "address": {
            "address1": "1446 Old Northern Blvd",
            "address2": "",
            "address3": "",
            "city": "Roslyn",
            "zip_code": "11576",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1446 Old Northern Blvd",
                "Roslyn, NY 11576"
            ]
        }
    },
    {
        "bid": "cLIKuW950x5Tq9xMuUmnRw",
        "rating": 4.5,
        "reviews": 47,
        "coordinates": {
            "latitude": 40.8889878,
            "longitude": -74.1114663
        },
        "name": "Al Yamama Grill",
        "address": {
            "address1": "347 Lanza Ave",
            "address2": None,
            "address3": "",
            "city": "Garfield",
            "zip_code": "07026",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "347 Lanza Ave",
                "Garfield, NJ 07026"
            ]
        }
    },
    {
        "bid": "86rhgcF5GTtkF0gcXnaHnA",
        "rating": 4.0,
        "reviews": 2,
        "coordinates": {
            "latitude": 40.7695785,
            "longitude": -74.1948847
        },
        "name": "The Gyro Platter",
        "address": {
            "address1": "67 Hoffman Blvd",
            "address2": None,
            "address3": None,
            "city": "East Orange",
            "zip_code": "07017",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "67 Hoffman Blvd",
                "East Orange, NJ 07017"
            ]
        }
    },
    {
        "bid": "PSDZlIqct5Bc_azE-tio9A",
        "rating": 4.0,
        "reviews": 161,
        "coordinates": {
            "latitude": 40.7941619,
            "longitude": -74.1290739
        },
        "name": "Mykonos Restaurant",
        "address": {
            "address1": "440 Ridge Rd",
            "address2": "",
            "address3": "",
            "city": "North Arlington",
            "zip_code": "07031",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "440 Ridge Rd",
                "North Arlington, NJ 07031"
            ]
        }
    },
    {
        "bid": "6nl1ScQaYV8y9DjCiNfaTg",
        "rating": 4.0,
        "reviews": 16,
        "coordinates": {
            "latitude": 40.831288,
            "longitude": -73.992764
        },
        "name": "Cafe Mekan",
        "address": {
            "address1": "693 Bergen Boulvard",
            "address2": None,
            "address3": "",
            "city": "Ridgefield",
            "zip_code": "07657",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "693 Bergen Boulvard",
                "Ridgefield, NJ 07657"
            ]
        }
    },
    {
        "bid": "flBpil_5irQ4CKO4FAY6gA",
        "rating": 4.5,
        "reviews": 257,
        "coordinates": {
            "latitude": 40.8270225524902,
            "longitude": -74.1044387817383
        },
        "name": "Greek Town Gyros",
        "address": {
            "address1": "65 Park Ave",
            "address2": "",
            "address3": "",
            "city": "Rutherford",
            "zip_code": "07070",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "65 Park Ave",
                "Rutherford, NJ 07070"
            ]
        }
    },
    {
        "bid": "dT4fl34s1MQaLQARc5BSFw",
        "rating": 3.5,
        "reviews": 695,
        "coordinates": {
            "latitude": 40.721009372316,
            "longitude": -73.846807820392
        },
        "name": "Agora Taverna",
        "address": {
            "address1": "70-09 Austin St",
            "address2": "",
            "address3": "",
            "city": "Forest Hills",
            "zip_code": "11375",
            "country": "US",
            "state": "NY",
            "display_address": [
                "70-09 Austin St",
                "Forest Hills, NY 11375"
            ]
        }
    },
    {
        "bid": "rBnGSfnZS303n5DV8nY-Sw",
        "rating": 4.5,
        "reviews": 27,
        "coordinates": {
            "latitude": 40.87738,
            "longitude": -74.02519
        },
        "name": "Mediterranean To Go",
        "address": {
            "address1": "352 Palisade Ave",
            "address2": "",
            "address3": "",
            "city": "Bogota",
            "zip_code": "07603",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "352 Palisade Ave",
                "Bogota, NJ 07603"
            ]
        }
    },
    {
        "bid": "MH08_pIRKsUSwfkVYxUE7w",
        "rating": 4.0,
        "reviews": 599,
        "coordinates": {
            "latitude": 40.80668,
            "longitude": -73.95395
        },
        "name": "Vinater\u00eda",
        "address": {
            "address1": "2211 Frederick Douglass Blvd",
            "address2": None,
            "address3": "",
            "city": "Harlem",
            "zip_code": "10026",
            "country": "US",
            "state": "NY",
            "display_address": [
                "2211 Frederick Douglass Blvd",
                "Harlem, NY 10026"
            ]
        }
    },
    {
        "bid": "mb8b2PdYGe2Nf2tsZpzIiA",
        "rating": 3.0,
        "reviews": 330,
        "coordinates": {
            "latitude": 40.74679,
            "longitude": -73.99172
        },
        "name": "Mykonos Bleu",
        "address": {
            "address1": "127 W 28th St",
            "address2": None,
            "address3": None,
            "city": "New York",
            "zip_code": "10001",
            "country": "US",
            "state": "NY",
            "display_address": [
                "127 W 28th St",
                "New York, NY 10001"
            ]
        }
    },
    {
        "bid": "1_vyc6Z4a78TFMbaCjWqDQ",
        "rating": 4.5,
        "reviews": 147,
        "coordinates": {
            "latitude": 40.762035,
            "longitude": -73.942101
        },
        "name": "3Greeks Grill",
        "address": {
            "address1": "3561 Vernon Blvd",
            "address2": "",
            "address3": "",
            "city": "Long Island City",
            "zip_code": "11106",
            "country": "US",
            "state": "NY",
            "display_address": [
                "3561 Vernon Blvd",
                "Long Island City, NY 11106"
            ]
        }
    },
    {
        "bid": "rrxcBTWS827bJ4oBr5a_ww",
        "rating": 3.5,
        "reviews": 314,
        "coordinates": {
            "latitude": 40.8043464658849,
            "longitude": -73.9556999961065
        },
        "name": "Silvana",
        "address": {
            "address1": "300 W 116th St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10026",
            "country": "US",
            "state": "NY",
            "display_address": [
                "300 W 116th St",
                "New York, NY 10026"
            ]
        }
    },
    {
        "bid": "JdNzj7EGQLC9eqqw3SYBPg",
        "rating": 4.0,
        "reviews": 489,
        "coordinates": {
            "latitude": 40.73088285012182,
            "longitude": -74.00079123783922
        },
        "name": "Organic Grill",
        "address": {
            "address1": "133 W 3rd St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10012",
            "country": "US",
            "state": "NY",
            "display_address": [
                "133 W 3rd St",
                "New York, NY 10012"
            ]
        }
    },
    {
        "bid": "pu4KH8QCseFEMnGi27jiCQ",
        "rating": 5.0,
        "reviews": 35,
        "coordinates": {
            "latitude": 40.301046,
            "longitude": -73.978988
        },
        "name": "The Hummus Republic",
        "address": {
            "address1": "84 Ocean Ave",
            "address2": None,
            "address3": "",
            "city": "Long Branch",
            "zip_code": "07740",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "84 Ocean Ave",
                "Long Branch, NJ 07740"
            ]
        }
    },
    {
        "bid": "7U6ECqnbmJvKmSCidFuThw",
        "rating": 4.5,
        "reviews": 36,
        "coordinates": {
            "latitude": 40.59756,
            "longitude": -74.28989
        },
        "name": "Madina Halal Platter",
        "address": {
            "address1": "395 St George Ave",
            "address2": "",
            "address3": None,
            "city": "Rahway",
            "zip_code": "07065",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "395 St George Ave",
                "Rahway, NJ 07065"
            ]
        }
    },
    {
        "bid": "VGTrGSH38A4n-v5nFe4skA",
        "rating": 4.5,
        "reviews": 477,
        "coordinates": {
            "latitude": 40.7576813278964,
            "longitude": -73.9732953737526
        },
        "name": "Uncle Gussy's",
        "address": {
            "address1": "345 Park Ave",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10154",
            "country": "US",
            "state": "NY",
            "display_address": [
                "345 Park Ave",
                "New York, NY 10154"
            ]
        }
    },
    {
        "bid": "FON3TceJNsTC0I0mzBwOKg",
        "rating": 3.5,
        "reviews": 1243,
        "coordinates": {
            "latitude": 40.75938,
            "longitude": -73.97558
        },
        "name": "Fig & Olive",
        "address": {
            "address1": "10 E 52nd St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10022",
            "country": "US",
            "state": "NY",
            "display_address": [
                "10 E 52nd St",
                "New York, NY 10022"
            ]
        }
    },
    {
        "bid": "KQ3b0rxCBnwKF0AHWjcJpg",
        "rating": 4.0,
        "reviews": 375,
        "coordinates": {
            "latitude": 40.761003859362,
            "longitude": -73.9229999999999
        },
        "name": "Amylos Taverna",
        "address": {
            "address1": "33-19 Broadway",
            "address2": "",
            "address3": None,
            "city": "Astoria",
            "zip_code": "11106",
            "country": "US",
            "state": "NY",
            "display_address": [
                "33-19 Broadway",
                "Astoria, NY 11106"
            ]
        }
    },
    {
        "bid": "CMaKcJbkj-hn1We0ecVt3Q",
        "rating": 3.5,
        "reviews": 54,
        "coordinates": {
            "latitude": 40.71571,
            "longitude": -74.0075
        },
        "name": "Soup & Gyro Turkish Mediterranean Restaurant",
        "address": {
            "address1": "178A Church St",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10013",
            "country": "US",
            "state": "NY",
            "display_address": [
                "178A Church St",
                "New York, NY 10013"
            ]
        }
    },
    {
        "bid": "l7vpI5VGSAsJOsZc2DLYnQ",
        "rating": 4.5,
        "reviews": 11,
        "coordinates": {
            "latitude": 40.718056,
            "longitude": -73.988081
        },
        "name": "Kotti Berliner D\u00f6ner Kebab",
        "address": {
            "address1": "88 Essex St",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10002",
            "country": "US",
            "state": "NY",
            "display_address": [
                "88 Essex St",
                "New York, NY 10002"
            ]
        }
    },
    {
        "bid": "_MfIjyAh82uKoVU39Z7eDg",
        "rating": 4.5,
        "reviews": 95,
        "coordinates": {
            "latitude": 40.99167,
            "longitude": -74.03273
        },
        "name": "The Kebab\u00e7i West",
        "address": {
            "address1": "417 Broadway",
            "address2": "",
            "address3": None,
            "city": "Westwood",
            "zip_code": "07675",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "417 Broadway",
                "Westwood, NJ 07675"
            ]
        }
    },
    {
        "bid": "q8phYyHb3-zBLKSrReKIww",
        "rating": 4.0,
        "reviews": 23,
        "coordinates": {
            "latitude": 40.780343,
            "longitude": -73.793616
        },
        "name": "Mezze",
        "address": {
            "address1": "19-03 Utopia Pkwy",
            "address2": None,
            "address3": "",
            "city": "Whitestone",
            "zip_code": "11357",
            "country": "US",
            "state": "NY",
            "display_address": [
                "19-03 Utopia Pkwy",
                "Whitestone, NY 11357"
            ]
        }
    },
    {
        "bid": "jeaGvCdBqXjeIKA3pSDs_Q",
        "rating": 4.5,
        "reviews": 42,
        "coordinates": {
            "latitude": 40.7949043,
            "longitude": -74.4789827
        },
        "name": "Hummus Republic",
        "address": {
            "address1": "66 South St",
            "address2": "",
            "address3": None,
            "city": "Morristown",
            "zip_code": "07960",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "66 South St",
                "Morristown, NJ 07960"
            ]
        }
    },
    {
        "bid": "hDgpiXE5_d4Is1sJ5kUBQg",
        "rating": 4.0,
        "reviews": 828,
        "coordinates": {
            "latitude": 40.74492841946161,
            "longitude": -73.9837861
        },
        "name": "Wine 30",
        "address": {
            "address1": "41 E 30th St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10016",
            "country": "US",
            "state": "NY",
            "display_address": [
                "41 E 30th St",
                "New York, NY 10016"
            ]
        }
    },
    {
        "bid": "ca87UUQLsgjbVvHWg8Su6A",
        "rating": 4.5,
        "reviews": 219,
        "coordinates": {
            "latitude": 40.749021,
            "longitude": -73.684393
        },
        "name": "Afghan Grill",
        "address": {
            "address1": "1629 Hillside Ave",
            "address2": "",
            "address3": "",
            "city": "New Hyde Park",
            "zip_code": "11040",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1629 Hillside Ave",
                "New Hyde Park, NY 11040"
            ]
        }
    },
    {
        "bid": "MOTbxLDT6QcN9kbn691tYA",
        "rating": 5.0,
        "reviews": 2,
        "coordinates": {
            "latitude": 40.53867511571532,
            "longitude": -74.42252286718663
        },
        "name": "Qaswa BBQ & Grill",
        "address": {
            "address1": "1412 Stelton Rd",
            "address2": "Ste 2",
            "address3": None,
            "city": "Piscataway",
            "zip_code": "08854",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "1412 Stelton Rd",
                "Ste 2",
                "Piscataway, NJ 08854"
            ]
        }
    },
    {
        "bid": "eM2gw8PTUHQXsf5OLRDbTg",
        "rating": 4.5,
        "reviews": 7,
        "coordinates": {
            "latitude": 40.623782,
            "longitude": -74.330433
        },
        "name": "Blue Jasmine Cafe",
        "address": {
            "address1": "2120 Lamberts Mill Rd",
            "address2": None,
            "address3": "",
            "city": "Scotch Plains",
            "zip_code": "07076",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "2120 Lamberts Mill Rd",
                "Scotch Plains, NJ 07076"
            ]
        }
    },
    {
        "bid": "FvnExtQHPfz_crDCBTQ1iQ",
        "rating": 4.0,
        "reviews": 343,
        "coordinates": {
            "latitude": 40.729513,
            "longitude": -74.001138
        },
        "name": "Mint Masala",
        "address": {
            "address1": "95 Macdougal St",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10012",
            "country": "US",
            "state": "NY",
            "display_address": [
                "95 Macdougal St",
                "New York, NY 10012"
            ]
        }
    },
    {
        "bid": "7zUYzHfjVdln5TYgkazgDg",
        "rating": 4.0,
        "reviews": 167,
        "coordinates": {
            "latitude": 40.893301216705,
            "longitude": -73.973325151939
        },
        "name": "Hummus Elite",
        "address": {
            "address1": "39 E Palisade Ave",
            "address2": "",
            "address3": "",
            "city": "Englewood",
            "zip_code": "07631",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "39 E Palisade Ave",
                "Englewood, NJ 07631"
            ]
        }
    },
    {
        "bid": "MHuhN-URZQ22Anrpu6juhg",
        "rating": 4.0,
        "reviews": 128,
        "coordinates": {
            "latitude": 40.7334864923026,
            "longitude": -73.8250243663788
        },
        "name": "Main Bakhtar Halal Kabab",
        "address": {
            "address1": "67-29 Main St",
            "address2": "",
            "address3": "",
            "city": "Flushing",
            "zip_code": "11367",
            "country": "US",
            "state": "NY",
            "display_address": [
                "67-29 Main St",
                "Flushing, NY 11367"
            ]
        }
    },
    {
        "bid": "2cNN79haPaS0zyaV-eQB3Q",
        "rating": 4.0,
        "reviews": 167,
        "coordinates": {
            "latitude": 40.721403221060115,
            "longitude": -74.28829421167309
        },
        "name": "Porto Falafel",
        "address": {
            "address1": "2933 Vauxhall Rd",
            "address2": "",
            "address3": None,
            "city": "Vauxhall",
            "zip_code": "07088",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "2933 Vauxhall Rd",
                "Vauxhall, NJ 07088"
            ]
        }
    },
    {
        "bid": "ajo-X0Z4MjQgIxja1VY_rQ",
        "rating": 4.0,
        "reviews": 285,
        "coordinates": {
            "latitude": 40.72475085775584,
            "longitude": -73.54825470211678
        },
        "name": "Azerbaijan Grill",
        "address": {
            "address1": "2366 Hempstead Tpke",
            "address2": None,
            "address3": "",
            "city": "East Meadow ",
            "zip_code": "11554",
            "country": "US",
            "state": "NY",
            "display_address": [
                "2366 Hempstead Tpke",
                "East Meadow , NY 11554"
            ]
        }
    },
    {
        "bid": "K6XxfhaQ5AAcYqDpTA-tBA",
        "rating": 4.0,
        "reviews": 116,
        "coordinates": {
            "latitude": 40.8408466432458,
            "longitude": -74.2081782117971
        },
        "name": "Toros - Montclair",
        "address": {
            "address1": "594 Valley Rd",
            "address2": "",
            "address3": None,
            "city": "Montclair",
            "zip_code": "07043",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "594 Valley Rd",
                "Montclair, NJ 07043"
            ]
        }
    },
    {
        "bid": "PELbdHCpKUexQiE7UjdasA",
        "rating": 4.5,
        "reviews": 84,
        "coordinates": {
            "latitude": 40.879569,
            "longitude": -74.041223
        },
        "name": "Platters Corner",
        "address": {
            "address1": "60 River St",
            "address2": None,
            "address3": "",
            "city": "Hackensack",
            "zip_code": "07601",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "60 River St",
                "Hackensack, NJ 07601"
            ]
        }
    },
    {
        "bid": "tg2I4TLCUNr_llG2xLE4sg",
        "rating": 4.0,
        "reviews": 425,
        "coordinates": {
            "latitude": 40.7437839950329,
            "longitude": -73.9221807731946
        },
        "name": "Turkish Grill",
        "address": {
            "address1": "42-03 Queens Blvd",
            "address2": "",
            "address3": "",
            "city": "Sunnyside",
            "zip_code": "11104",
            "country": "US",
            "state": "NY",
            "display_address": [
                "42-03 Queens Blvd",
                "Sunnyside, NY 11104"
            ]
        }
    },
    {
        "bid": "VWiKAEzdATXDYxdomqQ9Ig",
        "rating": 4.0,
        "reviews": 121,
        "coordinates": {
            "latitude": 40.824644114832495,
            "longitude": -73.94780920000001
        },
        "name": "Falafel Tarboosh",
        "address": {
            "address1": "1701 Amsterdam Ave",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10031",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1701 Amsterdam Ave",
                "New York, NY 10031"
            ]
        }
    },
    {
        "bid": "gf3xwZf-YGGm2oWXZFVqOQ",
        "rating": 4.5,
        "reviews": 39,
        "coordinates": {
            "latitude": 40.68340210569663,
            "longitude": -73.35501756684424
        },
        "name": "Taheni Mediteranean Grill",
        "address": {
            "address1": "296 E Montauk Hwy",
            "address2": "",
            "address3": None,
            "city": "Lindenhurst",
            "zip_code": "11757",
            "country": "US",
            "state": "NY",
            "display_address": [
                "296 E Montauk Hwy",
                "Lindenhurst, NY 11757"
            ]
        }
    },
    {
        "bid": "LAX6ELNSSvYpGPhWnWkycA",
        "rating": 4.0,
        "reviews": 148,
        "coordinates": {
            "latitude": 40.7581395,
            "longitude": -74.4142198
        },
        "name": "Biladi Grill",
        "address": {
            "address1": "77 Main St",
            "address2": "",
            "address3": "",
            "city": "Madison",
            "zip_code": "07940",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "77 Main St",
                "Madison, NJ 07940"
            ]
        }
    },
    {
        "bid": "oucUhaQjSEeJb2F3rVRR_Q",
        "rating": 3.5,
        "reviews": 495,
        "coordinates": {
            "latitude": 40.72152,
            "longitude": -74.00142
        },
        "name": "Antique Garage Soho",
        "address": {
            "address1": "41 Mercer St",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10013",
            "country": "US",
            "state": "NY",
            "display_address": [
                "41 Mercer St",
                "New York, NY 10013"
            ]
        }
    },
    {
        "bid": "oDB5B9w2emjU9pbPP573QA",
        "rating": 3.0,
        "reviews": 70,
        "coordinates": {
            "latitude": 40.83265,
            "longitude": -73.69869
        },
        "name": "Ayhan's Mediterranean Marketplace",
        "address": {
            "address1": "293 Main St",
            "address2": "",
            "address3": "",
            "city": "Port Washington",
            "zip_code": "11050",
            "country": "US",
            "state": "NY",
            "display_address": [
                "293 Main St",
                "Port Washington, NY 11050"
            ]
        }
    },
    {
        "bid": "C9khKyGgZY8S-JjK9FowKg",
        "rating": 4.5,
        "reviews": 156,
        "coordinates": {
            "latitude": 40.88375,
            "longitude": -74.24461
        },
        "name": "Cappadocia Restaurant",
        "address": {
            "address1": "117 Newark Pompton Tpke",
            "address2": None,
            "address3": "",
            "city": "Little Falls",
            "zip_code": "07424",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "117 Newark Pompton Tpke",
                "Little Falls, NJ 07424"
            ]
        }
    },
    {
        "bid": "VTvRzP_NMQS5WDIcx-M2WQ",
        "rating": 4.5,
        "reviews": 269,
        "coordinates": {
            "latitude": 40.35151,
            "longitude": -74.07505
        },
        "name": "Greek Spot the Restaurant",
        "address": {
            "address1": "15 North Bridge Ave",
            "address2": None,
            "address3": "",
            "city": "Red Bank",
            "zip_code": "07701",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "15 North Bridge Ave",
                "Red Bank, NJ 07701"
            ]
        }
    },
    {
        "bid": "YpIMMamKh0jTAd4bpedbqA",
        "rating": 4.5,
        "reviews": 186,
        "coordinates": {
            "latitude": 40.5927,
            "longitude": -74.24199
        },
        "name": "The Halal Spot",
        "address": {
            "address1": "1249 Roosevelt Ave",
            "address2": None,
            "address3": "",
            "city": "Carteret",
            "zip_code": "07008",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "1249 Roosevelt Ave",
                "Carteret, NJ 07008"
            ]
        }
    },
    {
        "bid": "PpxJsItHTF6sDAK6XnDJ9w",
        "rating": 4.0,
        "reviews": 649,
        "coordinates": {
            "latitude": 40.733163,
            "longitude": -73.986158
        },
        "name": "Bite",
        "address": {
            "address1": "211 E 14th St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10003",
            "country": "US",
            "state": "NY",
            "display_address": [
                "211 E 14th St",
                "New York, NY 10003"
            ]
        }
    },
    {
        "bid": "vYmV8YA7Gam5z31VIrO0ug",
        "rating": 4.5,
        "reviews": 132,
        "coordinates": {
            "latitude": 40.7056003,
            "longitude": -73.6578854
        },
        "name": "Turkuaz Mediterranean Gourmet",
        "address": {
            "address1": "493 Hempstead Tpke",
            "address2": None,
            "address3": "",
            "city": "West Hempstead",
            "zip_code": "11552",
            "country": "US",
            "state": "NY",
            "display_address": [
                "493 Hempstead Tpke",
                "West Hempstead, NY 11552"
            ]
        }
    },
    {
        "bid": "a7BC1doUjNDqrqTaAMmfZg",
        "rating": 4.0,
        "reviews": 288,
        "coordinates": {
            "latitude": 40.7257318645125,
            "longitude": -73.9946338116395
        },
        "name": "Bite",
        "address": {
            "address1": "335 Lafayette St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10012",
            "country": "US",
            "state": "NY",
            "display_address": [
                "335 Lafayette St",
                "New York, NY 10012"
            ]
        }
    },
    {
        "bid": "TJhgvNJuAzmyYzaMyMnN0Q",
        "rating": 4.0,
        "reviews": 183,
        "coordinates": {
            "latitude": 40.71745,
            "longitude": -73.85674
        },
        "name": "Village Grill",
        "address": {
            "address1": "7301 Yellowstone Blvd",
            "address2": "",
            "address3": "",
            "city": "Forest Hills",
            "zip_code": "11375",
            "country": "US",
            "state": "NY",
            "display_address": [
                "7301 Yellowstone Blvd",
                "Forest Hills, NY 11375"
            ]
        }
    },
    {
        "bid": "N51w2HM8ODZWyDKn9KcVvA",
        "rating": 4.0,
        "reviews": 230,
        "coordinates": {
            "latitude": 40.6514550017949,
            "longitude": -74.0035843849182
        },
        "name": "Kofte Piyaz",
        "address": {
            "address1": "881 5th Ave",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11232",
            "country": "US",
            "state": "NY",
            "display_address": [
                "881 5th Ave",
                "Brooklyn, NY 11232"
            ]
        }
    },
    {
        "bid": "CyIf24YrOuiikkYVnHjoog",
        "rating": 4.0,
        "reviews": 302,
        "coordinates": {
            "latitude": 40.7183319967204,
            "longitude": -74.0439149770278
        },
        "name": "Uncle Momo",
        "address": {
            "address1": "289 Grove St",
            "address2": "",
            "address3": None,
            "city": "Jersey City",
            "zip_code": "07302",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "289 Grove St",
                "Jersey City, NJ 07302"
            ]
        }
    },
    {
        "bid": "p-PJcI8SYIi_mowY5svQOA",
        "rating": 3.5,
        "reviews": 488,
        "coordinates": {
            "latitude": 40.72638,
            "longitude": -73.98904
        },
        "name": "Nomad",
        "address": {
            "address1": "78 2nd Ave",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10003",
            "country": "US",
            "state": "NY",
            "display_address": [
                "78 2nd Ave",
                "New York, NY 10003"
            ]
        }
    },
    {
        "bid": "m6LF4_uSdR4snHgASMMcBA",
        "rating": 4.5,
        "reviews": 59,
        "coordinates": {
            "latitude": 40.628975,
            "longitude": -74.028633
        },
        "name": "Little Athens NY",
        "address": {
            "address1": "7809 3rd Ave",
            "address2": None,
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11209",
            "country": "US",
            "state": "NY",
            "display_address": [
                "7809 3rd Ave",
                "Brooklyn, NY 11209"
            ]
        }
    },
    {
        "bid": "BLRQ4yv240jpLaMQmOBoWw",
        "rating": 4.5,
        "reviews": 268,
        "coordinates": {
            "latitude": 40.33269,
            "longitude": -74.0724
        },
        "name": "Bayroot",
        "address": {
            "address1": "555 Shrewsbury Ave",
            "address2": "",
            "address3": "",
            "city": "Shrewsbury",
            "zip_code": "07702",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "555 Shrewsbury Ave",
                "Shrewsbury, NJ 07702"
            ]
        }
    },
    {
        "bid": "SpQNLrNqbDUmBRKs_ABpDQ",
        "rating": 4.0,
        "reviews": 52,
        "coordinates": {
            "latitude": 40.80336145444024,
            "longitude": -73.64566570263398
        },
        "name": "Limani Mezze",
        "address": {
            "address1": "1512 Old Northern Blvd",
            "address2": "",
            "address3": None,
            "city": "Roslyn",
            "zip_code": "11576",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1512 Old Northern Blvd",
                "Roslyn, NY 11576"
            ]
        }
    },
    {
        "bid": "V3LxcyGfHInU_7F5dnOfVw",
        "rating": 4.5,
        "reviews": 95,
        "coordinates": {
            "latitude": 40.826537,
            "longitude": -73.987058
        },
        "name": "Nefista Vegan Kofteh",
        "address": {
            "address1": "656 Anderson Ave",
            "address2": None,
            "address3": None,
            "city": "Cliffside Park",
            "zip_code": "07010",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "656 Anderson Ave",
                "Cliffside Park, NJ 07010"
            ]
        }
    },
    {
        "bid": "KfpNzpE0MiMUoVSN6FFdpw",
        "rating": 4.0,
        "reviews": 243,
        "coordinates": {
            "latitude": 40.8959031,
            "longitude": -74.0657647
        },
        "name": "Angelo's Greek Taverna",
        "address": {
            "address1": "245 Maywood Ave",
            "address2": "",
            "address3": "",
            "city": "Maywood",
            "zip_code": "07607",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "245 Maywood Ave",
                "Maywood, NJ 07607"
            ]
        }
    },
    {
        "bid": "ci9LG3eh4ZATHWmy5Lsw0A",
        "rating": 4.5,
        "reviews": 348,
        "coordinates": {
            "latitude": 40.7720901,
            "longitude": -73.5269623
        },
        "name": "Kabul Grill",
        "address": {
            "address1": "129 N Broadway",
            "address2": "",
            "address3": "",
            "city": "Hicksville",
            "zip_code": "11801",
            "country": "US",
            "state": "NY",
            "display_address": [
                "129 N Broadway",
                "Hicksville, NY 11801"
            ]
        }
    },
    {
        "bid": "pk3JzGBX28kpFo-IRGwBEQ",
        "rating": 3.5,
        "reviews": 4,
        "coordinates": {
            "latitude": 40.81671,
            "longitude": -73.95774
        },
        "name": "Shai Hummusiya",
        "address": {
            "address1": "3229 Broadway",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10027",
            "country": "US",
            "state": "NY",
            "display_address": [
                "3229 Broadway",
                "New York, NY 10027"
            ]
        }
    },
    {
        "bid": "zSB4-uiRUVbNJWBy7ZkDjw",
        "rating": 4.0,
        "reviews": 74,
        "coordinates": {
            "latitude": 41.002327599794995,
            "longitude": -74.32617308220874
        },
        "name": "Kabob House Mediterranean Grill",
        "address": {
            "address1": "42 Main St",
            "address2": "",
            "address3": None,
            "city": "Bloomingdale",
            "zip_code": "07403",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "42 Main St",
                "Bloomingdale, NJ 07403"
            ]
        }
    },
    {
        "bid": "8KotY_L_CXJTD63YrRAdeA",
        "rating": 4.5,
        "reviews": 111,
        "coordinates": {
            "latitude": 40.8141352096874,
            "longitude": -74.1635080235389
        },
        "name": "Gabriella's Place Lebanese Cuisine",
        "address": {
            "address1": "177 Franklin Ave",
            "address2": "",
            "address3": "",
            "city": "Nutley",
            "zip_code": "07110",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "177 Franklin Ave",
                "Nutley, NJ 07110"
            ]
        }
    },
    {
        "bid": "dYan0dlBcbyOrcNet_Mfmg",
        "rating": 4.5,
        "reviews": 7,
        "coordinates": {
            "latitude": 40.7907309,
            "longitude": -74.0230121
        },
        "name": "El Jardin",
        "address": {
            "address1": "5819 John F Kennedy Blvd",
            "address2": None,
            "address3": "",
            "city": "North Bergen",
            "zip_code": "07047",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "5819 John F Kennedy Blvd",
                "North Bergen, NJ 07047"
            ]
        }
    },
    {
        "bid": "xGXnRoxjhniDJlGoi56xVQ",
        "rating": 4.0,
        "reviews": 8,
        "coordinates": {
            "latitude": 40.617547,
            "longitude": -73.730448
        },
        "name": "Mur",
        "address": {
            "address1": "310 Central Ave",
            "address2": "",
            "address3": None,
            "city": "Lawrence",
            "zip_code": "11559",
            "country": "US",
            "state": "NY",
            "display_address": [
                "310 Central Ave",
                "Lawrence, NY 11559"
            ]
        }
    },
    {
        "bid": "ZJtg5RVPRQUUvdDboWX94g",
        "rating": 4.0,
        "reviews": 162,
        "coordinates": {
            "latitude": 40.605021,
            "longitude": -73.980301
        },
        "name": "Mera ",
        "address": {
            "address1": "282 Kings Hwy",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11223",
            "country": "US",
            "state": "NY",
            "display_address": [
                "282 Kings Hwy",
                "Brooklyn, NY 11223"
            ]
        }
    },
    {
        "bid": "ShZamNKgSkv8XKDnjE0kPw",
        "rating": 3.5,
        "reviews": 138,
        "coordinates": {
            "latitude": 40.8284782,
            "longitude": -74.1001848
        },
        "name": "Eros Cafe",
        "address": {
            "address1": "168 Union Ave",
            "address2": "",
            "address3": "",
            "city": "East Rutherford",
            "zip_code": "07073",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "168 Union Ave",
                "East Rutherford, NJ 07073"
            ]
        }
    },
    {
        "bid": "YYUvrFhpG22sbP7RFRaxvQ",
        "rating": 4.0,
        "reviews": 235,
        "coordinates": {
            "latitude": 40.7297819256055,
            "longitude": -73.8236096230523
        },
        "name": "Grill Point",
        "address": {
            "address1": "69-54 Main St",
            "address2": "",
            "address3": "",
            "city": "Flushing",
            "zip_code": "11367",
            "country": "US",
            "state": "NY",
            "display_address": [
                "69-54 Main St",
                "Flushing, NY 11367"
            ]
        }
    },
    {
        "bid": "TMKUWtlTdXRyDBWgi0hl3w",
        "rating": 4.0,
        "reviews": 170,
        "coordinates": {
            "latitude": 40.8803035787814,
            "longitude": -74.1454234695392
        },
        "name": "Yasmeen",
        "address": {
            "address1": "247 Piaget Ave",
            "address2": None,
            "address3": "",
            "city": "Clifton",
            "zip_code": "07011",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "247 Piaget Ave",
                "Clifton, NJ 07011"
            ]
        }
    },
    {
        "bid": "IbB_7AxWQtDFW1iKnoD1Ug",
        "rating": 4.0,
        "reviews": 409,
        "coordinates": {
            "latitude": 40.71165,
            "longitude": -73.94529
        },
        "name": "BK JANI",
        "address": {
            "address1": "679 Grand St",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11211",
            "country": "US",
            "state": "NY",
            "display_address": [
                "679 Grand St",
                "Brooklyn, NY 11211"
            ]
        }
    },
    {
        "bid": "PHSsvGDW6Rh2pGWEDTrDew",
        "rating": 4.0,
        "reviews": 651,
        "coordinates": {
            "latitude": 40.75105092190377,
            "longitude": -74.00194808204913
        },
        "name": "Death Ave",
        "address": {
            "address1": "315 10th Ave",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10001",
            "country": "US",
            "state": "NY",
            "display_address": [
                "315 10th Ave",
                "New York, NY 10001"
            ]
        }
    },
    {
        "bid": "CXZReO6zwmf9j54gXY0Tog",
        "rating": 4.5,
        "reviews": 58,
        "coordinates": {
            "latitude": 40.833363,
            "longitude": -74.097152
        },
        "name": "Hot Kebabs City",
        "address": {
            "address1": "228 Paterson Ave",
            "address2": "",
            "address3": None,
            "city": "East Rutherford",
            "zip_code": "07073",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "228 Paterson Ave",
                "East Rutherford, NJ 07073"
            ]
        }
    },
    {
        "bid": "USQxn9Arz6tl-4AqtqpCkg",
        "rating": 3.5,
        "reviews": 199,
        "coordinates": {
            "latitude": 40.7070857,
            "longitude": -74.0080807
        },
        "name": "Pita Press",
        "address": {
            "address1": "25 Cedar St",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10005",
            "country": "US",
            "state": "NY",
            "display_address": [
                "25 Cedar St",
                "New York, NY 10005"
            ]
        }
    },
    {
        "bid": "Z4lxeWpTOMWn0r2KB_otxQ",
        "rating": 5.0,
        "reviews": 17,
        "coordinates": {
            "latitude": 40.8237134,
            "longitude": -74.2194458
        },
        "name": "Zachy On The Go",
        "address": {
            "address1": "150 Valley Rd",
            "address2": None,
            "address3": "",
            "city": "Montclair",
            "zip_code": "07042",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "150 Valley Rd",
                "Montclair, NJ 07042"
            ]
        }
    },
    {
        "bid": "N-M-c8yQFqGW1jn_tdCzPg",
        "rating": 4.5,
        "reviews": 224,
        "coordinates": {
            "latitude": 40.7090396819627,
            "longitude": -74.0113380915443
        },
        "name": "Sam's Falafel",
        "address": {
            "address1": "Cedar St And Broadway",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10006",
            "country": "US",
            "state": "NY",
            "display_address": [
                "Cedar St And Broadway",
                "New York, NY 10006"
            ]
        }
    },
    {
        "bid": "DRBx2Kyo9lzDlsggp-ENqA",
        "rating": 4.5,
        "reviews": 547,
        "coordinates": {
            "latitude": 41.1034092,
            "longitude": -73.5485603
        },
        "name": "Layla's Falafel",
        "address": {
            "address1": "936 High Ridge Rd",
            "address2": None,
            "address3": "",
            "city": "Stamford",
            "zip_code": "06905",
            "country": "US",
            "state": "CT",
            "display_address": [
                "936 High Ridge Rd",
                "Stamford, CT 06905"
            ]
        }
    },
    {
        "bid": "U45dUNzVKs2KlM5HRgbDGA",
        "rating": 4.0,
        "reviews": 49,
        "coordinates": {
            "latitude": 40.6843884,
            "longitude": -73.97883762807574
        },
        "name": "Halal International",
        "address": {
            "address1": "574 Atlantic Ave",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11217",
            "country": "US",
            "state": "NY",
            "display_address": [
                "574 Atlantic Ave",
                "Brooklyn, NY 11217"
            ]
        }
    },
    {
        "bid": "_IXwnlEd4DsiXuruRiRl9Q",
        "rating": 3.5,
        "reviews": 445,
        "coordinates": {
            "latitude": 40.75228,
            "longitude": -73.9795
        },
        "name": "Pera Mediterranean Brasserie",
        "address": {
            "address1": "303 Madison Ave",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10017",
            "country": "US",
            "state": "NY",
            "display_address": [
                "303 Madison Ave",
                "New York, NY 10017"
            ]
        }
    },
    {
        "bid": "tu3lu9iTFoPITkOM7art9A",
        "rating": 3.5,
        "reviews": 5,
        "coordinates": {
            "latitude": 40.7489301,
            "longitude": -73.8932955
        },
        "name": "Zam Zam Grill",
        "address": {
            "address1": "72-27 37th Ave",
            "address2": "",
            "address3": None,
            "city": "Jackson Heights",
            "zip_code": "11372",
            "country": "US",
            "state": "NY",
            "display_address": [
                "72-27 37th Ave",
                "Jackson Heights, NY 11372"
            ]
        }
    },
    {
        "bid": "XCpvVDi-eMDid3s6LrDIuw",
        "rating": 4.0,
        "reviews": 206,
        "coordinates": {
            "latitude": 40.7775898,
            "longitude": -73.9785419
        },
        "name": "Sido Falafel & More",
        "address": {
            "address1": "267 Columbus Ave",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10023",
            "country": "US",
            "state": "NY",
            "display_address": [
                "267 Columbus Ave",
                "New York, NY 10023"
            ]
        }
    },
    {
        "bid": "77RmZE8OkNBxSPniHIaoaw",
        "rating": 4.0,
        "reviews": 431,
        "coordinates": {
            "latitude": 40.818153,
            "longitude": -74.223335
        },
        "name": "Uncle Momo",
        "address": {
            "address1": "702 Bloomfield Ave",
            "address2": "",
            "address3": "",
            "city": "Montclair",
            "zip_code": "07042",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "702 Bloomfield Ave",
                "Montclair, NJ 07042"
            ]
        }
    },
    {
        "bid": "CGlVVVjJ0d8eKCAefOTS9w",
        "rating": 4.0,
        "reviews": 132,
        "coordinates": {
            "latitude": 40.760091,
            "longitude": -73.891977
        },
        "name": "Plaka",
        "address": {
            "address1": "75-61 31st Ave",
            "address2": "",
            "address3": "",
            "city": "East Elmhurst",
            "zip_code": "11370",
            "country": "US",
            "state": "NY",
            "display_address": [
                "75-61 31st Ave",
                "East Elmhurst, NY 11370"
            ]
        }
    },
    {
        "bid": "jCRblp7F5IbUSySK_Y7Qiw",
        "rating": 4.0,
        "reviews": 360,
        "coordinates": {
            "latitude": 40.74528,
            "longitude": -73.97588
        },
        "name": "EONS Greek Food for Life",
        "address": {
            "address1": "633 2nd Ave",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10016",
            "country": "US",
            "state": "NY",
            "display_address": [
                "633 2nd Ave",
                "New York, NY 10016"
            ]
        }
    },
    {
        "bid": "AdZ13ZEVD7t2h8PaEIbTbQ",
        "rating": 3.5,
        "reviews": 71,
        "coordinates": {
            "latitude": 40.666413,
            "longitude": -73.9506115
        },
        "name": "ALENbi",
        "address": {
            "address1": "887 Nostrand Ave",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11225",
            "country": "US",
            "state": "NY",
            "display_address": [
                "887 Nostrand Ave",
                "Brooklyn, NY 11225"
            ]
        }
    },
    {
        "bid": "RoIl1F0_4A94DdP_xy8Mwg",
        "rating": 4.5,
        "reviews": 316,
        "coordinates": {
            "latitude": 40.76835316283952,
            "longitude": -73.9111827338491
        },
        "name": "Sabry's",
        "address": {
            "address1": "2425 Steinway St",
            "address2": "",
            "address3": "",
            "city": "Astoria",
            "zip_code": "11103",
            "country": "US",
            "state": "NY",
            "display_address": [
                "2425 Steinway St",
                "Astoria, NY 11103"
            ]
        }
    },
    {
        "bid": "JhB5b1Z7wR1hfGCw3iUMRw",
        "rating": 4.0,
        "reviews": 107,
        "coordinates": {
            "latitude": 40.89698,
            "longitude": -73.97133
        },
        "name": "Rose's of Englewood",
        "address": {
            "address1": "126 Engle St",
            "address2": "",
            "address3": "",
            "city": "Englewood",
            "zip_code": "07631",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "126 Engle St",
                "Englewood, NJ 07631"
            ]
        }
    },
    {
        "bid": "s_YuHngBngWwzpcKNIM71A",
        "rating": 4.5,
        "reviews": 321,
        "coordinates": {
            "latitude": 40.723644,
            "longitude": -74.00325
        },
        "name": "Pi Bakerie",
        "address": {
            "address1": "512 Broome St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10013",
            "country": "US",
            "state": "NY",
            "display_address": [
                "512 Broome St",
                "New York, NY 10013"
            ]
        }
    },
    {
        "bid": "xN7JOFf3nBBDxvZ1M4Slbg",
        "rating": 4.0,
        "reviews": 298,
        "coordinates": {
            "latitude": 40.7529899,
            "longitude": -74.02924
        },
        "name": "Barb\u00e8s Restaurant",
        "address": {
            "address1": "1300 Park Ave",
            "address2": None,
            "address3": "",
            "city": "Hoboken",
            "zip_code": "07030",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "1300 Park Ave",
                "Hoboken, NJ 07030"
            ]
        }
    },
    {
        "bid": "KJ0mCfhX0POysKwwp4e3IQ",
        "rating": 4.5,
        "reviews": 7,
        "coordinates": {
            "latitude": 40.73898100138879,
            "longitude": -74.1719270068636
        },
        "name": "Tribos Peri Peri",
        "address": {
            "address1": "98 Halsey St",
            "address2": "",
            "address3": None,
            "city": "Newark",
            "zip_code": "07102",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "98 Halsey St",
                "Newark, NJ 07102"
            ]
        }
    },
    {
        "bid": "azCB19UzoGl7njg5FDudaw",
        "rating": 3.5,
        "reviews": 134,
        "coordinates": {
            "latitude": 40.6263033995038,
            "longitude": -74.1298565325409
        },
        "name": "Sumac",
        "address": {
            "address1": "1198 Forest Ave",
            "address2": "",
            "address3": "",
            "city": "Staten Island",
            "zip_code": "10310",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1198 Forest Ave",
                "Staten Island, NY 10310"
            ]
        }
    },
    {
        "bid": "XIyjy3QFk7zT4qDKwbGKUA",
        "rating": 4.5,
        "reviews": 11,
        "coordinates": {
            "latitude": 40.58894196502154,
            "longitude": -73.64459483942804
        },
        "name": "Greek Cove - Long Beach",
        "address": {
            "address1": "665 E Park Ave",
            "address2": "",
            "address3": None,
            "city": "Long Beach",
            "zip_code": "11561",
            "country": "US",
            "state": "NY",
            "display_address": [
                "665 E Park Ave",
                "Long Beach, NY 11561"
            ]
        }
    },
    {
        "bid": "B8wqZSQdRBUl2XN8smO5Tg",
        "rating": 4.0,
        "reviews": 17,
        "coordinates": {
            "latitude": 40.74706,
            "longitude": -73.89198
        },
        "name": "Moonlite Grill & Chicken",
        "address": {
            "address1": "73-15 Broadway",
            "address2": "",
            "address3": None,
            "city": "Queens",
            "zip_code": "11372",
            "country": "US",
            "state": "NY",
            "display_address": [
                "73-15 Broadway",
                "Queens, NY 11372"
            ]
        }
    },
    {
        "bid": "qVU2-6I58ssHIRzPfP5Gqw",
        "rating": 4.0,
        "reviews": 311,
        "coordinates": {
            "latitude": 40.91517560356527,
            "longitude": -74.05964211762358
        },
        "name": "Cava",
        "address": {
            "address1": "600 Bergen Town Ctr Near Main Entrance Close To Nike",
            "address2": "Near Main Entrance, Close to Nike",
            "address3": "",
            "city": "Paramus",
            "zip_code": "07652",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "600 Bergen Town Ctr Near Main Entrance Close To Nike",
                "Near Main Entrance, Close to Nike",
                "Paramus, NJ 07652"
            ]
        }
    },
    {
        "bid": "MIyMHjB_V-4XGl6SVfak0A",
        "rating": 4.0,
        "reviews": 116,
        "coordinates": {
            "latitude": 40.7572741280559,
            "longitude": -73.9820981359181
        },
        "name": "Moshe's Falafel",
        "address": {
            "address1": "94 W 46th St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10036",
            "country": "US",
            "state": "NY",
            "display_address": [
                "94 W 46th St",
                "New York, NY 10036"
            ]
        }
    },
    {
        "bid": "rGvKGmrQCa4vKFasCgwyAg",
        "rating": 4.5,
        "reviews": 160,
        "coordinates": {
            "latitude": 40.5057517871469,
            "longitude": -74.6415592341878
        },
        "name": "The Falafel House",
        "address": {
            "address1": "411 US-206",
            "address2": None,
            "address3": "Town Center One",
            "city": "Hillsborough Township",
            "zip_code": "08844",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "411 US-206",
                "Town Center One",
                "Hillsborough Township, NJ 08844"
            ]
        }
    },
    {
        "bid": "Rgs4WOGCbYBgrnN39XMLvA",
        "rating": 4.5,
        "reviews": 156,
        "coordinates": {
            "latitude": 40.58699,
            "longitude": -74.4189851
        },
        "name": "House Of Falafel",
        "address": {
            "address1": "2323 Plainfield Ave",
            "address2": "",
            "address3": None,
            "city": "South Plainfield",
            "zip_code": "07080",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "2323 Plainfield Ave",
                "South Plainfield, NJ 07080"
            ]
        }
    },
    {
        "bid": "fFkqEyupjc5x2iJQIPcpLw",
        "rating": 4.5,
        "reviews": 265,
        "coordinates": {
            "latitude": 40.7264,
            "longitude": -73.98411
        },
        "name": "Ruffian",
        "address": {
            "address1": "125 E 7th St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10009",
            "country": "US",
            "state": "NY",
            "display_address": [
                "125 E 7th St",
                "New York, NY 10009"
            ]
        }
    },
    {
        "bid": "D7e-_CH_Aovi166axIxMQg",
        "rating": 4.0,
        "reviews": 246,
        "coordinates": {
            "latitude": 40.8469145,
            "longitude": -74.2903897
        },
        "name": "Cinar Turkish Restaurant",
        "address": {
            "address1": "632 Bloomfield Ave",
            "address2": None,
            "address3": "",
            "city": "West Caldwell",
            "zip_code": "07006",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "632 Bloomfield Ave",
                "West Caldwell, NJ 07006"
            ]
        }
    },
    {
        "bid": "BU_GtPGTCy5KiJ6g8Ltdwg",
        "rating": 4.0,
        "reviews": 77,
        "coordinates": {
            "latitude": 40.85147,
            "longitude": -73.928109
        },
        "name": "Golan Heights",
        "address": {
            "address1": "2553 Amsterdam Ave",
            "address2": "",
            "address3": "",
            "city": "Manhattan",
            "zip_code": "10033",
            "country": "US",
            "state": "NY",
            "display_address": [
                "2553 Amsterdam Ave",
                "Manhattan, NY 10033"
            ]
        }
    },
    {
        "bid": "tFjn-akT7Bjp1mlmllZnTA",
        "rating": 4.0,
        "reviews": 61,
        "coordinates": {
            "latitude": 40.592795,
            "longitude": -74.068009
        },
        "name": "Chinar On The Island",
        "address": {
            "address1": "283 Sand Ln",
            "address2": None,
            "address3": "",
            "city": "Staten Island",
            "zip_code": "10305",
            "country": "US",
            "state": "NY",
            "display_address": [
                "283 Sand Ln",
                "Staten Island, NY 10305"
            ]
        }
    },
    {
        "bid": "fE8AO33n15rVzHjbhKlh_w",
        "rating": 5.0,
        "reviews": 102,
        "coordinates": {
            "latitude": 40.886314,
            "longitude": -73.41729
        },
        "name": "Mazzar Grill",
        "address": {
            "address1": "106 New York Ave",
            "address2": None,
            "address3": "",
            "city": "Huntington",
            "zip_code": "11743",
            "country": "US",
            "state": "NY",
            "display_address": [
                "106 New York Ave",
                "Huntington, NY 11743"
            ]
        }
    },
    {
        "bid": "FoIypvLXLOYMdhDQzzcxUA",
        "rating": 4.5,
        "reviews": 39,
        "coordinates": {
            "latitude": 40.78667315676499,
            "longitude": -74.39104166714482
        },
        "name": "The Great Greek Mediterranean Grill",
        "address": {
            "address1": "182 Ridgedale Ave",
            "address2": None,
            "address3": "",
            "city": "Florham Park",
            "zip_code": "07932",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "182 Ridgedale Ave",
                "Florham Park, NJ 07932"
            ]
        }
    },
    {
        "bid": "G4NUm5zm5pWDhd7eORU8xQ",
        "rating": 4.0,
        "reviews": 181,
        "coordinates": {
            "latitude": 40.78662,
            "longitude": -74.14602
        },
        "name": "Athenian Fresh Grill",
        "address": {
            "address1": "11-35 River Rd",
            "address2": "",
            "address3": "",
            "city": "North Arlington",
            "zip_code": "07031",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "11-35 River Rd",
                "North Arlington, NJ 07031"
            ]
        }
    },
    {
        "bid": "dGlkilMgNDj-ZzgLxCiDJQ",
        "rating": 4.5,
        "reviews": 64,
        "coordinates": {
            "latitude": 40.875587,
            "longitude": -74.383722
        },
        "name": "Rayhoon Persian Kabob House",
        "address": {
            "address1": "450 N Beverwyck Rd",
            "address2": None,
            "address3": "",
            "city": "Parsippany",
            "zip_code": "07054",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "450 N Beverwyck Rd",
                "Parsippany, NJ 07054"
            ]
        }
    },
    {
        "bid": "Wm2HlpBm6naywFQdsezUew",
        "rating": 4.5,
        "reviews": 119,
        "coordinates": {
            "latitude": 40.85383148603,
            "longitude": -74.1724397281115
        },
        "name": "Off The Grill",
        "address": {
            "address1": "1348 Clifton Ave",
            "address2": None,
            "address3": "",
            "city": "Clifton",
            "zip_code": "07012",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "1348 Clifton Ave",
                "Clifton, NJ 07012"
            ]
        }
    },
    {
        "bid": "0J7D7NAqgHebL-7UoRL8Uw",
        "rating": 4.5,
        "reviews": 12,
        "coordinates": {
            "latitude": 40.63947,
            "longitude": -73.99088
        },
        "name": "Falafamania",
        "address": {
            "address1": "4305 12th Ave",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11219",
            "country": "US",
            "state": "NY",
            "display_address": [
                "4305 12th Ave",
                "Brooklyn, NY 11219"
            ]
        }
    },
    {
        "bid": "IiWdOM5sbRDRbHf0YwdyRg",
        "rating": 4.5,
        "reviews": 124,
        "coordinates": {
            "latitude": 40.87367,
            "longitude": -74.53433
        },
        "name": "Kabab Paradise",
        "address": {
            "address1": "124 Rte 10 W",
            "address2": "",
            "address3": None,
            "city": "Randolph",
            "zip_code": "07869",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "124 Rte 10 W",
                "Randolph, NJ 07869"
            ]
        }
    },
    {
        "bid": "l9dCKe-0EO1XQFkuFi8YRQ",
        "rating": 3.5,
        "reviews": 159,
        "coordinates": {
            "latitude": 40.77227,
            "longitude": -74.02148
        },
        "name": "Garbanzo Grill",
        "address": {
            "address1": "3706 Park Ave",
            "address2": "",
            "address3": "",
            "city": "Weehawken",
            "zip_code": "07086",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "3706 Park Ave",
                "Weehawken, NJ 07086"
            ]
        }
    },
    {
        "bid": "c40x0H2nNwR9JyV0z2iuow",
        "rating": 4.0,
        "reviews": 140,
        "coordinates": {
            "latitude": 40.83626,
            "longitude": -74.09202
        },
        "name": "Hunkar Restaurant",
        "address": {
            "address1": "319 Hackensack St",
            "address2": "",
            "address3": "",
            "city": "Carlstadt",
            "zip_code": "07072",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "319 Hackensack St",
                "Carlstadt, NJ 07072"
            ]
        }
    },
    {
        "bid": "N2nwanXq9dDvKLIy7Ovb7g",
        "rating": 4.0,
        "reviews": 627,
        "coordinates": {
            "latitude": 40.76152,
            "longitude": -73.925
        },
        "name": "Bahari Estiatorio",
        "address": {
            "address1": "3114 Broadway",
            "address2": "",
            "address3": "",
            "city": "Astoria",
            "zip_code": "11106",
            "country": "US",
            "state": "NY",
            "display_address": [
                "3114 Broadway",
                "Astoria, NY 11106"
            ]
        }
    },
    {
        "bid": "es4ZRudaDLJrkVRkulwVqQ",
        "rating": 4.0,
        "reviews": 22,
        "coordinates": {
            "latitude": 40.14906,
            "longitude": -74.22769
        },
        "name": "Ava Barsoum Mediterranean Food",
        "address": {
            "address1": "4224 Rte 9 S",
            "address2": "",
            "address3": None,
            "city": "Howell Township",
            "zip_code": "07731",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "4224 Rte 9 S",
                "Howell Township, NJ 07731"
            ]
        }
    },
    {
        "bid": "U7aH5Sy4Z5QfEpzeccz56w",
        "rating": 4.0,
        "reviews": 334,
        "coordinates": {
            "latitude": 40.7197288162693,
            "longitude": -73.8449875895475
        },
        "name": "Pahal Zan",
        "address": {
            "address1": "106-12 71st Ave",
            "address2": "",
            "address3": "",
            "city": "Forest Hills",
            "zip_code": "11375",
            "country": "US",
            "state": "NY",
            "display_address": [
                "106-12 71st Ave",
                "Forest Hills, NY 11375"
            ]
        }
    },
    {
        "bid": "GQ2Y63JnE1tUoZ1DtcquEw",
        "rating": 4.5,
        "reviews": 68,
        "coordinates": {
            "latitude": 41.03261,
            "longitude": -73.76797
        },
        "name": "Greca Mediterranean Kitchen + Bar",
        "address": {
            "address1": "189 Main St",
            "address2": None,
            "address3": "",
            "city": "White Plains",
            "zip_code": "10601",
            "country": "US",
            "state": "NY",
            "display_address": [
                "189 Main St",
                "White Plains, NY 10601"
            ]
        }
    },
    {
        "bid": "iE6kR5wsCbldJHKZ5kGLcw",
        "rating": 4.0,
        "reviews": 221,
        "coordinates": {
            "latitude": 40.7373679,
            "longitude": -74.0329029529499
        },
        "name": "Greektown",
        "address": {
            "address1": "86 Garden St",
            "address2": "",
            "address3": "",
            "city": "Hoboken",
            "zip_code": "07030",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "86 Garden St",
                "Hoboken, NJ 07030"
            ]
        }
    },
    {
        "bid": "JtmzTnEDpS03tMytXOPUQw",
        "rating": 4.0,
        "reviews": 65,
        "coordinates": {
            "latitude": 40.7225149191837,
            "longitude": -73.9890300482512
        },
        "name": "NYC Falafel",
        "address": {
            "address1": "201 Allen St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10002",
            "country": "US",
            "state": "NY",
            "display_address": [
                "201 Allen St",
                "New York, NY 10002"
            ]
        }
    },
    {
        "bid": "eDNSaUzzYbhEXFnN6Jnc4w",
        "rating": 3.5,
        "reviews": 429,
        "coordinates": {
            "latitude": 40.74929,
            "longitude": -73.98317
        },
        "name": "Arabesque",
        "address": {
            "address1": "4 E 36th St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10016",
            "country": "US",
            "state": "NY",
            "display_address": [
                "4 E 36th St",
                "New York, NY 10016"
            ]
        }
    },
    {
        "bid": "8O-nF9b9fQH4Zxu6ymcUPw",
        "rating": 3.5,
        "reviews": 417,
        "coordinates": {
            "latitude": 40.73021,
            "longitude": -74.00058
        },
        "name": "Olive Tree Cafe",
        "address": {
            "address1": "117 Macdougal St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10012",
            "country": "US",
            "state": "NY",
            "display_address": [
                "117 Macdougal St",
                "New York, NY 10012"
            ]
        }
    },
    {
        "bid": "TbBHcuxnq1Fs487UAEvQcg",
        "rating": 3.0,
        "reviews": 17,
        "coordinates": {
            "latitude": 40.64491,
            "longitude": -73.70388
        },
        "name": "Laffa Bar and Grill",
        "address": {
            "address1": "1326 Peninsula Blvd",
            "address2": None,
            "address3": "",
            "city": "Hewlett",
            "zip_code": "11557",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1326 Peninsula Blvd",
                "Hewlett, NY 11557"
            ]
        }
    },
    {
        "bid": "GqzOGvwjduvXy3vZj_ChWw",
        "rating": 4.0,
        "reviews": 214,
        "coordinates": {
            "latitude": 40.6480942834742,
            "longitude": -73.9791212747221
        },
        "name": "Batata",
        "address": {
            "address1": "3021 Fort Hamilton Pkwy",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11218",
            "country": "US",
            "state": "NY",
            "display_address": [
                "3021 Fort Hamilton Pkwy",
                "Brooklyn, NY 11218"
            ]
        }
    },
    {
        "bid": "zieQ0Yvh8f50-rjh4jWyKg",
        "rating": 4.0,
        "reviews": 321,
        "coordinates": {
            "latitude": 40.857075,
            "longitude": -74.02511
        },
        "name": "Sparta Taverna",
        "address": {
            "address1": "206 Main St",
            "address2": "",
            "address3": None,
            "city": "Ridgefield Park",
            "zip_code": "07660",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "206 Main St",
                "Ridgefield Park, NJ 07660"
            ]
        }
    },
    {
        "bid": "DiMNNmZDrnbo7xKVzVBNqw",
        "rating": 4.0,
        "reviews": 205,
        "coordinates": {
            "latitude": 41.073649,
            "longitude": -73.5487517
        },
        "name": "Tabouli Grill",
        "address": {
            "address1": "59 High Ridge Rd",
            "address2": "",
            "address3": "",
            "city": "Stamford",
            "zip_code": "06905",
            "country": "US",
            "state": "CT",
            "display_address": [
                "59 High Ridge Rd",
                "Stamford, CT 06905"
            ]
        }
    },
    {
        "bid": "s1SDiB0IfA9gvqiba5EkMQ",
        "rating": 4.0,
        "reviews": 45,
        "coordinates": {
            "latitude": 40.5898996,
            "longitude": -73.7976476
        },
        "name": "Cuisine By Claudette",
        "address": {
            "address1": "190 Beach 69th St",
            "address2": "Unit C",
            "address3": "",
            "city": "Arverne",
            "zip_code": "11692",
            "country": "US",
            "state": "NY",
            "display_address": [
                "190 Beach 69th St",
                "Unit C",
                "Arverne, NY 11692"
            ]
        }
    },
    {
        "bid": "zOidWChUejS-lHyd3Cv6ug",
        "rating": 4.0,
        "reviews": 268,
        "coordinates": {
            "latitude": 40.7335277154316,
            "longitude": -73.7587297262596
        },
        "name": "Greek Family Kitchen",
        "address": {
            "address1": "212-02 Union Tpke",
            "address2": "",
            "address3": "",
            "city": "Hollis Hills",
            "zip_code": "11364",
            "country": "US",
            "state": "NY",
            "display_address": [
                "212-02 Union Tpke",
                "Hollis Hills, NY 11364"
            ]
        }
    },
    {
        "bid": "p6AlpFwd99eGJukxOj1nrA",
        "rating": 4.0,
        "reviews": 13,
        "coordinates": {
            "latitude": 40.726423324702004,
            "longitude": -73.87065238542243
        },
        "name": "Cafe Istanbul Grill",
        "address": {
            "address1": "6208 Woodhaven Blvd",
            "address2": None,
            "address3": "",
            "city": "Rego Park",
            "zip_code": "11374",
            "country": "US",
            "state": "NY",
            "display_address": [
                "6208 Woodhaven Blvd",
                "Rego Park, NY 11374"
            ]
        }
    },
    {
        "bid": "krV7j6LMGErBLcw66TwnOg",
        "rating": 3.5,
        "reviews": 80,
        "coordinates": {
            "latitude": 40.7856285,
            "longitude": -73.9731151
        },
        "name": "Mamoun's Falafel",
        "address": {
            "address1": "508 Columbus Ave",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10024",
            "country": "US",
            "state": "NY",
            "display_address": [
                "508 Columbus Ave",
                "New York, NY 10024"
            ]
        }
    },
    {
        "bid": "DGDgn4lEjpKkMW8U1lzHxA",
        "rating": 4.0,
        "reviews": 135,
        "coordinates": {
            "latitude": 40.8120567920045,
            "longitude": -74.1247057337114
        },
        "name": "Hummus & Guac",
        "address": {
            "address1": "402 Valley Brook Ave",
            "address2": None,
            "address3": "",
            "city": "Lyndhurst",
            "zip_code": "07071",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "402 Valley Brook Ave",
                "Lyndhurst, NJ 07071"
            ]
        }
    },
    {
        "bid": "qf098TQ-Frxq4QyrlYqDJw",
        "rating": 3.5,
        "reviews": 176,
        "coordinates": {
            "latitude": 40.631191,
            "longitude": -74.022193
        },
        "name": "Hazar Turkish Kebab",
        "address": {
            "address1": "7224 5th Ave",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11209",
            "country": "US",
            "state": "NY",
            "display_address": [
                "7224 5th Ave",
                "Brooklyn, NY 11209"
            ]
        }
    },
    {
        "bid": "5wJnsZN9kLIw7yuCEHZWrg",
        "rating": 4.0,
        "reviews": 212,
        "coordinates": {
            "latitude": 40.676689,
            "longitude": -73.456848
        },
        "name": "Ephesus Mediterranean & Turkish Cuisine",
        "address": {
            "address1": "514 Park Blvd",
            "address2": "",
            "address3": "",
            "city": "Massapequa Park",
            "zip_code": "11762",
            "country": "US",
            "state": "NY",
            "display_address": [
                "514 Park Blvd",
                "Massapequa Park, NY 11762"
            ]
        }
    },
    {
        "bid": "fahnqhxhFqyMAHKVC01sSA",
        "rating": 3.5,
        "reviews": 16,
        "coordinates": {
            "latitude": 40.6952229685817,
            "longitude": -73.9563989639282
        },
        "name": "Moishe's Place",
        "address": {
            "address1": "868 Bedford Ave",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11205",
            "country": "US",
            "state": "NY",
            "display_address": [
                "868 Bedford Ave",
                "Brooklyn, NY 11205"
            ]
        }
    },
    {
        "bid": "yB4YcbSpAFE8XGJuQT-6zA",
        "rating": 4.0,
        "reviews": 216,
        "coordinates": {
            "latitude": 40.716799944155,
            "longitude": -74.0355072729312
        },
        "name": "Cava",
        "address": {
            "address1": "30 Montgomery St",
            "address2": "",
            "address3": None,
            "city": "Jersey City",
            "zip_code": "07302",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "30 Montgomery St",
                "Jersey City, NJ 07302"
            ]
        }
    },
    {
        "bid": "bRudwmIUL70q05QYF8e4gw",
        "rating": 4.5,
        "reviews": 5,
        "coordinates": {
            "latitude": 40.738065,
            "longitude": -73.612807
        },
        "name": "NAYA - Roosevelt Field",
        "address": {
            "address1": "630 Old Country Rd",
            "address2": None,
            "address3": "",
            "city": "Garden City",
            "zip_code": "11530",
            "country": "US",
            "state": "NY",
            "display_address": [
                "630 Old Country Rd",
                "Garden City, NY 11530"
            ]
        }
    },
    {
        "bid": "2l6f0IXKZkxyq0L4EaoaFQ",
        "rating": 3.5,
        "reviews": 1368,
        "coordinates": {
            "latitude": 40.720706862742,
            "longitude": -73.9948451276474
        },
        "name": "The Butcher's Daughter",
        "address": {
            "address1": "19 Kenmare St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10012",
            "country": "US",
            "state": "NY",
            "display_address": [
                "19 Kenmare St",
                "New York, NY 10012"
            ]
        }
    },
    {
        "bid": "JG1XlvQ6s9ZC1yXeVLBh6Q",
        "rating": 4.5,
        "reviews": 105,
        "coordinates": {
            "latitude": 40.925964,
            "longitude": -73.96392
        },
        "name": "Europe Cafe & Grill",
        "address": {
            "address1": "1 Highwood Ave",
            "address2": None,
            "address3": "",
            "city": "Tenafly",
            "zip_code": "07670",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "1 Highwood Ave",
                "Tenafly, NJ 07670"
            ]
        }
    },
    {
        "bid": "lIV6srdtoTyzRffIPe0AFA",
        "rating": 4.5,
        "reviews": 52,
        "coordinates": {
            "latitude": 40.62959155568596,
            "longitude": -74.02878841255159
        },
        "name": "Louie's Gyros",
        "address": {
            "address1": "7720 3rd Ave",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11209",
            "country": "US",
            "state": "NY",
            "display_address": [
                "7720 3rd Ave",
                "Brooklyn, NY 11209"
            ]
        }
    },
    {
        "bid": "DRNDmbYonrjMwzH292gcdQ",
        "rating": 4.0,
        "reviews": 62,
        "coordinates": {
            "latitude": 40.72068769558698,
            "longitude": -74.2882619
        },
        "name": "Justina Falafel",
        "address": {
            "address1": "2933 Vauxhall Rd",
            "address2": "",
            "address3": "",
            "city": "Vauxhall",
            "zip_code": "07088",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "2933 Vauxhall Rd",
                "Vauxhall, NJ 07088"
            ]
        }
    },
    {
        "bid": "nELxK7TzX7bTCSBT79wWGA",
        "rating": 4.0,
        "reviews": 46,
        "coordinates": {
            "latitude": 40.75820802048987,
            "longitude": -73.99257895964601
        },
        "name": "Istanbul Bay",
        "address": {
            "address1": "578 9th Ave",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10036",
            "country": "US",
            "state": "NY",
            "display_address": [
                "578 9th Ave",
                "New York, NY 10036"
            ]
        }
    },
    {
        "bid": "4vyhLYCgPuZoCQ_HLBD9ig",
        "rating": 4.5,
        "reviews": 424,
        "coordinates": {
            "latitude": 40.232,
            "longitude": -74.271917
        },
        "name": "Lemon Mediterranean Restaurant",
        "address": {
            "address1": "3475 Rt 9",
            "address2": "",
            "address3": "",
            "city": "Freehold",
            "zip_code": "07728",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "3475 Rt 9",
                "Freehold, NJ 07728"
            ]
        }
    },
    {
        "bid": "tAHRDrCR0l_utA91IyOYNw",
        "rating": 3.0,
        "reviews": 153,
        "coordinates": {
            "latitude": 40.71511,
            "longitude": -74.00758
        },
        "name": "Baba Ghanouge",
        "address": {
            "address1": "165 Church St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10007",
            "country": "US",
            "state": "NY",
            "display_address": [
                "165 Church St",
                "New York, NY 10007"
            ]
        }
    },
    {
        "bid": "seCOrCJVVhmnjhRAWjVeKA",
        "rating": 4.0,
        "reviews": 107,
        "coordinates": {
            "latitude": 40.7541476,
            "longitude": -73.9818586
        },
        "name": "Cava",
        "address": {
            "address1": "11 W 42nd St",
            "address2": None,
            "address3": None,
            "city": "New York",
            "zip_code": "10036",
            "country": "US",
            "state": "NY",
            "display_address": [
                "11 W 42nd St",
                "New York, NY 10036"
            ]
        }
    },
    {
        "bid": "0SkUuz4WDYfJk21D8Ki4hA",
        "rating": 4.5,
        "reviews": 9,
        "coordinates": {
            "latitude": 41.02795,
            "longitude": -73.76762
        },
        "name": "ANAR",
        "address": {
            "address1": "98 E Post Rd",
            "address2": None,
            "address3": None,
            "city": "White Plains",
            "zip_code": "10601",
            "country": "US",
            "state": "NY",
            "display_address": [
                "98 E Post Rd",
                "White Plains, NY 10601"
            ]
        }
    },
    {
        "bid": "ncDNh2mFnRdX9AKnQQ-2nQ",
        "rating": 4.5,
        "reviews": 5,
        "coordinates": {
            "latitude": 40.754475,
            "longitude": -73.975847
        },
        "name": "Pita Yeero",
        "address": {
            "address1": "230 Park Ave",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10169",
            "country": "US",
            "state": "NY",
            "display_address": [
                "230 Park Ave",
                "New York, NY 10169"
            ]
        }
    },
    {
        "bid": "KjqBMZ0bE9VV2VP3DrDZvg",
        "rating": 4.0,
        "reviews": 188,
        "coordinates": {
            "latitude": 40.61803,
            "longitude": -74.03065
        },
        "name": "First Oasis",
        "address": {
            "address1": "9218 4th Ave",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11209",
            "country": "US",
            "state": "NY",
            "display_address": [
                "9218 4th Ave",
                "Brooklyn, NY 11209"
            ]
        }
    },
    {
        "bid": "vJM8r7tpcKjeTnOjBwOv7Q",
        "rating": 4.5,
        "reviews": 3,
        "coordinates": {
            "latitude": 40.72043,
            "longitude": -74.04352
        },
        "name": "Falafel Station",
        "address": {
            "address1": "138 Newark Ave",
            "address2": "",
            "address3": None,
            "city": "Jersey City",
            "zip_code": "07302",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "138 Newark Ave",
                "Jersey City, NJ 07302"
            ]
        }
    },
    {
        "bid": "jdurWp7Bm_-u_m9M2DE76A",
        "rating": 4.0,
        "reviews": 29,
        "coordinates": {
            "latitude": 40.58323,
            "longitude": -74.09523
        },
        "name": "Alba International Food",
        "address": {
            "address1": "1880 Hylan Blvd",
            "address2": None,
            "address3": None,
            "city": "Staten Island",
            "zip_code": "10305",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1880 Hylan Blvd",
                "Staten Island, NY 10305"
            ]
        }
    },
    {
        "bid": "FsOqfY3z5CXovt8SSEnfVg",
        "rating": 4.5,
        "reviews": 338,
        "coordinates": {
            "latitude": 40.49826,
            "longitude": -74.45712
        },
        "name": "Namli Mediterranean & Turkish Cuisine",
        "address": {
            "address1": "88 Central Ave",
            "address2": None,
            "address3": "",
            "city": "New Brunswick",
            "zip_code": "08901",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "88 Central Ave",
                "New Brunswick, NJ 08901"
            ]
        }
    },
    {
        "bid": "JZ45uaCB6SLBYng22_dplQ",
        "rating": 4.0,
        "reviews": 20,
        "coordinates": {
            "latitude": 40.75714,
            "longitude": -73.993802
        },
        "name": "Lasani",
        "address": {
            "address1": "539 9th Ave",
            "address2": None,
            "address3": None,
            "city": "New York",
            "zip_code": "10018",
            "country": "US",
            "state": "NY",
            "display_address": [
                "539 9th Ave",
                "New York, NY 10018"
            ]
        }
    },
    {
        "bid": "lKorC4Qb3Xbiyy-bU9JjyA",
        "rating": 5.0,
        "reviews": 2,
        "coordinates": {
            "latitude": 40.460904,
            "longitude": -74.456371
        },
        "name": "The Hummus Republic",
        "address": {
            "address1": "758 Shoppes Blvd",
            "address2": None,
            "address3": "",
            "city": "North Brunswick Township",
            "zip_code": "08902",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "758 Shoppes Blvd",
                "North Brunswick Township, NJ 08902"
            ]
        }
    },
    {
        "bid": "vgH2stheUnWDUYElmezVTw",
        "rating": 4.5,
        "reviews": 275,
        "coordinates": {
            "latitude": 40.87139,
            "longitude": -73.42695
        },
        "name": "Neraki Greek Mediterranean Grill",
        "address": {
            "address1": "273 Main St",
            "address2": "",
            "address3": "",
            "city": "Huntington",
            "zip_code": "11743",
            "country": "US",
            "state": "NY",
            "display_address": [
                "273 Main St",
                "Huntington, NY 11743"
            ]
        }
    },
    {
        "bid": "6ShMwC7gcYt_FJFxzgvoYw",
        "rating": 3.5,
        "reviews": 14,
        "coordinates": {
            "latitude": 40.59535,
            "longitude": -74.06307
        },
        "name": "Kestane Seaside",
        "address": {
            "address1": "124 Ocean Ave",
            "address2": None,
            "address3": "",
            "city": "Staten Island",
            "zip_code": "10305",
            "country": "US",
            "state": "NY",
            "display_address": [
                "124 Ocean Ave",
                "Staten Island, NY 10305"
            ]
        }
    },
    {
        "bid": "2N1y8Cv7R92lDYia_eruCw",
        "rating": 4.0,
        "reviews": 197,
        "coordinates": {
            "latitude": 40.80032,
            "longitude": -74.00733
        },
        "name": "Platter King",
        "address": {
            "address1": "7704 Bergenline Ave",
            "address2": None,
            "address3": "",
            "city": "North Bergen",
            "zip_code": "07047",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "7704 Bergenline Ave",
                "North Bergen, NJ 07047"
            ]
        }
    },
    {
        "bid": "WFCmjTPLubBpscQBkhSPNQ",
        "rating": 4.5,
        "reviews": 357,
        "coordinates": {
            "latitude": 41.0307019,
            "longitude": -73.7661408
        },
        "name": "Shiraz Kitchen & Wine Bar",
        "address": {
            "address1": "80 Mamaroneck Ave",
            "address2": None,
            "address3": "",
            "city": "White plains ",
            "zip_code": "10601",
            "country": "US",
            "state": "NY",
            "display_address": [
                "80 Mamaroneck Ave",
                "White plains , NY 10601"
            ]
        }
    },
    {
        "bid": "7NN76mp_iwmJd1_FEqpM_w",
        "rating": 3.5,
        "reviews": 131,
        "coordinates": {
            "latitude": 40.74362,
            "longitude": -73.97932
        },
        "name": "Eros Greek Restaurant",
        "address": {
            "address1": "447 3rd Ave",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10016",
            "country": "US",
            "state": "NY",
            "display_address": [
                "447 3rd Ave",
                "New York, NY 10016"
            ]
        }
    },
    {
        "bid": "GqhuyExkns5kcLSHgBb5WQ",
        "rating": 4.5,
        "reviews": 100,
        "coordinates": {
            "latitude": 40.744799,
            "longitude": -74.257245
        },
        "name": "Bistro d\u2019Azur",
        "address": {
            "address1": "14 Academy St",
            "address2": "",
            "address3": None,
            "city": "South Orange",
            "zip_code": "07079",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "14 Academy St",
                "South Orange, NJ 07079"
            ]
        }
    },
    {
        "bid": "EE2G_gi5fJ2F6sz0Lkd09w",
        "rating": 3.5,
        "reviews": 305,
        "coordinates": {
            "latitude": 40.87985,
            "longitude": -73.95082
        },
        "name": "Lefkes",
        "address": {
            "address1": "495 Sylvan Ave",
            "address2": None,
            "address3": "",
            "city": "Englewood Cliffs",
            "zip_code": "07632",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "495 Sylvan Ave",
                "Englewood Cliffs, NJ 07632"
            ]
        }
    },
    {
        "bid": "CJXVkLtlWmpCaHMRUII8XQ",
        "rating": 4.0,
        "reviews": 119,
        "coordinates": {
            "latitude": 40.7521504,
            "longitude": -73.9841278
        },
        "name": "Paprika kosher Catering ",
        "address": {
            "address1": "32 W 39th St",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10018",
            "country": "US",
            "state": "NY",
            "display_address": [
                "32 W 39th St",
                "New York, NY 10018"
            ]
        }
    },
    {
        "bid": "zDEctiYZsuwCBlnncwuPAg",
        "rating": 4.5,
        "reviews": 6,
        "coordinates": {
            "latitude": 40.69622743507663,
            "longitude": -73.742758
        },
        "name": "Taza Halal Eats",
        "address": {
            "address1": "216-19 Linden Blvd",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "11411",
            "country": "US",
            "state": "NY",
            "display_address": [
                "216-19 Linden Blvd",
                "New York, NY 11411"
            ]
        }
    },
    {
        "bid": "DWR54ugpSThnDub4xeHWow",
        "rating": 4.0,
        "reviews": 383,
        "coordinates": {
            "latitude": 40.62297,
            "longitude": -74.02807
        },
        "name": "Karam Restaurant",
        "address": {
            "address1": "8519 4th Ave",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11209",
            "country": "US",
            "state": "NY",
            "display_address": [
                "8519 4th Ave",
                "Brooklyn, NY 11209"
            ]
        }
    },
    {
        "bid": "csGdM5dj9FPCXYHiqSBtZw",
        "rating": 3.5,
        "reviews": 83,
        "coordinates": {
            "latitude": 40.53258,
            "longitude": -74.19196
        },
        "name": "Kuzina The Greek Kitchen",
        "address": {
            "address1": "895 Huguenot Ave",
            "address2": "",
            "address3": "",
            "city": "Woodrow",
            "zip_code": "10312",
            "country": "US",
            "state": "NY",
            "display_address": [
                "895 Huguenot Ave",
                "Woodrow, NY 10312"
            ]
        }
    },
    {
        "bid": "IuRFzTKQ24j9Abeh6u4Puw",
        "rating": 4.0,
        "reviews": 184,
        "coordinates": {
            "latitude": 40.9727954,
            "longitude": -73.9618546
        },
        "name": "Zendiggi Kebab House",
        "address": {
            "address1": "228 Closter Dock Rd",
            "address2": "",
            "address3": "",
            "city": "Closter",
            "zip_code": "07624",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "228 Closter Dock Rd",
                "Closter, NJ 07624"
            ]
        }
    },
    {
        "bid": "avsTScJuRMPWrCUQkbGZ9w",
        "rating": 5.0,
        "reviews": 1,
        "coordinates": {
            "latitude": 40.7636224538599,
            "longitude": -73.9829115942121
        },
        "name": "FLE-FLE - Coming Soon",
        "address": {
            "address1": "1695 Broadway",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10019",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1695 Broadway",
                "New York, NY 10019"
            ]
        }
    },
    {
        "bid": "Jy8pMEIVMeM9dc6GYkuiiQ",
        "rating": 4.5,
        "reviews": 58,
        "coordinates": {
            "latitude": 40.980216,
            "longitude": -74.119437
        },
        "name": "Parisa Persian Grill",
        "address": {
            "address1": "24 Chestnut St",
            "address2": None,
            "address3": "",
            "city": "Ridgewood",
            "zip_code": "07450",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "24 Chestnut St",
                "Ridgewood, NJ 07450"
            ]
        }
    },
    {
        "bid": "ArgwH4dZIsDalmXmfasteA",
        "rating": 4.5,
        "reviews": 281,
        "coordinates": {
            "latitude": 40.9573783,
            "longitude": -74.2235621
        },
        "name": "Gyro Grill",
        "address": {
            "address1": "783 Hamburg Tpke",
            "address2": "",
            "address3": None,
            "city": "Wayne",
            "zip_code": "07470",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "783 Hamburg Tpke",
                "Wayne, NJ 07470"
            ]
        }
    },
    {
        "bid": "ubeG-hyIV8qoSSAk_pAZ2A",
        "rating": 4.0,
        "reviews": 147,
        "coordinates": {
            "latitude": 40.68332,
            "longitude": -73.97936
        },
        "name": "No Pork Halal Kitchen",
        "address": {
            "address1": "50 4th Ave",
            "address2": None,
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11217",
            "country": "US",
            "state": "NY",
            "display_address": [
                "50 4th Ave",
                "Brooklyn, NY 11217"
            ]
        }
    },
    {
        "bid": "bJUDGmgdiicJHTmPtblFRg",
        "rating": 3.5,
        "reviews": 89,
        "coordinates": {
            "latitude": 40.589632,
            "longitude": -74.164509
        },
        "name": "Holy Schnitzel",
        "address": {
            "address1": "438 Nome Ave",
            "address2": None,
            "address3": None,
            "city": "Staten Island",
            "zip_code": "10314",
            "country": "US",
            "state": "NY",
            "display_address": [
                "438 Nome Ave",
                "Staten Island, NY 10314"
            ]
        }
    },
    {
        "bid": "yk-urU0Zz41LiTS2ZBZf1Q",
        "rating": 3.5,
        "reviews": 149,
        "coordinates": {
            "latitude": 40.7449088452058,
            "longitude": -73.921469294812
        },
        "name": "Romanian Garden",
        "address": {
            "address1": "43-06 43rd Ave",
            "address2": "",
            "address3": "",
            "city": "Sunnyside",
            "zip_code": "11104",
            "country": "US",
            "state": "NY",
            "display_address": [
                "43-06 43rd Ave",
                "Sunnyside, NY 11104"
            ]
        }
    },
    {
        "bid": "hI9rkUO2a6bZigyXVoVbgQ",
        "rating": 5.0,
        "reviews": 8,
        "coordinates": {
            "latitude": 40.779671,
            "longitude": -73.946998
        },
        "name": "Tinos",
        "address": {
            "address1": "1748 1st Ave",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10128",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1748 1st Ave",
                "New York, NY 10128"
            ]
        }
    },
    {
        "bid": "h6MxdL-RSrcZNqkhA5lq_w",
        "rating": 4.0,
        "reviews": 210,
        "coordinates": {
            "latitude": 40.577072,
            "longitude": -73.9627471
        },
        "name": "Beyti Turkish Kebab",
        "address": {
            "address1": "414 Brighton Beach Ave",
            "address2": None,
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11235",
            "country": "US",
            "state": "NY",
            "display_address": [
                "414 Brighton Beach Ave",
                "Brooklyn, NY 11235"
            ]
        }
    },
    {
        "bid": "D3oHX4chk3pPlzJ97HZX_w",
        "rating": 4.5,
        "reviews": 68,
        "coordinates": {
            "latitude": 40.3514110738897,
            "longitude": -74.0648574868975
        },
        "name": "Zaitooni Deli",
        "address": {
            "address1": "11 Mechanic St",
            "address2": "",
            "address3": "",
            "city": "Red Bank",
            "zip_code": "07701",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "11 Mechanic St",
                "Red Bank, NJ 07701"
            ]
        }
    },
    {
        "bid": "bBJ9Ak-0HZ7Y3MohaLOIyQ",
        "rating": 4.0,
        "reviews": 1,
        "coordinates": {
            "latitude": 40.74430826842502,
            "longitude": -73.93107946647226
        },
        "name": "Halal Munchies",
        "address": {
            "address1": "33-8 Queens Blvd",
            "address2": "",
            "address3": None,
            "city": "Queens",
            "zip_code": "11101",
            "country": "US",
            "state": "NY",
            "display_address": [
                "33-8 Queens Blvd",
                "Queens, NY 11101"
            ]
        }
    },
    {
        "bid": "_7qt2EodhYIs0C6TLm7jJA",
        "rating": 4.0,
        "reviews": 10,
        "coordinates": {
            "latitude": 40.711787,
            "longitude": -73.941087
        },
        "name": "The Holy Grill",
        "address": {
            "address1": "810 Grand St",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11211",
            "country": "US",
            "state": "NY",
            "display_address": [
                "810 Grand St",
                "Brooklyn, NY 11211"
            ]
        }
    },
    {
        "bid": "0GX2FPZvZm_yXuNzkGha6Q",
        "rating": 4.0,
        "reviews": 53,
        "coordinates": {
            "latitude": 40.73153833,
            "longitude": -74.06618
        },
        "name": "Falafel Station",
        "address": {
            "address1": "2828 John F Kennedy Blvd",
            "address2": "",
            "address3": None,
            "city": "Jersey City",
            "zip_code": "07306",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "2828 John F Kennedy Blvd",
                "Jersey City, NJ 07306"
            ]
        }
    },
    {
        "bid": "3Q-qP7nZ79_bBDMyU1J4gA",
        "rating": 4.5,
        "reviews": 64,
        "coordinates": {
            "latitude": 41.127579,
            "longitude": -73.712562
        },
        "name": "Meraki Taverna",
        "address": {
            "address1": "450 Main St",
            "address2": "",
            "address3": None,
            "city": "Armonk",
            "zip_code": "10504",
            "country": "US",
            "state": "NY",
            "display_address": [
                "450 Main St",
                "Armonk, NY 10504"
            ]
        }
    },
    {
        "bid": "OIR22M7L20BLHfBeiPaeGQ",
        "rating": 4.5,
        "reviews": 82,
        "coordinates": {
            "latitude": 40.90809,
            "longitude": -74.41757
        },
        "name": "Uzbekistana",
        "address": {
            "address1": "1175 Main St",
            "address2": "",
            "address3": "",
            "city": "Boonton",
            "zip_code": "07005",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "1175 Main St",
                "Boonton, NJ 07005"
            ]
        }
    },
    {
        "bid": "Z4OF9kKSikiYZCx62_aq8A",
        "rating": 3.0,
        "reviews": 178,
        "coordinates": {
            "latitude": 40.7997299,
            "longitude": -73.96852
        },
        "name": "Jerusalem Restaurant",
        "address": {
            "address1": "2715 Broadway",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10025",
            "country": "US",
            "state": "NY",
            "display_address": [
                "2715 Broadway",
                "New York, NY 10025"
            ]
        }
    },
    {
        "bid": "ztgJJSidCZCNfGv1OMq0sQ",
        "rating": 5.0,
        "reviews": 29,
        "coordinates": {
            "latitude": 40.75301,
            "longitude": -73.9699
        },
        "name": "Tony Dragon's Grille",
        "address": {
            "address1": "47Th St And 2nd Ave",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10017",
            "country": "US",
            "state": "NY",
            "display_address": [
                "47Th St And 2nd Ave",
                "New York, NY 10017"
            ]
        }
    },
    {
        "bid": "PvxKXXFeaVFnMwMrvydiFg",
        "rating": 3.5,
        "reviews": 166,
        "coordinates": {
            "latitude": 40.707240503413,
            "longitude": -73.8971290568964
        },
        "name": "Gyro World Ridgewood",
        "address": {
            "address1": "66-57 Fresh Pond Rd",
            "address2": "",
            "address3": "",
            "city": "Ridgewood",
            "zip_code": "11385",
            "country": "US",
            "state": "NY",
            "display_address": [
                "66-57 Fresh Pond Rd",
                "Ridgewood, NY 11385"
            ]
        }
    },
    {
        "bid": "mQX9JxLMlhVxaUMP9ADUHw",
        "rating": 3.5,
        "reviews": 729,
        "coordinates": {
            "latitude": 40.75538,
            "longitude": -73.9811
        },
        "name": "Kellari New York",
        "address": {
            "address1": "19 W 44th St",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10036",
            "country": "US",
            "state": "NY",
            "display_address": [
                "19 W 44th St",
                "New York, NY 10036"
            ]
        }
    },
    {
        "bid": "80YK6JElg_pHjlHLlOvkmw",
        "rating": 3.5,
        "reviews": 361,
        "coordinates": {
            "latitude": 40.6678,
            "longitude": -73.98048
        },
        "name": "Istanbul Park",
        "address": {
            "address1": "293 7th Ave",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11215",
            "country": "US",
            "state": "NY",
            "display_address": [
                "293 7th Ave",
                "Brooklyn, NY 11215"
            ]
        }
    },
    {
        "bid": "9BjFk-3I-wSGjfNMv7oqtA",
        "rating": 5.0,
        "reviews": 8,
        "coordinates": {
            "latitude": 40.82642575181808,
            "longitude": -73.9871788061431
        },
        "name": "Bite Me",
        "address": {
            "address1": "652 Anderson Ave",
            "address2": "",
            "address3": None,
            "city": "Cliffside Park",
            "zip_code": "07010",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "652 Anderson Ave",
                "Cliffside Park, NJ 07010"
            ]
        }
    },
    {
        "bid": "hVDL6V_WETTTR4x1oERw0Q",
        "rating": 4.5,
        "reviews": 176,
        "coordinates": {
            "latitude": 40.658557,
            "longitude": -73.702018
        },
        "name": "Roro's Gyro",
        "address": {
            "address1": "32 Roosevelt Ave",
            "address2": "",
            "address3": "",
            "city": "Valley Stream",
            "zip_code": "11581",
            "country": "US",
            "state": "NY",
            "display_address": [
                "32 Roosevelt Ave",
                "Valley Stream, NY 11581"
            ]
        }
    },
    {
        "bid": "nDhhVuhDyP-QRi0lwk0j3w",
        "rating": 4.5,
        "reviews": 142,
        "coordinates": {
            "latitude": 40.7132359,
            "longitude": -73.8293642
        },
        "name": "Eva's Kitchen",
        "address": {
            "address1": "12036 Queens Blvd",
            "address2": "",
            "address3": None,
            "city": "Kew Gardens",
            "zip_code": "11415",
            "country": "US",
            "state": "NY",
            "display_address": [
                "12036 Queens Blvd",
                "Kew Gardens, NY 11415"
            ]
        }
    },
    {
        "bid": "aU5wBEpbuFYWp2G3jqHBOg",
        "rating": 4.0,
        "reviews": 437,
        "coordinates": {
            "latitude": 40.737724,
            "longitude": -73.669208
        },
        "name": "The Greek Place",
        "address": {
            "address1": "2144 Jericho Tpke",
            "address2": "",
            "address3": "",
            "city": "New Hyde Park",
            "zip_code": "11040",
            "country": "US",
            "state": "NY",
            "display_address": [
                "2144 Jericho Tpke",
                "New Hyde Park, NY 11040"
            ]
        }
    },
    {
        "bid": "lxF4xhZeoQusxVi-R90nUA",
        "rating": 5.0,
        "reviews": 1,
        "coordinates": {
            "latitude": 40.788,
            "longitude": -73.727758
        },
        "name": "Paprika Restaurant",
        "address": {
            "address1": "8 Bond St",
            "address2": None,
            "address3": "",
            "city": "Great Neck",
            "zip_code": "11021",
            "country": "US",
            "state": "NY",
            "display_address": [
                "8 Bond St",
                "Great Neck, NY 11021"
            ]
        }
    },
    {
        "bid": "_8KIG9pHYfEnPNhAShqjVQ",
        "rating": 5.0,
        "reviews": 119,
        "coordinates": {
            "latitude": 40.86369,
            "longitude": -74.40251
        },
        "name": "Elmas",
        "address": {
            "address1": "1561 US-46",
            "address2": None,
            "address3": "",
            "city": "Parsippany-Troy Hills",
            "zip_code": "07054",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "1561 US-46",
                "Parsippany-Troy Hills, NJ 07054"
            ]
        }
    },
    {
        "bid": "50ak4CXlbH7UoQlwI3FAAQ",
        "rating": 4.0,
        "reviews": 451,
        "coordinates": {
            "latitude": 40.82803,
            "longitude": -74.18677
        },
        "name": "Stamna Greek Taverna",
        "address": {
            "address1": "1055 Broad St",
            "address2": "",
            "address3": "",
            "city": "Bloomfield",
            "zip_code": "07003",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "1055 Broad St",
                "Bloomfield, NJ 07003"
            ]
        }
    },
    {
        "bid": "jpb9h2lv8eJBmX3Z_CBpSg",
        "rating": 4.0,
        "reviews": 42,
        "coordinates": {
            "latitude": 40.6280598630808,
            "longitude": -74.0293489028262
        },
        "name": "Samia's Mediterranean Food",
        "address": {
            "address1": "7922 3rd Ave",
            "address2": None,
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11209",
            "country": "US",
            "state": "NY",
            "display_address": [
                "7922 3rd Ave",
                "Brooklyn, NY 11209"
            ]
        }
    },
    {
        "bid": "fXeW5v65iVnkIukqZ8D54g",
        "rating": 4.5,
        "reviews": 11,
        "coordinates": {
            "latitude": 41.05473,
            "longitude": -73.54037
        },
        "name": "Taj Mediterranean Mezze and Grill",
        "address": {
            "address1": "211 Summer St",
            "address2": None,
            "address3": "",
            "city": "Stamford",
            "zip_code": "06901",
            "country": "US",
            "state": "CT",
            "display_address": [
                "211 Summer St",
                "Stamford, CT 06901"
            ]
        }
    },
    {
        "bid": "gjIctg7P18f6UocGVW2IMQ",
        "rating": 4.0,
        "reviews": 361,
        "coordinates": {
            "latitude": 40.74189,
            "longitude": -73.99305
        },
        "name": "Bite",
        "address": {
            "address1": "62 W 22nd St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10010",
            "country": "US",
            "state": "NY",
            "display_address": [
                "62 W 22nd St",
                "New York, NY 10010"
            ]
        }
    },
    {
        "bid": "9meUV_lq0wzBJ1cNQWm6ew",
        "rating": 5.0,
        "reviews": 1,
        "coordinates": {
            "latitude": 40.615409,
            "longitude": -73.963656
        },
        "name": "Taste of Akko",
        "address": {
            "address1": "1724 Coney Island Ave",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11230",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1724 Coney Island Ave",
                "Brooklyn, NY 11230"
            ]
        }
    },
    {
        "bid": "I3yUaerVzoYECRk2g0CU_g",
        "rating": 4.0,
        "reviews": 161,
        "coordinates": {
            "latitude": 40.81678,
            "longitude": -73.46654
        },
        "name": "Limani Taverna",
        "address": {
            "address1": "8289 Jericho Tpke",
            "address2": "",
            "address3": None,
            "city": "Woodbury",
            "zip_code": "11797",
            "country": "US",
            "state": "NY",
            "display_address": [
                "8289 Jericho Tpke",
                "Woodbury, NY 11797"
            ]
        }
    },
    {
        "bid": "ift35m5Sbya_3ZWnDo84tA",
        "rating": 3.5,
        "reviews": 140,
        "coordinates": {
            "latitude": 40.592724,
            "longitude": -74.0868
        },
        "name": "Kuzina",
        "address": {
            "address1": "1458 Hylan Blvd",
            "address2": "",
            "address3": "",
            "city": "Staten Island",
            "zip_code": "10305",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1458 Hylan Blvd",
                "Staten Island, NY 10305"
            ]
        }
    },
    {
        "bid": "4bHtiA1md69LDag55kv8lg",
        "rating": 4.0,
        "reviews": 153,
        "coordinates": {
            "latitude": 40.737985,
            "longitude": -73.987703
        },
        "name": "Isabelle's Osteria",
        "address": {
            "address1": "245 Park Ave S",
            "address2": None,
            "address3": None,
            "city": "New York",
            "zip_code": "10003",
            "country": "US",
            "state": "NY",
            "display_address": [
                "245 Park Ave S",
                "New York, NY 10003"
            ]
        }
    },
    {
        "bid": "y6U7NWV5WK3tBmn53fK_8g",
        "rating": 5.0,
        "reviews": 28,
        "coordinates": {
            "latitude": 40.80238,
            "longitude": -73.99317
        },
        "name": "Madison Cafe & Grill",
        "address": {
            "address1": "4 Pembroke Pl",
            "address2": "Ste 101",
            "address3": "",
            "city": "Edgewater",
            "zip_code": "07020",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "4 Pembroke Pl",
                "Ste 101",
                "Edgewater, NJ 07020"
            ]
        }
    },
    {
        "bid": "eTG_KeM6EbbjfBSkHkuIRg",
        "rating": 4.5,
        "reviews": 784,
        "coordinates": {
            "latitude": 40.880978,
            "longitude": -74.38203
        },
        "name": "Kabab Paradise",
        "address": {
            "address1": "76 N Beverwyck Rd",
            "address2": "",
            "address3": "",
            "city": "Lake Hiawatha",
            "zip_code": "07034",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "76 N Beverwyck Rd",
                "Lake Hiawatha, NJ 07034"
            ]
        }
    },
    {
        "bid": "S9QZOR4UwfvYPPcHWfmNTw",
        "rating": 4.0,
        "reviews": 442,
        "coordinates": {
            "latitude": 40.775355401246,
            "longitude": -73.9140461748688
        },
        "name": "Telly's Taverna",
        "address": {
            "address1": "28-13 23rd Ave",
            "address2": "",
            "address3": "",
            "city": "Astoria",
            "zip_code": "11105",
            "country": "US",
            "state": "NY",
            "display_address": [
                "28-13 23rd Ave",
                "Astoria, NY 11105"
            ]
        }
    },
    {
        "bid": "KkbiqhmMmOnHUtAn9f3jFg",
        "rating": 3.5,
        "reviews": 39,
        "coordinates": {
            "latitude": 40.72113493837031,
            "longitude": -74.0455004
        },
        "name": "Ela Greek Kitchen",
        "address": {
            "address1": "179 Newark Ave",
            "address2": None,
            "address3": "",
            "city": "Jersey City",
            "zip_code": "07302",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "179 Newark Ave",
                "Jersey City, NJ 07302"
            ]
        }
    },
    {
        "bid": "9tzCWRhoG-tFHIK2kGAJJA",
        "rating": 5.0,
        "reviews": 1,
        "coordinates": {
            "latitude": 40.807094,
            "longitude": -73.989077
        },
        "name": "The Wild Radish",
        "address": {
            "address1": "225 River Rd",
            "address2": "",
            "address3": None,
            "city": "Edgewater",
            "zip_code": "07020",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "225 River Rd",
                "Edgewater, NJ 07020"
            ]
        }
    },
    {
        "bid": "CPtao9WHPnVJGUS0H4Txww",
        "rating": 3.5,
        "reviews": 150,
        "coordinates": {
            "latitude": 40.757703,
            "longitude": -73.980522
        },
        "name": "Taam Tov",
        "address": {
            "address1": "41 W 47th St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10036",
            "country": "US",
            "state": "NY",
            "display_address": [
                "41 W 47th St",
                "New York, NY 10036"
            ]
        }
    },
    {
        "bid": "I9QmbM5vmYSA_dYM4eHeUg",
        "rating": 4.5,
        "reviews": 70,
        "coordinates": {
            "latitude": 40.80288,
            "longitude": -73.964352
        },
        "name": "Elis Wine Bar & Restaurant",
        "address": {
            "address1": "1012 Amsterdam Ave",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10025",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1012 Amsterdam Ave",
                "New York, NY 10025"
            ]
        }
    },
    {
        "bid": "C_kcGiYKcisroLdB3GXdDw",
        "rating": 3.5,
        "reviews": 36,
        "coordinates": {
            "latitude": 40.889034,
            "longitude": -74.022185
        },
        "name": "Sababa Grill",
        "address": {
            "address1": "456 Cedar Ln",
            "address2": "",
            "address3": "",
            "city": "Teaneck",
            "zip_code": "07666",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "456 Cedar Ln",
                "Teaneck, NJ 07666"
            ]
        }
    },
    {
        "bid": "TPSY6gS0-cncBwlPOUYs1Q",
        "rating": 3.5,
        "reviews": 248,
        "coordinates": {
            "latitude": 40.7780303955078,
            "longitude": -73.9809875488281
        },
        "name": "Seven Hills Mediterranean Grill",
        "address": {
            "address1": "158 W 72nd St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10023",
            "country": "US",
            "state": "NY",
            "display_address": [
                "158 W 72nd St",
                "New York, NY 10023"
            ]
        }
    },
    {
        "bid": "p5PlsI9rZK5vkQo3njhuGQ",
        "rating": 4.0,
        "reviews": 252,
        "coordinates": {
            "latitude": 40.62458,
            "longitude": -74.0303
        },
        "name": "Blue Door Souvlakia",
        "address": {
            "address1": "8413 3rd Ave",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11209",
            "country": "US",
            "state": "NY",
            "display_address": [
                "8413 3rd Ave",
                "Brooklyn, NY 11209"
            ]
        }
    },
    {
        "bid": "Cw7AFqulngjtirLYgVJTTQ",
        "rating": 4.5,
        "reviews": 20,
        "coordinates": {
            "latitude": 40.752031491310916,
            "longitude": -73.98966817052634
        },
        "name": "Greek From Greece",
        "address": {
            "address1": "469 7th Ave",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10018",
            "country": "US",
            "state": "NY",
            "display_address": [
                "469 7th Ave",
                "New York, NY 10018"
            ]
        }
    },
    {
        "bid": "cAEHvzQBxREhpJkFonpYaQ",
        "rating": 3.5,
        "reviews": 370,
        "coordinates": {
            "latitude": 40.71461,
            "longitude": -74.03625
        },
        "name": "Rumi Turkish Grill",
        "address": {
            "address1": "67 Greene St",
            "address2": "",
            "address3": "",
            "city": "Jersey City",
            "zip_code": "07302",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "67 Greene St",
                "Jersey City, NJ 07302"
            ]
        }
    },
    {
        "bid": "g_i8mZ0JhcxXSB2lqPe_Kw",
        "rating": 4.5,
        "reviews": 10,
        "coordinates": {
            "latitude": 40.85232,
            "longitude": -73.93485
        },
        "name": "CAMI Modern Kitchen & Bar",
        "address": {
            "address1": "4325 Broadway",
            "address2": None,
            "address3": None,
            "city": "New York City",
            "zip_code": "10033",
            "country": "US",
            "state": "NY",
            "display_address": [
                "4325 Broadway",
                "New York City, NY 10033"
            ]
        }
    },
    {
        "bid": "i8Tiw2291FA1075lQouA-g",
        "rating": 5.0,
        "reviews": 2,
        "coordinates": {
            "latitude": 40.75502,
            "longitude": -73.96913
        },
        "name": "Izmir Delights Mediterranean Catering",
        "address": {
            "address1": "242 E 50th St",
            "address2": None,
            "address3": "",
            "city": "Manhattan",
            "zip_code": "10022",
            "country": "US",
            "state": "NY",
            "display_address": [
                "242 E 50th St",
                "Manhattan, NY 10022"
            ]
        }
    },
    {
        "bid": "1cRwpGzJkcF4BKcYewMp_g",
        "rating": 4.0,
        "reviews": 196,
        "coordinates": {
            "latitude": 41.013663,
            "longitude": -73.945519
        },
        "name": "The Greek Village",
        "address": {
            "address1": "254 Livingston St",
            "address2": "",
            "address3": "",
            "city": "Northvale",
            "zip_code": "07647",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "254 Livingston St",
                "Northvale, NJ 07647"
            ]
        }
    },
    {
        "bid": "1tiHa-hrvPMBJ-Fk69YWPg",
        "rating": 4.5,
        "reviews": 111,
        "coordinates": {
            "latitude": 40.7806912,
            "longitude": -73.8017165
        },
        "name": "Concettina Restaurant",
        "address": {
            "address1": "160-24 Willets Pt Blvd",
            "address2": "",
            "address3": None,
            "city": "Whitestone",
            "zip_code": "11357",
            "country": "US",
            "state": "NY",
            "display_address": [
                "160-24 Willets Pt Blvd",
                "Whitestone, NY 11357"
            ]
        }
    },
    {
        "bid": "Iyik_4xahSE4gxzR36t20Q",
        "rating": 4.5,
        "reviews": 3,
        "coordinates": {
            "latitude": 40.63863588973571,
            "longitude": -73.70066661964387
        },
        "name": "Famous Pita",
        "address": {
            "address1": "1305 A Broadway",
            "address2": "",
            "address3": None,
            "city": "Hewlett",
            "zip_code": "11557",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1305 A Broadway",
                "Hewlett, NY 11557"
            ]
        }
    },
    {
        "bid": "4_SX63rsdmlFOBzlsbRVlA",
        "rating": 4.0,
        "reviews": 257,
        "coordinates": {
            "latitude": 40.8587321138519,
            "longitude": -74.358713991231
        },
        "name": "Marakesh Restaurant",
        "address": {
            "address1": "321 Rt 46 E",
            "address2": "",
            "address3": "",
            "city": "Parsippany",
            "zip_code": "07054",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "321 Rt 46 E",
                "Parsippany, NJ 07054"
            ]
        }
    },
    {
        "bid": "wZkZmjZEJDraLJgAalnHvA",
        "rating": 4.0,
        "reviews": 1012,
        "coordinates": {
            "latitude": 40.8141624,
            "longitude": -73.960288
        },
        "name": "Pisticci",
        "address": {
            "address1": "125 La Salle St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10027",
            "country": "US",
            "state": "NY",
            "display_address": [
                "125 La Salle St",
                "New York, NY 10027"
            ]
        }
    },
    {
        "bid": "5mJgmAgKpTbCDdpVs7OFxQ",
        "rating": 4.5,
        "reviews": 232,
        "coordinates": {
            "latitude": 40.7462,
            "longitude": -73.9774599
        },
        "name": "Ted's Corner Tavern",
        "address": {
            "address1": "523 3rd Ave",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10016",
            "country": "US",
            "state": "NY",
            "display_address": [
                "523 3rd Ave",
                "New York, NY 10016"
            ]
        }
    },
    {
        "bid": "59IvDUyk4K0eTLiObaKT6g",
        "rating": 4.0,
        "reviews": 13,
        "coordinates": {
            "latitude": 40.54058,
            "longitude": -74.36725
        },
        "name": "Pita Grill & Creperie",
        "address": {
            "address1": "660 Middlesex Ave",
            "address2": "",
            "address3": None,
            "city": "Metuchen",
            "zip_code": "08840",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "660 Middlesex Ave",
                "Metuchen, NJ 08840"
            ]
        }
    },
    {
        "bid": "xefmiLAsKURFc6FDGSRgfQ",
        "rating": 4.0,
        "reviews": 249,
        "coordinates": {
            "latitude": 40.704847720599815,
            "longitude": -74.00642874102088
        },
        "name": "Westville",
        "address": {
            "address1": "110 Wall St",
            "address2": None,
            "address3": "",
            "city": "NY",
            "zip_code": "10005",
            "country": "US",
            "state": "NY",
            "display_address": [
                "110 Wall St",
                "NY, NY 10005"
            ]
        }
    },
    {
        "bid": "jvPYm9rYK-5ddnjU30Oz4Q",
        "rating": 4.5,
        "reviews": 415,
        "coordinates": {
            "latitude": 40.7261499,
            "longitude": -73.98402
        },
        "name": "Avant Garden",
        "address": {
            "address1": "130 E 7th St",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10009",
            "country": "US",
            "state": "NY",
            "display_address": [
                "130 E 7th St",
                "New York, NY 10009"
            ]
        }
    },
    {
        "bid": "nP7xQc2WX4xcNceiG4g1yg",
        "rating": 4.5,
        "reviews": 295,
        "coordinates": {
            "latitude": 40.88385,
            "longitude": -74.28445
        },
        "name": "Antik Greek Kitchen",
        "address": {
            "address1": "335 Fairfield Rd",
            "address2": "",
            "address3": "",
            "city": "Fairfield",
            "zip_code": "07004",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "335 Fairfield Rd",
                "Fairfield, NJ 07004"
            ]
        }
    },
    {
        "bid": "w6KV5eBcp7cqQek8skKbGQ",
        "rating": 4.5,
        "reviews": 5,
        "coordinates": {
            "latitude": 40.7559052,
            "longitude": -73.921274
        },
        "name": "Shawarma Spot",
        "address": {
            "address1": "34-23 Steinway St",
            "address2": None,
            "address3": "",
            "city": "Astoria",
            "zip_code": "11101",
            "country": "US",
            "state": "NY",
            "display_address": [
                "34-23 Steinway St",
                "Astoria, NY 11101"
            ]
        }
    },
    {
        "bid": "7BueYnu-Why21qXninomaQ",
        "rating": 5.0,
        "reviews": 4,
        "coordinates": {
            "latitude": 40.651157,
            "longitude": -74.348708
        },
        "name": "Chutzpah Kitchen",
        "address": {
            "address1": "138 E Broad St",
            "address2": "",
            "address3": None,
            "city": "Westfield",
            "zip_code": "07090",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "138 E Broad St",
                "Westfield, NJ 07090"
            ]
        }
    },
    {
        "bid": "crXjUbBDJIhuh3ygwweuJA",
        "rating": 4.0,
        "reviews": 83,
        "coordinates": {
            "latitude": 40.78661360341939,
            "longitude": -73.79248694608779
        },
        "name": "VIVO! Restaurant & Catering",
        "address": {
            "address1": "201-10 Cross Island Pkwy",
            "address2": "",
            "address3": None,
            "city": "Bayside",
            "zip_code": "11360",
            "country": "US",
            "state": "NY",
            "display_address": [
                "201-10 Cross Island Pkwy",
                "Bayside, NY 11360"
            ]
        }
    },
    {
        "bid": "2D044L5Ole3UQTP1bnRaGg",
        "rating": 4.5,
        "reviews": 19,
        "coordinates": {
            "latitude": 40.45338,
            "longitude": -74.39856
        },
        "name": "Koy Grill",
        "address": {
            "address1": "336 State Route 18",
            "address2": None,
            "address3": "",
            "city": "East Brunswick",
            "zip_code": "08816",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "336 State Route 18",
                "East Brunswick, NJ 08816"
            ]
        }
    },
    {
        "bid": "pjzIGnDkwmG-k2XmH65RQQ",
        "rating": 4.5,
        "reviews": 23,
        "coordinates": {
            "latitude": 40.7559948562588,
            "longitude": -73.9193926972807
        },
        "name": "Anemos Estiatorio",
        "address": {
            "address1": "41-15 34th Ave",
            "address2": "",
            "address3": None,
            "city": "Astoria",
            "zip_code": "11103",
            "country": "US",
            "state": "NY",
            "display_address": [
                "41-15 34th Ave",
                "Astoria, NY 11103"
            ]
        }
    },
    {
        "bid": "F5NgayCZt3ZIqJOmIQWxZg",
        "rating": 3.5,
        "reviews": 4,
        "coordinates": {
            "latitude": 40.61166,
            "longitude": -74.08812
        },
        "name": "Al Baraka Restaurant",
        "address": {
            "address1": "610 Richmond Rd",
            "address2": None,
            "address3": "",
            "city": "Staten Island",
            "zip_code": "10304",
            "country": "US",
            "state": "NY",
            "display_address": [
                "610 Richmond Rd",
                "Staten Island, NY 10304"
            ]
        }
    },
    {
        "bid": "b7YBJ1xaMTk8G_JJpG5j6Q",
        "rating": 5.0,
        "reviews": 27,
        "coordinates": {
            "latitude": 40.715424539650954,
            "longitude": -73.96028533806343
        },
        "name": "Williamsburg Halal Food - Bonjour Habibi",
        "address": {
            "address1": "249 Bedford Ave",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11249",
            "country": "US",
            "state": "NY",
            "display_address": [
                "249 Bedford Ave",
                "Brooklyn, NY 11249"
            ]
        }
    },
    {
        "bid": "xO7abxLk-BxGlVBr32ZPFA",
        "rating": 4.0,
        "reviews": 43,
        "coordinates": {
            "latitude": 40.983531,
            "longitude": -73.686109
        },
        "name": "Meso Restaurants",
        "address": {
            "address1": "22 Elm Pl",
            "address2": None,
            "address3": "",
            "city": "Rye",
            "zip_code": "10580",
            "country": "US",
            "state": "NY",
            "display_address": [
                "22 Elm Pl",
                "Rye, NY 10580"
            ]
        }
    },
    {
        "bid": "szM38YfE8k9SERJoKY8BQw",
        "rating": 5.0,
        "reviews": 31,
        "coordinates": {
            "latitude": 40.74188057613545,
            "longitude": -74.0005185997379
        },
        "name": "Eat Offbeat",
        "address": {
            "address1": "",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10011",
            "country": "US",
            "state": "NY",
            "display_address": [
                "New York, NY 10011"
            ]
        }
    },
    {
        "bid": "_WcjDeOZlFmx_2Quh49j2g",
        "rating": 4.0,
        "reviews": 225,
        "coordinates": {
            "latitude": 40.91444,
            "longitude": -73.77356
        },
        "name": "Tzatziki Greek Grill",
        "address": {
            "address1": "1 Huguenot St",
            "address2": "",
            "address3": "",
            "city": "New Rochelle",
            "zip_code": "10801",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1 Huguenot St",
                "New Rochelle, NY 10801"
            ]
        }
    },
    {
        "bid": "b8hS46GXMqWU_GaBNJiT1g",
        "rating": 4.0,
        "reviews": 332,
        "coordinates": {
            "latitude": 41.039821815479684,
            "longitude": -73.873486
        },
        "name": "MP Taverna Irvington",
        "address": {
            "address1": "1 Bridge St",
            "address2": "",
            "address3": "",
            "city": "Irvington",
            "zip_code": "10533",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1 Bridge St",
                "Irvington, NY 10533"
            ]
        }
    },
    {
        "bid": "Khku97458lDm26qtQZ4s-A",
        "rating": 4.5,
        "reviews": 46,
        "coordinates": {
            "latitude": 40.7776,
            "longitude": -73.94569
        },
        "name": "Effy's Cafe",
        "address": {
            "address1": "1688 York Ave",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10128",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1688 York Ave",
                "New York, NY 10128"
            ]
        }
    },
    {
        "bid": "TYUcE9t6bA9kCEqRNud5Dg",
        "rating": 4.0,
        "reviews": 227,
        "coordinates": {
            "latitude": 40.7678122049352,
            "longitude": -73.9119970122338
        },
        "name": "Kabab Caf\u00e9",
        "address": {
            "address1": "2512 Steinway St",
            "address2": "",
            "address3": "",
            "city": "Astoria",
            "zip_code": "11103",
            "country": "US",
            "state": "NY",
            "display_address": [
                "2512 Steinway St",
                "Astoria, NY 11103"
            ]
        }
    },
    {
        "bid": "qDzj7XJ5T49ln0y9LURHhg",
        "rating": 4.5,
        "reviews": 318,
        "coordinates": {
            "latitude": 40.728652,
            "longitude": -73.702461
        },
        "name": "Crabtree's Restaurant",
        "address": {
            "address1": "226 Jericho Tpke",
            "address2": "",
            "address3": "",
            "city": "Floral Park",
            "zip_code": "11001",
            "country": "US",
            "state": "NY",
            "display_address": [
                "226 Jericho Tpke",
                "Floral Park, NY 11001"
            ]
        }
    },
    {
        "bid": "4DNOjNfx295uuzB-IsrtpQ",
        "rating": 4.0,
        "reviews": 173,
        "coordinates": {
            "latitude": 40.568482,
            "longitude": -74.611858
        },
        "name": "King Tut",
        "address": {
            "address1": "6 W Main St",
            "address2": "",
            "address3": None,
            "city": "Somerville",
            "zip_code": "08876",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "6 W Main St",
                "Somerville, NJ 08876"
            ]
        }
    },
    {
        "bid": "2_X2fnsnbztkkMrvK9na4A",
        "rating": 4.5,
        "reviews": 5,
        "coordinates": {
            "latitude": 40.75346554505132,
            "longitude": -73.90700306743383
        },
        "name": "Peace N Plants",
        "address": {
            "address1": "5317 Broadway",
            "address2": "",
            "address3": None,
            "city": "Queens",
            "zip_code": "11377",
            "country": "US",
            "state": "NY",
            "display_address": [
                "5317 Broadway",
                "Queens, NY 11377"
            ]
        }
    },
    {
        "bid": "cG9aOGzPioO4zl6jxuhMLg",
        "rating": 3.5,
        "reviews": 58,
        "coordinates": {
            "latitude": 40.75873,
            "longitude": -73.9885
        },
        "name": "ilili Box",
        "address": {
            "address1": "700 8th Ave",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10036",
            "country": "US",
            "state": "NY",
            "display_address": [
                "700 8th Ave",
                "New York, NY 10036"
            ]
        }
    },
    {
        "bid": "0mjfhvQArDoqKTg3ONWbmQ",
        "rating": 4.5,
        "reviews": 177,
        "coordinates": {
            "latitude": 40.7592340480098,
            "longitude": -73.972864948706
        },
        "name": "King of Falafel & Shawarma - Cart",
        "address": {
            "address1": "53rd & Park Ave",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10022",
            "country": "US",
            "state": "NY",
            "display_address": [
                "53rd & Park Ave",
                "New York, NY 10022"
            ]
        }
    },
    {
        "bid": "2SI_Wa5L7BvN6vLxtMVJqQ",
        "rating": 4.5,
        "reviews": 30,
        "coordinates": {
            "latitude": 40.36339473205285,
            "longitude": -74.6513915819776
        },
        "name": "ta\u00efm mediterranean kitchen - Princeton",
        "address": {
            "address1": "301 North Harrison Street",
            "address2": None,
            "address3": "",
            "city": "Princeton",
            "zip_code": "08540",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "301 North Harrison Street",
                "Princeton, NJ 08540"
            ]
        }
    },
    {
        "bid": "dgVmfjh7sNV--UMV09DaMw",
        "rating": 5.0,
        "reviews": 1,
        "coordinates": {
            "latitude": 40.76703,
            "longitude": -73.98288
        },
        "name": "Lahavash",
        "address": {
            "address1": "973 8th Ave",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10019",
            "country": "US",
            "state": "NY",
            "display_address": [
                "973 8th Ave",
                "New York, NY 10019"
            ]
        }
    },
    {
        "bid": "Wv7fXFAqhzRZ9eozFVo4yQ",
        "rating": 3.5,
        "reviews": 3,
        "coordinates": {
            "latitude": 40.6458117964899,
            "longitude": -73.9029653902864
        },
        "name": "Mr Grillooo",
        "address": {
            "address1": "1401 Rockway Pkwy",
            "address2": None,
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11236",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1401 Rockway Pkwy",
                "Brooklyn, NY 11236"
            ]
        }
    },
    {
        "bid": "Oax63CojdWkAHvhXonA7ZA",
        "rating": 4.5,
        "reviews": 153,
        "coordinates": {
            "latitude": 40.7885389809394,
            "longitude": -73.7295954473659
        },
        "name": "Rothchild's Coffee & Kitchen",
        "address": {
            "address1": "76 Middle Neck Rd",
            "address2": None,
            "address3": "",
            "city": "Great Neck",
            "zip_code": "11021",
            "country": "US",
            "state": "NY",
            "display_address": [
                "76 Middle Neck Rd",
                "Great Neck, NY 11021"
            ]
        }
    },
    {
        "bid": "P-RaGy9h2tH_IRXcDv7mmg",
        "rating": 4.5,
        "reviews": 12,
        "coordinates": {
            "latitude": 40.715022,
            "longitude": -74.010284
        },
        "name": "WarrenPeace",
        "address": {
            "address1": "77 Warren St",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10007",
            "country": "US",
            "state": "NY",
            "display_address": [
                "77 Warren St",
                "New York, NY 10007"
            ]
        }
    },
    {
        "bid": "3jhFctjqpUyQqsNSZmHF-g",
        "rating": 3.5,
        "reviews": 27,
        "coordinates": {
            "latitude": 40.63194,
            "longitude": -74.02777
        },
        "name": "Gyro King",
        "address": {
            "address1": "7408 3rd Ave",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11209",
            "country": "US",
            "state": "NY",
            "display_address": [
                "7408 3rd Ave",
                "Brooklyn, NY 11209"
            ]
        }
    },
    {
        "bid": "-593H2__eJeiSBT4pU7Wfw",
        "rating": 4.0,
        "reviews": 182,
        "coordinates": {
            "latitude": 40.7856907,
            "longitude": -73.972613
        },
        "name": "Viand",
        "address": {
            "address1": "517 Columbus Ave",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10024",
            "country": "US",
            "state": "NY",
            "display_address": [
                "517 Columbus Ave",
                "New York, NY 10024"
            ]
        }
    },
    {
        "bid": "wecz7ZagG_IcYuCo4pw8Ow",
        "rating": 4.5,
        "reviews": 62,
        "coordinates": {
            "latitude": 41.16077053505586,
            "longitude": -73.86435613286594
        },
        "name": "Melike",
        "address": {
            "address1": "121 Main St",
            "address2": "",
            "address3": None,
            "city": "Ossining",
            "zip_code": "10562",
            "country": "US",
            "state": "NY",
            "display_address": [
                "121 Main St",
                "Ossining, NY 10562"
            ]
        }
    },
    {
        "bid": "maZVyQ0jQ24MeaP9-72XxQ",
        "rating": 4.0,
        "reviews": 301,
        "coordinates": {
            "latitude": 40.768571,
            "longitude": -73.924437
        },
        "name": "Pita Hot",
        "address": {
            "address1": "25-13 30th Ave",
            "address2": "",
            "address3": "",
            "city": "Astoria",
            "zip_code": "11102",
            "country": "US",
            "state": "NY",
            "display_address": [
                "25-13 30th Ave",
                "Astoria, NY 11102"
            ]
        }
    },
    {
        "bid": "3pa9RgZPxtzWx5cvkWWYSw",
        "rating": 4.0,
        "reviews": 107,
        "coordinates": {
            "latitude": 40.7281695,
            "longitude": -73.2274502
        },
        "name": "Mediterranean Express",
        "address": {
            "address1": "625 E Main St",
            "address2": "",
            "address3": "",
            "city": "Bay Shore",
            "zip_code": "11706",
            "country": "US",
            "state": "NY",
            "display_address": [
                "625 E Main St",
                "Bay Shore, NY 11706"
            ]
        }
    },
    {
        "bid": "siCpA-N7BjEuZs1EJhg80g",
        "rating": 4.0,
        "reviews": 457,
        "coordinates": {
            "latitude": 40.5678956955671,
            "longitude": -74.6109391003847
        },
        "name": "Kyma Greek Cuisine",
        "address": {
            "address1": "24 E Main St",
            "address2": "",
            "address3": "",
            "city": "Somerville",
            "zip_code": "08876",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "24 E Main St",
                "Somerville, NJ 08876"
            ]
        }
    },
    {
        "bid": "Yv3MrJfVG3pQJIQbOTxHLA",
        "rating": 4.0,
        "reviews": 213,
        "coordinates": {
            "latitude": 40.89726037467907,
            "longitude": -74.09554404217042
        },
        "name": "Tribos Peri Peri",
        "address": {
            "address1": "383 Market St",
            "address2": "Ste 5",
            "address3": "",
            "city": "Saddle Brook",
            "zip_code": "07663",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "383 Market St",
                "Ste 5",
                "Saddle Brook, NJ 07663"
            ]
        }
    },
    {
        "bid": "UiOUyzrVPTAAjNpGMFhFyQ",
        "rating": 3.5,
        "reviews": 46,
        "coordinates": {
            "latitude": 40.756951,
            "longitude": -73.975883
        },
        "name": "Dill & Parsley",
        "address": {
            "address1": "425 Madison Ave",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10017",
            "country": "US",
            "state": "NY",
            "display_address": [
                "425 Madison Ave",
                "New York, NY 10017"
            ]
        }
    },
    {
        "bid": "BUmtymTHTj_bj7RNmuON3A",
        "rating": 4.0,
        "reviews": 69,
        "coordinates": {
            "latitude": 40.995176,
            "longitude": -74.008512
        },
        "name": "Cedar Tree",
        "address": {
            "address1": "650 Westwood Ave",
            "address2": "",
            "address3": None,
            "city": "River Vale",
            "zip_code": "07675",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "650 Westwood Ave",
                "River Vale, NJ 07675"
            ]
        }
    },
    {
        "bid": "XtSPNWY6L70I6p9l8vnwWg",
        "rating": 3.0,
        "reviews": 428,
        "coordinates": {
            "latitude": 40.71885,
            "longitude": -74.0438099
        },
        "name": "Ibby's Falafel",
        "address": {
            "address1": "303 Grove St",
            "address2": "",
            "address3": "",
            "city": "Jersey City",
            "zip_code": "07302",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "303 Grove St",
                "Jersey City, NJ 07302"
            ]
        }
    },
    {
        "bid": "CypNLOSll5QOSeytI7vYQg",
        "rating": 4.5,
        "reviews": 27,
        "coordinates": {
            "latitude": 40.7419122977856,
            "longitude": -73.9195425573355
        },
        "name": "Shah's Halal Food",
        "address": {
            "address1": "4520-4698 46th St",
            "address2": "",
            "address3": "",
            "city": "Sunnyside",
            "zip_code": "11104",
            "country": "US",
            "state": "NY",
            "display_address": [
                "4520-4698 46th St",
                "Sunnyside, NY 11104"
            ]
        }
    },
    {
        "bid": "w3DiZbqZaCARXG3AsZ0Saw",
        "rating": 4.0,
        "reviews": 12,
        "coordinates": {
            "latitude": 40.729832669882455,
            "longitude": -73.8606600167723
        },
        "name": "Art Of Grill",
        "address": {
            "address1": "97-13 Queens Blvd",
            "address2": None,
            "address3": "",
            "city": "Rego Park",
            "zip_code": "11374",
            "country": "US",
            "state": "NY",
            "display_address": [
                "97-13 Queens Blvd",
                "Rego Park, NY 11374"
            ]
        }
    },
    {
        "bid": "9WQbGNhEj9RxgVFYhR6NOQ",
        "rating": 3.5,
        "reviews": 14,
        "coordinates": {
            "latitude": 40.758266685730895,
            "longitude": -73.97001336653737
        },
        "name": "Miznon",
        "address": {
            "address1": "157 East 53rd St",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10022",
            "country": "US",
            "state": "NY",
            "display_address": [
                "157 East 53rd St",
                "New York, NY 10022"
            ]
        }
    },
    {
        "bid": "gqMEDb3xNkvFTFT8QjLPCQ",
        "rating": 4.0,
        "reviews": 300,
        "coordinates": {
            "latitude": 41.091355,
            "longitude": -73.918355
        },
        "name": "The Greek-ish - Nyack",
        "address": {
            "address1": "8 N Broadway",
            "address2": "",
            "address3": "",
            "city": "Nyack",
            "zip_code": "10960",
            "country": "US",
            "state": "NY",
            "display_address": [
                "8 N Broadway",
                "Nyack, NY 10960"
            ]
        }
    },
    {
        "bid": "mAEYVONH9nIj4BlK4fvlpA",
        "rating": 3.5,
        "reviews": 102,
        "coordinates": {
            "latitude": 40.8171049,
            "longitude": -73.2932593
        },
        "name": "Limani Grille",
        "address": {
            "address1": "1 Vanderbilt Motor Pkwy",
            "address2": "",
            "address3": None,
            "city": "Commack",
            "zip_code": "11725",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1 Vanderbilt Motor Pkwy",
                "Commack, NY 11725"
            ]
        }
    },
    {
        "bid": "dkO1XNRmzR5EWvtubpj-Lg",
        "rating": 4.0,
        "reviews": 254,
        "coordinates": {
            "latitude": 40.69020867353352,
            "longitude": -74.2957334
        },
        "name": "The Halal Guys",
        "address": {
            "address1": "2317 US Rt 22",
            "address2": "",
            "address3": None,
            "city": "Union",
            "zip_code": "07083",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "2317 US Rt 22",
                "Union, NJ 07083"
            ]
        }
    },
    {
        "bid": "pI-aETYVrGd34LF-UTot9A",
        "rating": 4.0,
        "reviews": 34,
        "coordinates": {
            "latitude": 40.831996,
            "longitude": -73.851316
        },
        "name": "Vegan Grill",
        "address": {
            "address1": "1201 Castle Hill Ave",
            "address2": None,
            "address3": "",
            "city": "The Bronx",
            "zip_code": "10462",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1201 Castle Hill Ave",
                "The Bronx, NY 10462"
            ]
        }
    },
    {
        "bid": "YGC-08WWsRf-vfzRN28ETw",
        "rating": 4.0,
        "reviews": 180,
        "coordinates": {
            "latitude": 40.9802082,
            "longitude": -74.1180171
        },
        "name": "Lisa's Mediterranean Cuisine",
        "address": {
            "address1": "28 Oak St",
            "address2": "",
            "address3": "",
            "city": "Ridgewood",
            "zip_code": "07450",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "28 Oak St",
                "Ridgewood, NJ 07450"
            ]
        }
    },
    {
        "bid": "AnxKQTDLaKt7mqRVobx9eA",
        "rating": 3.5,
        "reviews": 138,
        "coordinates": {
            "latitude": 41.02294,
            "longitude": -73.62525
        },
        "name": "Mediterraneo Restaurant",
        "address": {
            "address1": "366 Greenwich Ave",
            "address2": "",
            "address3": "",
            "city": "Greenwich",
            "zip_code": "06830",
            "country": "US",
            "state": "CT",
            "display_address": [
                "366 Greenwich Ave",
                "Greenwich, CT 06830"
            ]
        }
    },
    {
        "bid": "0YAzH3hluzk17YojAt4kCg",
        "rating": 4.5,
        "reviews": 6,
        "coordinates": {
            "latitude": 40.70334969590157,
            "longitude": -73.98675834435635
        },
        "name": "Fuel Fever",
        "address": {
            "address1": "52 Jay St",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11214",
            "country": "US",
            "state": "NY",
            "display_address": [
                "52 Jay St",
                "Brooklyn, NY 11214"
            ]
        }
    },
    {
        "bid": "9w-rEWIIUXBwGKEQsRHSog",
        "rating": 4.0,
        "reviews": 12,
        "coordinates": {
            "latitude": 40.76438,
            "longitude": -73.97968
        },
        "name": "ta\u00efm mediterranean kitchen",
        "address": {
            "address1": "156 W 56th St",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10019",
            "country": "US",
            "state": "NY",
            "display_address": [
                "156 W 56th St",
                "New York, NY 10019"
            ]
        }
    },
    {
        "bid": "_CHgmuCIXI5H_EzjyPATWQ",
        "rating": 2.5,
        "reviews": 4,
        "coordinates": {
            "latitude": 40.753804,
            "longitude": -73.949438
        },
        "name": "Perivoli",
        "address": {
            "address1": "8-08 Queens Plz S",
            "address2": "",
            "address3": None,
            "city": "Long Island City",
            "zip_code": "11101",
            "country": "US",
            "state": "NY",
            "display_address": [
                "8-08 Queens Plz S",
                "Long Island City, NY 11101"
            ]
        }
    },
    {
        "bid": "3idAtiEXe_XfTcPoZC_DcQ",
        "rating": 4.0,
        "reviews": 1132,
        "coordinates": {
            "latitude": 40.728473,
            "longitude": -73.982104
        },
        "name": "Westville",
        "address": {
            "address1": "173 Avenue A",
            "address2": "",
            "address3": "",
            "city": "NY",
            "zip_code": "10009",
            "country": "US",
            "state": "NY",
            "display_address": [
                "173 Avenue A",
                "NY, NY 10009"
            ]
        }
    },
    {
        "bid": "k6J8jvPev2z6Q5iNRjquuw",
        "rating": 4.0,
        "reviews": 42,
        "coordinates": {
            "latitude": 40.7561902,
            "longitude": -73.767676
        },
        "name": "Yummy Yummy",
        "address": {
            "address1": "4724 Bell Blvd",
            "address2": None,
            "address3": "",
            "city": "Bayside",
            "zip_code": "11361",
            "country": "US",
            "state": "NY",
            "display_address": [
                "4724 Bell Blvd",
                "Bayside, NY 11361"
            ]
        }
    },
    {
        "bid": "nbckNJxUlbBynw2EbU6UTg",
        "rating": 4.0,
        "reviews": 858,
        "coordinates": {
            "latitude": 41.0765027,
            "longitude": -73.8583908
        },
        "name": "Lefteris Gyro",
        "address": {
            "address1": "1 North Broadway",
            "address2": "",
            "address3": "",
            "city": "Tarrytown",
            "zip_code": "10591",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1 North Broadway",
                "Tarrytown, NY 10591"
            ]
        }
    },
    {
        "bid": "lP0fNopAi2T01KKHArarow",
        "rating": 4.5,
        "reviews": 18,
        "coordinates": {
            "latitude": 40.5828942841384,
            "longitude": -73.9544864537733
        },
        "name": "The Bay Cafe",
        "address": {
            "address1": "2 Neptune Ave",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11235",
            "country": "US",
            "state": "NY",
            "display_address": [
                "2 Neptune Ave",
                "Brooklyn, NY 11235"
            ]
        }
    },
    {
        "bid": "K2BwmJKplPfAr4N4NKYtwQ",
        "rating": 3.5,
        "reviews": 104,
        "coordinates": {
            "latitude": 40.774981,
            "longitude": -74.02067
        },
        "name": "Beyti Kebab Restaurant",
        "address": {
            "address1": "4105 Park Ave",
            "address2": "",
            "address3": None,
            "city": "Union City",
            "zip_code": "07087",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "4105 Park Ave",
                "Union City, NJ 07087"
            ]
        }
    },
    {
        "bid": "q6ux26c-SfK-679y9lvVbw",
        "rating": 3.5,
        "reviews": 276,
        "coordinates": {
            "latitude": 40.80435,
            "longitude": -73.94766
        },
        "name": "Settepani",
        "address": {
            "address1": "196 Lenox Ave",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10026",
            "country": "US",
            "state": "NY",
            "display_address": [
                "196 Lenox Ave",
                "New York, NY 10026"
            ]
        }
    },
    {
        "bid": "595Kf6h_Xd0hUaE__FKZNA",
        "rating": 3.0,
        "reviews": 69,
        "coordinates": {
            "latitude": 40.7339976520599,
            "longitude": -74.0592405572534
        },
        "name": "Midtown Grill",
        "address": {
            "address1": "584 Summit Ave",
            "address2": "",
            "address3": None,
            "city": "Jersey City",
            "zip_code": "07306",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "584 Summit Ave",
                "Jersey City, NJ 07306"
            ]
        }
    },
    {
        "bid": "tE20h_-KIOMqp72zKZ0-iA",
        "rating": 4.0,
        "reviews": 81,
        "coordinates": {
            "latitude": 40.744599307922165,
            "longitude": -73.99574536689364
        },
        "name": "Operation: Falafel",
        "address": {
            "address1": "232 7th Ave",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10011",
            "country": "US",
            "state": "NY",
            "display_address": [
                "232 7th Ave",
                "New York, NY 10011"
            ]
        }
    },
    {
        "bid": "31n0qHOh87vCkAF-CiCcqg",
        "rating": 4.0,
        "reviews": 56,
        "coordinates": {
            "latitude": 40.7890592515469,
            "longitude": -73.729792535305
        },
        "name": "Grill Time",
        "address": {
            "address1": "90 Middle Neck Rd",
            "address2": "",
            "address3": "",
            "city": "Great Neck",
            "zip_code": "11021",
            "country": "US",
            "state": "NY",
            "display_address": [
                "90 Middle Neck Rd",
                "Great Neck, NY 11021"
            ]
        }
    },
    {
        "bid": "Hk0b84P_jbufMAzkNyIJoQ",
        "rating": 3.5,
        "reviews": 278,
        "coordinates": {
            "latitude": 40.8064400881056,
            "longitude": -73.9873175009109
        },
        "name": "Greek Taverna",
        "address": {
            "address1": "55 The Promenade",
            "address2": None,
            "address3": "",
            "city": "Edgewater",
            "zip_code": "07020",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "55 The Promenade",
                "Edgewater, NJ 07020"
            ]
        }
    },
    {
        "bid": "1gK-0_lGqjxbwiHWcXXdzg",
        "rating": 4.0,
        "reviews": 643,
        "coordinates": {
            "latitude": 40.738058,
            "longitude": -73.989289
        },
        "name": "ABCV",
        "address": {
            "address1": "38 E 19th St",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10003",
            "country": "US",
            "state": "NY",
            "display_address": [
                "38 E 19th St",
                "New York, NY 10003"
            ]
        }
    },
    {
        "bid": "PjfnqELVT517Ahw1HHRR4Q",
        "rating": 4.0,
        "reviews": 136,
        "coordinates": {
            "latitude": 40.75522490868759,
            "longitude": -73.98732317361068
        },
        "name": "Yard House",
        "address": {
            "address1": "575 7th Ave",
            "address2": None,
            "address3": None,
            "city": "New York",
            "zip_code": "10018",
            "country": "US",
            "state": "NY",
            "display_address": [
                "575 7th Ave",
                "New York, NY 10018"
            ]
        }
    },
    {
        "bid": "OYeIasyGnl8DL8zgYVW3ow",
        "rating": 4.0,
        "reviews": 240,
        "coordinates": {
            "latitude": 40.726556,
            "longitude": -73.851522
        },
        "name": "Stix Kosher Restaurant",
        "address": {
            "address1": "10115 Queens Blvd",
            "address2": "",
            "address3": "",
            "city": "Forest Hills",
            "zip_code": "11375",
            "country": "US",
            "state": "NY",
            "display_address": [
                "10115 Queens Blvd",
                "Forest Hills, NY 11375"
            ]
        }
    },
    {
        "bid": "c3IOi78TXzUs3-D0aRAtmQ",
        "rating": 4.5,
        "reviews": 36,
        "coordinates": {
            "latitude": 41.0326835,
            "longitude": -74.0352405
        },
        "name": "Aegean Estiatorio",
        "address": {
            "address1": "99 Park Ave",
            "address2": None,
            "address3": "",
            "city": "Park Ridge",
            "zip_code": "07656",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "99 Park Ave",
                "Park Ridge, NJ 07656"
            ]
        }
    },
    {
        "bid": "CLD0Bh-Z_7oGDQOcYdPGLg",
        "rating": 4.0,
        "reviews": 133,
        "coordinates": {
            "latitude": 40.6237,
            "longitude": -74.02487
        },
        "name": "Le Sajj Restaurant",
        "address": {
            "address1": "8221 5th Ave",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11209",
            "country": "US",
            "state": "NY",
            "display_address": [
                "8221 5th Ave",
                "Brooklyn, NY 11209"
            ]
        }
    },
    {
        "bid": "NUuMeryNv5j0g-qQ6dsjIA",
        "rating": 4.0,
        "reviews": 561,
        "coordinates": {
            "latitude": 40.50012,
            "longitude": -74.45423
        },
        "name": "Sahara Restaurant",
        "address": {
            "address1": "165 Easton Ave",
            "address2": "",
            "address3": "",
            "city": "New Brunswick",
            "zip_code": "08901",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "165 Easton Ave",
                "New Brunswick, NJ 08901"
            ]
        }
    },
    {
        "bid": "ZGcu6Re8LgkzVxKgzRNU8w",
        "rating": 5.0,
        "reviews": 290,
        "coordinates": {
            "latitude": 40.599697,
            "longitude": -74.55903
        },
        "name": "Hills of Herat",
        "address": {
            "address1": "1982 Washington Valley Rd",
            "address2": "Ste 2",
            "address3": None,
            "city": "Martinsville",
            "zip_code": "08836",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "1982 Washington Valley Rd",
                "Ste 2",
                "Martinsville, NJ 08836"
            ]
        }
    },
    {
        "bid": "YCklo1QMs_bREUGRo6UNpQ",
        "rating": 4.5,
        "reviews": 298,
        "coordinates": {
            "latitude": 41.2078850089454,
            "longitude": -73.7286890674938
        },
        "name": "The Turk",
        "address": {
            "address1": "20 S Moger Ave",
            "address2": "",
            "address3": "",
            "city": "Mount Kisco",
            "zip_code": "10549",
            "country": "US",
            "state": "NY",
            "display_address": [
                "20 S Moger Ave",
                "Mount Kisco, NY 10549"
            ]
        }
    },
    {
        "bid": "Diyc2pbhSe18B7MVnlwu1Q",
        "rating": 4.5,
        "reviews": 27,
        "coordinates": {
            "latitude": 41.12426066830882,
            "longitude": -73.416778
        },
        "name": "Mykonos Kouzina",
        "address": {
            "address1": "141 Main St",
            "address2": None,
            "address3": None,
            "city": "Norwalk",
            "zip_code": "06851",
            "country": "US",
            "state": "CT",
            "display_address": [
                "141 Main St",
                "Norwalk, CT 06851"
            ]
        }
    },
    {
        "bid": "9C_nbWFFT4LmXxz_4-5DOA",
        "rating": 4.0,
        "reviews": 67,
        "coordinates": {
            "latitude": 40.731869,
            "longitude": -73.8487524
        },
        "name": "Tov-Li Shawarma",
        "address": {
            "address1": "6447 108th St",
            "address2": "",
            "address3": None,
            "city": "Forest Hills",
            "zip_code": "11375",
            "country": "US",
            "state": "NY",
            "display_address": [
                "6447 108th St",
                "Forest Hills, NY 11375"
            ]
        }
    },
    {
        "bid": "uRGZWfCAbwZBEwauv1Kyxw",
        "rating": 3.0,
        "reviews": 33,
        "coordinates": {
            "latitude": 40.726995,
            "longitude": -74.037956
        },
        "name": "Hummus Grill",
        "address": {
            "address1": "30 Mall Dr W",
            "address2": None,
            "address3": "Newport Centre Mall",
            "city": "Jersey City",
            "zip_code": "07310",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "30 Mall Dr W",
                "Newport Centre Mall",
                "Jersey City, NJ 07310"
            ]
        }
    },
    {
        "bid": "D9nQb14gqhCAOaUUvJz3-Q",
        "rating": 4.0,
        "reviews": 321,
        "coordinates": {
            "latitude": 40.706043,
            "longitude": -74.011776
        },
        "name": "Reserve Cut",
        "address": {
            "address1": "40 Broad St",
            "address2": "Fl 2",
            "address3": "",
            "city": "New York",
            "zip_code": "10004",
            "country": "US",
            "state": "NY",
            "display_address": [
                "40 Broad St",
                "Fl 2",
                "New York, NY 10004"
            ]
        }
    },
    {
        "bid": "q8LJHb_9UG46Lsg01GdBag",
        "rating": 3.5,
        "reviews": 42,
        "coordinates": {
            "latitude": 40.72297,
            "longitude": -73.99576
        },
        "name": "Local 92 - Soho",
        "address": {
            "address1": "244 Mulberry St",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10012",
            "country": "US",
            "state": "NY",
            "display_address": [
                "244 Mulberry St",
                "New York, NY 10012"
            ]
        }
    },
    {
        "bid": "Fhup324BhP55rpNQpYAXgg",
        "rating": 4.5,
        "reviews": 174,
        "coordinates": {
            "latitude": 41.15167,
            "longitude": -73.24017
        },
        "name": "Yalla Organic Hummus & Grill",
        "address": {
            "address1": "222 Post Rd",
            "address2": None,
            "address3": None,
            "city": "Fairfield",
            "zip_code": "06824",
            "country": "US",
            "state": "CT",
            "display_address": [
                "222 Post Rd",
                "Fairfield, CT 06824"
            ]
        }
    },
    {
        "bid": "P8Ef_AHyRF_tkep-83wrVQ",
        "rating": 4.0,
        "reviews": 187,
        "coordinates": {
            "latitude": 41.0528,
            "longitude": -73.54149
        },
        "name": "Kouzina Greek Taverna & Bar",
        "address": {
            "address1": "223 Main St",
            "address2": "",
            "address3": None,
            "city": "Stamford",
            "zip_code": "06901",
            "country": "US",
            "state": "CT",
            "display_address": [
                "223 Main St",
                "Stamford, CT 06901"
            ]
        }
    },
    {
        "bid": "1hbAbWZ3bdJCSg_EoS4zyQ",
        "rating": 2.5,
        "reviews": 166,
        "coordinates": {
            "latitude": 40.759541,
            "longitude": -73.965394
        },
        "name": "Pita Grill",
        "address": {
            "address1": "1083 2nd Ave",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10022",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1083 2nd Ave",
                "New York, NY 10022"
            ]
        }
    },
    {
        "bid": "JyCANTNBOhB7qWrdQFzGEg",
        "rating": 4.5,
        "reviews": 125,
        "coordinates": {
            "latitude": 41.005802,
            "longitude": -73.658749
        },
        "name": "Argana Restaurant & Bar",
        "address": {
            "address1": "325 N Main St",
            "address2": None,
            "address3": "",
            "city": "Port Chester",
            "zip_code": "10573",
            "country": "US",
            "state": "NY",
            "display_address": [
                "325 N Main St",
                "Port Chester, NY 10573"
            ]
        }
    },
    {
        "bid": "X5QzZ75VRdcefyC6762QOw",
        "rating": 5.0,
        "reviews": 72,
        "coordinates": {
            "latitude": 40.8998683768543,
            "longitude": -74.1577463113301
        },
        "name": "Almazaq Restaurant and Bakery",
        "address": {
            "address1": "46 E Railway Ave",
            "address2": "",
            "address3": None,
            "city": "Paterson",
            "zip_code": "07503",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "46 E Railway Ave",
                "Paterson, NJ 07503"
            ]
        }
    },
    {
        "bid": "dGinNAQn1vV0Pks78tPpDQ",
        "rating": 5.0,
        "reviews": 26,
        "coordinates": {
            "latitude": 40.79471001658026,
            "longitude": -74.47851275692302
        },
        "name": "Azure",
        "address": {
            "address1": "3 Pine St",
            "address2": "",
            "address3": None,
            "city": "Morristown",
            "zip_code": "07960",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "3 Pine St",
                "Morristown, NJ 07960"
            ]
        }
    },
    {
        "bid": "n7LwEbf0zsMapAcUtyyeVA",
        "rating": 3.5,
        "reviews": 452,
        "coordinates": {
            "latitude": 40.765861,
            "longitude": -73.987418
        },
        "name": "Medi Restaurant & Wine Bar",
        "address": {
            "address1": "811 9th Ave",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10019",
            "country": "US",
            "state": "NY",
            "display_address": [
                "811 9th Ave",
                "New York, NY 10019"
            ]
        }
    },
    {
        "bid": "jrUnHXeh9bejvE7vG-Dtfg",
        "rating": 4.0,
        "reviews": 196,
        "coordinates": {
            "latitude": 40.86813,
            "longitude": -74.30645
        },
        "name": "Calandra's Mediterranean Grill",
        "address": {
            "address1": "118 US Hwy 46",
            "address2": "",
            "address3": "",
            "city": "Fairfield",
            "zip_code": "07004",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "118 US Hwy 46",
                "Fairfield, NJ 07004"
            ]
        }
    },
    {
        "bid": "mVsCn9tm3B-XeUeqRYBbxA",
        "rating": 4.5,
        "reviews": 15,
        "coordinates": {
            "latitude": 40.756995,
            "longitude": -73.972461
        },
        "name": "Pita Yeero",
        "address": {
            "address1": "570 Lexington Ave",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10022",
            "country": "US",
            "state": "NY",
            "display_address": [
                "570 Lexington Ave",
                "New York, NY 10022"
            ]
        }
    },
    {
        "bid": "OEINxHKmBMTzxTe9MqThnQ",
        "rating": 4.0,
        "reviews": 113,
        "coordinates": {
            "latitude": 41.030518897788,
            "longitude": -74.12961728144232
        },
        "name": "Allendale Mediterranean Grill",
        "address": {
            "address1": "101 W Allendale Ave",
            "address2": "",
            "address3": None,
            "city": "Allendale",
            "zip_code": "07401",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "101 W Allendale Ave",
                "Allendale, NJ 07401"
            ]
        }
    },
    {
        "bid": "kycAM7GyA1pEMmkdVS3xuw",
        "rating": 4.5,
        "reviews": 156,
        "coordinates": {
            "latitude": 40.73065,
            "longitude": -74.00037
        },
        "name": "Wolfnights - The Gourmet Wrap",
        "address": {
            "address1": "121 W 3rd St",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10012",
            "country": "US",
            "state": "NY",
            "display_address": [
                "121 W 3rd St",
                "New York, NY 10012"
            ]
        }
    },
    {
        "bid": "crTAY4Y4shWgWw5W1xfGyw",
        "rating": 5.0,
        "reviews": 35,
        "coordinates": {
            "latitude": 41.06947275470396,
            "longitude": -73.52641900944447
        },
        "name": "Zahra's Corner Grill",
        "address": {
            "address1": "259 Hope St",
            "address2": None,
            "address3": None,
            "city": "Stamford",
            "zip_code": "06906",
            "country": "US",
            "state": "CT",
            "display_address": [
                "259 Hope St",
                "Stamford, CT 06906"
            ]
        }
    },
    {
        "bid": "zKGv7E_UNpL8vCiyfUkJEw",
        "rating": 4.0,
        "reviews": 106,
        "coordinates": {
            "latitude": 40.62666,
            "longitude": -74.13177
        },
        "name": "Gyro King - Staten island",
        "address": {
            "address1": "1267 Forest Ave",
            "address2": "",
            "address3": "",
            "city": "Staten Island",
            "zip_code": "10302",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1267 Forest Ave",
                "Staten Island, NY 10302"
            ]
        }
    },
    {
        "bid": "7KN1q3ssjWoEnT_ggW09IA",
        "rating": 4.0,
        "reviews": 349,
        "coordinates": {
            "latitude": 40.764355,
            "longitude": -73.923586
        },
        "name": "King Souvlaki - Astoria",
        "address": {
            "address1": "31 St And 31 Ave",
            "address2": None,
            "address3": None,
            "city": "Astoria",
            "zip_code": "11106",
            "country": "US",
            "state": "NY",
            "display_address": [
                "31 St And 31 Ave",
                "Astoria, NY 11106"
            ]
        }
    },
    {
        "bid": "VUpzAbKlKblpu2Z1lmcAEw",
        "rating": 4.0,
        "reviews": 152,
        "coordinates": {
            "latitude": 40.771128,
            "longitude": -73.735284
        },
        "name": "Greek Islands",
        "address": {
            "address1": "25317 Northern Blvd",
            "address2": "",
            "address3": "",
            "city": "Little Neck",
            "zip_code": "11362",
            "country": "US",
            "state": "NY",
            "display_address": [
                "25317 Northern Blvd",
                "Little Neck, NY 11362"
            ]
        }
    },
    {
        "bid": "7hdBscsIW7w3DG1hYG0qPg",
        "rating": 4.5,
        "reviews": 78,
        "coordinates": {
            "latitude": 40.77384,
            "longitude": -73.91306
        },
        "name": "Dionysos Restaurant",
        "address": {
            "address1": "23-15 31st St",
            "address2": "",
            "address3": "",
            "city": "Astoria",
            "zip_code": "11105",
            "country": "US",
            "state": "NY",
            "display_address": [
                "23-15 31st St",
                "Astoria, NY 11105"
            ]
        }
    },
    {
        "bid": "pvNAZWVCvE2uSxmqAh7VUQ",
        "rating": 3.5,
        "reviews": 131,
        "coordinates": {
            "latitude": 40.81555,
            "longitude": -74.22024
        },
        "name": "Antika Grill",
        "address": {
            "address1": "578 Bloomfield Ave",
            "address2": None,
            "address3": "",
            "city": "Montclair",
            "zip_code": "07042",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "578 Bloomfield Ave",
                "Montclair, NJ 07042"
            ]
        }
    },
    {
        "bid": "wJODH3V64fFgICLWgT7jVA",
        "rating": 4.5,
        "reviews": 80,
        "coordinates": {
            "latitude": 40.2227925750545,
            "longitude": -74.0338144506156
        },
        "name": "Flame Kabob House",
        "address": {
            "address1": "702 Hwy 35",
            "address2": None,
            "address3": "",
            "city": "Neptune Township",
            "zip_code": "07753",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "702 Hwy 35",
                "Neptune Township, NJ 07753"
            ]
        }
    },
    {
        "bid": "f2BPK1qEPl_AevS3-a8ElQ",
        "rating": 4.0,
        "reviews": 68,
        "coordinates": {
            "latitude": 40.9251443,
            "longitude": -73.7886502
        },
        "name": "The Mirage Restaurant & Caf\u00e9",
        "address": {
            "address1": "690 North Ave",
            "address2": None,
            "address3": "",
            "city": "New Rochelle",
            "zip_code": "10801",
            "country": "US",
            "state": "NY",
            "display_address": [
                "690 North Ave",
                "New Rochelle, NY 10801"
            ]
        }
    },
    {
        "bid": "0RWRIP39mVtu-MR8yYtKLg",
        "rating": 4.5,
        "reviews": 345,
        "coordinates": {
            "latitude": 40.96868,
            "longitude": -73.71293
        },
        "name": "The Greek-ish - Harrison",
        "address": {
            "address1": "273 Halstead Ave",
            "address2": "",
            "address3": "",
            "city": "Harrison",
            "zip_code": "10528",
            "country": "US",
            "state": "NY",
            "display_address": [
                "273 Halstead Ave",
                "Harrison, NY 10528"
            ]
        }
    },
    {
        "bid": "_CAxhv96YGfxnoSi-P8vIQ",
        "rating": 4.5,
        "reviews": 13,
        "coordinates": {
            "latitude": 40.8540381538461,
            "longitude": -73.8870675489306
        },
        "name": "\u00c7akor Restaurant",
        "address": {
            "address1": "632 E 186th St",
            "address2": "",
            "address3": "",
            "city": "Bronx",
            "zip_code": "10458",
            "country": "US",
            "state": "NY",
            "display_address": [
                "632 E 186th St",
                "Bronx, NY 10458"
            ]
        }
    },
    {
        "bid": "7trrz27Cc5bvdCzt0CN2zA",
        "rating": 4.0,
        "reviews": 139,
        "coordinates": {
            "latitude": 40.88241,
            "longitude": -74.146423
        },
        "name": "Istanbul Cafe and Restaurant",
        "address": {
            "address1": "1378 A Main Ave",
            "address2": "",
            "address3": "",
            "city": "Clifton",
            "zip_code": "07011",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "1378 A Main Ave",
                "Clifton, NJ 07011"
            ]
        }
    },
    {
        "bid": "cxvndpb_DjtZaeBj6Ed81A",
        "rating": 3.0,
        "reviews": 310,
        "coordinates": {
            "latitude": 40.75426,
            "longitude": -73.97733
        },
        "name": "Ammos Estiatorio",
        "address": {
            "address1": "52 Vanderbilt Ave",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10017",
            "country": "US",
            "state": "NY",
            "display_address": [
                "52 Vanderbilt Ave",
                "New York, NY 10017"
            ]
        }
    },
    {
        "bid": "D1xIQojuqtk8Y_GSLnJdOQ",
        "rating": 3.5,
        "reviews": 67,
        "coordinates": {
            "latitude": 40.831034263503604,
            "longitude": -74.08951917269141
        },
        "name": "Mamoun's Falafel",
        "address": {
            "address1": "84 Route 17",
            "address2": "",
            "address3": "",
            "city": "East Rutherford",
            "zip_code": "07073",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "84 Route 17",
                "East Rutherford, NJ 07073"
            ]
        }
    },
    {
        "bid": "6CSyG4P-5vicgPIzfXHK7Q",
        "rating": 4.0,
        "reviews": 235,
        "coordinates": {
            "latitude": 40.776263,
            "longitude": -73.916025
        },
        "name": "Gregory's 26 Corner Taverna",
        "address": {
            "address1": "2602 23rd Ave",
            "address2": "",
            "address3": "",
            "city": "Astoria",
            "zip_code": "11105",
            "country": "US",
            "state": "NY",
            "display_address": [
                "2602 23rd Ave",
                "Astoria, NY 11105"
            ]
        }
    },
    {
        "bid": "GuzXia0biL841a9Tq1_S5w",
        "rating": 4.0,
        "reviews": 282,
        "coordinates": {
            "latitude": 40.7896611,
            "longitude": -73.7298918
        },
        "name": "Lola",
        "address": {
            "address1": "113A Middle Neck Rd",
            "address2": "",
            "address3": "",
            "city": "Great Neck",
            "zip_code": "11021",
            "country": "US",
            "state": "NY",
            "display_address": [
                "113A Middle Neck Rd",
                "Great Neck, NY 11021"
            ]
        }
    },
    {
        "bid": "lrf1S6gtyf7CNu8GK_GrWQ",
        "rating": 3.5,
        "reviews": 140,
        "coordinates": {
            "latitude": 40.6099346280098,
            "longitude": -73.9576180279255
        },
        "name": "Aksaray Turkish Cafe Restaurant",
        "address": {
            "address1": "1618 E 16th St",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11229",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1618 E 16th St",
                "Brooklyn, NY 11229"
            ]
        }
    },
    {
        "bid": "RS1qbaCAbI8_5gOloYs2pQ",
        "rating": 3.5,
        "reviews": 233,
        "coordinates": {
            "latitude": 40.8860359191895,
            "longitude": -74.1508560180664
        },
        "name": "Beirut Restaurant",
        "address": {
            "address1": "1543 Main Ave",
            "address2": "",
            "address3": "",
            "city": "Clifton",
            "zip_code": "07011",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "1543 Main Ave",
                "Clifton, NJ 07011"
            ]
        }
    },
    {
        "bid": "qtSwkbm4Os3qiCjJdd0rIg",
        "rating": 4.5,
        "reviews": 108,
        "coordinates": {
            "latitude": 40.975061,
            "longitude": -73.833517
        },
        "name": "Falafel Place",
        "address": {
            "address1": "2219 Central Park Ave",
            "address2": None,
            "address3": "",
            "city": "Yonkers",
            "zip_code": "10710",
            "country": "US",
            "state": "NY",
            "display_address": [
                "2219 Central Park Ave",
                "Yonkers, NY 10710"
            ]
        }
    },
    {
        "bid": "gstTKv8Q7xo2bF6KdnyicQ",
        "rating": 4.0,
        "reviews": 28,
        "coordinates": {
            "latitude": 40.7392,
            "longitude": -74.03006
        },
        "name": "Tastee Platters",
        "address": {
            "address1": "217 Washington St",
            "address2": None,
            "address3": "",
            "city": "Hoboken",
            "zip_code": "07030",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "217 Washington St",
                "Hoboken, NJ 07030"
            ]
        }
    },
    {
        "bid": "zpjKk8V6Muu1ZmILIZKCFA",
        "rating": 4.5,
        "reviews": 329,
        "coordinates": {
            "latitude": 40.9205149,
            "longitude": -74.1192616
        },
        "name": "Taverna Mykonos",
        "address": {
            "address1": "238 Broadway",
            "address2": "",
            "address3": "",
            "city": "Elmwood Park",
            "zip_code": "07407",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "238 Broadway",
                "Elmwood Park, NJ 07407"
            ]
        }
    },
    {
        "bid": "VgwXJPJX2LprvkjAGlYH6A",
        "rating": 4.5,
        "reviews": 3,
        "coordinates": {
            "latitude": 40.7015449,
            "longitude": -73.8872
        },
        "name": "Pera \u017ddera",
        "address": {
            "address1": "66-31 Myrtle Ave",
            "address2": "",
            "address3": None,
            "city": "Ridgewood",
            "zip_code": "11385",
            "country": "US",
            "state": "NY",
            "display_address": [
                "66-31 Myrtle Ave",
                "Ridgewood, NY 11385"
            ]
        }
    },
    {
        "bid": "q45SMZfNrF4XZZWzIC4tGw",
        "rating": 4.0,
        "reviews": 573,
        "coordinates": {
            "latitude": 40.727125,
            "longitude": -74.007683
        },
        "name": "Westville",
        "address": {
            "address1": "333 Hudson St",
            "address2": "",
            "address3": "",
            "city": "NY",
            "zip_code": "10013",
            "country": "US",
            "state": "NY",
            "display_address": [
                "333 Hudson St",
                "NY, NY 10013"
            ]
        }
    },
    {
        "bid": "Ob9s-5YXNkVdbx_c9nsGkQ",
        "rating": 4.0,
        "reviews": 64,
        "coordinates": {
            "latitude": 40.627771,
            "longitude": -74.0230695
        },
        "name": "Shawarma Al-Sham",
        "address": {
            "address1": "7701 5th Ave",
            "address2": None,
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11209",
            "country": "US",
            "state": "NY",
            "display_address": [
                "7701 5th Ave",
                "Brooklyn, NY 11209"
            ]
        }
    },
    {
        "bid": "Cwmrz8Ec_grGoM4Ak-xh7g",
        "rating": 3.5,
        "reviews": 263,
        "coordinates": {
            "latitude": 40.8110884,
            "longitude": -74.2140278
        },
        "name": "Greek Taverna",
        "address": {
            "address1": "292 Bloomfield Ave",
            "address2": "",
            "address3": "",
            "city": "Montclair",
            "zip_code": "07042",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "292 Bloomfield Ave",
                "Montclair, NJ 07042"
            ]
        }
    },
    {
        "bid": "5AW1Mw-FaExxjpnmocJHMQ",
        "rating": 4.0,
        "reviews": 79,
        "coordinates": {
            "latitude": 40.955859,
            "longitude": -73.813219
        },
        "name": "Meat The Greek",
        "address": {
            "address1": "8 Mill Rd",
            "address2": None,
            "address3": "",
            "city": "Eastchester",
            "zip_code": "10709",
            "country": "US",
            "state": "NY",
            "display_address": [
                "8 Mill Rd",
                "Eastchester, NY 10709"
            ]
        }
    },
    {
        "bid": "sZQqxULeVlEHyXTn0yNyfw",
        "rating": 3.5,
        "reviews": 67,
        "coordinates": {
            "latitude": 40.7666692,
            "longitude": -74.2505158
        },
        "name": "Valley Fresh",
        "address": {
            "address1": "8 S Valley Rd",
            "address2": None,
            "address3": "",
            "city": "West Orange",
            "zip_code": "07052",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "8 S Valley Rd",
                "West Orange, NJ 07052"
            ]
        }
    },
    {
        "bid": "sP0fgiQ8Chd4F6sHUWE2kg",
        "rating": 3.5,
        "reviews": 100,
        "coordinates": {
            "latitude": 40.7750129699707,
            "longitude": -73.9481506347656
        },
        "name": "Nargila Grill",
        "address": {
            "address1": "1599 York Ave",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10028",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1599 York Ave",
                "New York, NY 10028"
            ]
        }
    },
    {
        "bid": "NAQO657TpTvvEjv3b1LCBA",
        "rating": 3.5,
        "reviews": 7,
        "coordinates": {
            "latitude": 40.6634339690208,
            "longitude": -74.119353890419
        },
        "name": "A and C Fast Food",
        "address": {
            "address1": "13 W 22nd St",
            "address2": "",
            "address3": "",
            "city": "Bayonne",
            "zip_code": "07002",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "13 W 22nd St",
                "Bayonne, NJ 07002"
            ]
        }
    },
    {
        "bid": "JxABHYmfXZ4zlJEF9H8VVA",
        "rating": 5.0,
        "reviews": 24,
        "coordinates": {
            "latitude": 41.01621,
            "longitude": -73.94337
        },
        "name": "Mazadore Kebab",
        "address": {
            "address1": "29 NY-303",
            "address2": "",
            "address3": None,
            "city": "Tappan",
            "zip_code": "10983",
            "country": "US",
            "state": "NY",
            "display_address": [
                "29 NY-303",
                "Tappan, NY 10983"
            ]
        }
    },
    {
        "bid": "zmWM-mfenM3N_yTaItG1FA",
        "rating": 4.0,
        "reviews": 330,
        "coordinates": {
            "latitude": 40.85476,
            "longitude": -74.11908
        },
        "name": "Cedars",
        "address": {
            "address1": "5 Main Ave",
            "address2": "",
            "address3": "",
            "city": "Wallington",
            "zip_code": "07057",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "5 Main Ave",
                "Wallington, NJ 07057"
            ]
        }
    },
    {
        "bid": "M3oBXAziA_epajfsAXdgng",
        "rating": 4.5,
        "reviews": 92,
        "coordinates": {
            "latitude": 40.5243899,
            "longitude": -74.29827
        },
        "name": "Athens Gyro",
        "address": {
            "address1": "211 New Brunswick Ave",
            "address2": "",
            "address3": None,
            "city": "Perth Amboy",
            "zip_code": "08861",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "211 New Brunswick Ave",
                "Perth Amboy, NJ 08861"
            ]
        }
    },
    {
        "bid": "GDL3bxC44bmsV8it4QFXIQ",
        "rating": 3.0,
        "reviews": 4,
        "coordinates": {
            "latitude": 40.7109178698992,
            "longitude": -74.2057735872542
        },
        "name": "Hiba Halal Grill",
        "address": {
            "address1": "964 Bergen St",
            "address2": "",
            "address3": "",
            "city": "Newark",
            "zip_code": "07112",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "964 Bergen St",
                "Newark, NJ 07112"
            ]
        }
    },
    {
        "bid": "WOk35LoaGXJdXXd9s4Hmsw",
        "rating": 4.0,
        "reviews": 2,
        "coordinates": {
            "latitude": 40.7214608,
            "longitude": -74.06477447109941
        },
        "name": "Zeze Cool",
        "address": {
            "address1": "121 Clifton Place",
            "address2": None,
            "address3": None,
            "city": "Jersey City",
            "zip_code": "07304",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "121 Clifton Place",
                "Jersey City, NJ 07304"
            ]
        }
    },
    {
        "bid": "diUPT_muypq7W7dGSuSB-Q",
        "rating": 3.5,
        "reviews": 215,
        "coordinates": {
            "latitude": 40.895738,
            "longitude": -73.976122
        },
        "name": "La'Mezza",
        "address": {
            "address1": "63 Nathaniel Pl",
            "address2": "",
            "address3": "",
            "city": "Englewood",
            "zip_code": "07631",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "63 Nathaniel Pl",
                "Englewood, NJ 07631"
            ]
        }
    },
    {
        "bid": "dYQsjvy3fcS_9r9-tFaVWQ",
        "rating": 3.0,
        "reviews": 22,
        "coordinates": {
            "latitude": 40.764379,
            "longitude": -73.969991
        },
        "name": "Casa Cruz",
        "address": {
            "address1": "36 E 61st St",
            "address2": None,
            "address3": None,
            "city": "New York",
            "zip_code": "10065",
            "country": "US",
            "state": "NY",
            "display_address": [
                "36 E 61st St",
                "New York, NY 10065"
            ]
        }
    },
    {
        "bid": "Xaa0mvnMw_F1yiLTPhBIfA",
        "rating": 4.0,
        "reviews": 157,
        "coordinates": {
            "latitude": 40.81751070000002,
            "longitude": -73.46646674110448
        },
        "name": "Krinti Mediterranean Grill",
        "address": {
            "address1": "8285 Jericho Tpke",
            "address2": "",
            "address3": "",
            "city": "Woodbury",
            "zip_code": "11797",
            "country": "US",
            "state": "NY",
            "display_address": [
                "8285 Jericho Tpke",
                "Woodbury, NY 11797"
            ]
        }
    },
    {
        "bid": "bgx0OYquBVo3W-vXdN9hmg",
        "rating": 4.0,
        "reviews": 299,
        "coordinates": {
            "latitude": 40.9898453,
            "longitude": -74.0307963
        },
        "name": "Mezza Westwood",
        "address": {
            "address1": "22 Jefferson Ave",
            "address2": "",
            "address3": "",
            "city": "Westwood",
            "zip_code": "07675",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "22 Jefferson Ave",
                "Westwood, NJ 07675"
            ]
        }
    },
    {
        "bid": "HuyU8WpZRfqEbba0mKkvSw",
        "rating": 4.0,
        "reviews": 1957,
        "coordinates": {
            "latitude": 40.70479,
            "longitude": -73.6505
        },
        "name": "Witches Brew Coffee House",
        "address": {
            "address1": "311 Hempstead Tpke",
            "address2": "",
            "address3": "",
            "city": "West Hempstead",
            "zip_code": "11552",
            "country": "US",
            "state": "NY",
            "display_address": [
                "311 Hempstead Tpke",
                "West Hempstead, NY 11552"
            ]
        }
    },
    {
        "bid": "rthmFnic6BxJDGuQ2h8_cw",
        "rating": 3.5,
        "reviews": 15,
        "coordinates": {
            "latitude": 40.6756783,
            "longitude": -73.8189392
        },
        "name": "Sahara Grill Food Cart",
        "address": {
            "address1": "119-02 Rockway Blvd",
            "address2": "",
            "address3": "",
            "city": "South Ozone Park",
            "zip_code": "11420",
            "country": "US",
            "state": "NY",
            "display_address": [
                "119-02 Rockway Blvd",
                "South Ozone Park, NY 11420"
            ]
        }
    },
    {
        "bid": "Fskwbg3Mz626Nbvf_zLILg",
        "rating": 4.5,
        "reviews": 251,
        "coordinates": {
            "latitude": 40.757708,
            "longitude": -73.588165
        },
        "name": "Kabul Kabab House",
        "address": {
            "address1": "247 Post Ave",
            "address2": "",
            "address3": None,
            "city": "Westbury",
            "zip_code": "11590",
            "country": "US",
            "state": "NY",
            "display_address": [
                "247 Post Ave",
                "Westbury, NY 11590"
            ]
        }
    },
    {
        "bid": "C6780ajPevMEhiQlu9zYnw",
        "rating": 4.0,
        "reviews": 654,
        "coordinates": {
            "latitude": 40.809473,
            "longitude": -73.99067
        },
        "name": "Cafe Archetypus",
        "address": {
            "address1": "266 Old River Rd",
            "address2": "",
            "address3": "",
            "city": "Edgewater",
            "zip_code": "07020",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "266 Old River Rd",
                "Edgewater, NJ 07020"
            ]
        }
    },
    {
        "bid": "jGqTG3MUIva8rlSihNGPlw",
        "rating": 5.0,
        "reviews": 11,
        "coordinates": {
            "latitude": 41.033403,
            "longitude": -73.767594
        },
        "name": "Kanopi",
        "address": {
            "address1": "One Renaissance Sq",
            "address2": None,
            "address3": None,
            "city": "White Plains",
            "zip_code": "10601",
            "country": "US",
            "state": "NY",
            "display_address": [
                "One Renaissance Sq",
                "White Plains, NY 10601"
            ]
        }
    },
    {
        "bid": "ONXsF7KBawsPF4fvzSbd9g",
        "rating": 4.5,
        "reviews": 56,
        "coordinates": {
            "latitude": 40.89200254141359,
            "longitude": -74.14192744316242
        },
        "name": "Krichian's Grill & Bistro",
        "address": {
            "address1": "399 Crooks Ave",
            "address2": "",
            "address3": "",
            "city": "Paterson",
            "zip_code": "07503",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "399 Crooks Ave",
                "Paterson, NJ 07503"
            ]
        }
    },
    {
        "bid": "Zr4LCyGTU998s6lSL_D-8Q",
        "rating": 4.0,
        "reviews": 83,
        "coordinates": {
            "latitude": 40.762977451086,
            "longitude": -73.9131711423397
        },
        "name": "Ukus",
        "address": {
            "address1": "42-08 30th Ave",
            "address2": "",
            "address3": "",
            "city": "Astoria",
            "zip_code": "11103",
            "country": "US",
            "state": "NY",
            "display_address": [
                "42-08 30th Ave",
                "Astoria, NY 11103"
            ]
        }
    },
    {
        "bid": "MS28YFeme6hUhqO0uEUK7w",
        "rating": 4.0,
        "reviews": 42,
        "coordinates": {
            "latitude": 40.57822932962021,
            "longitude": -73.9592872523643
        },
        "name": "Clavel",
        "address": {
            "address1": "1001 Brighton Ave",
            "address2": None,
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11235",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1001 Brighton Ave",
                "Brooklyn, NY 11235"
            ]
        }
    },
    {
        "bid": "GH7bLQzEQcZYZKZzgf7svw",
        "rating": 4.0,
        "reviews": 9,
        "coordinates": {
            "latitude": 41.0393934648665,
            "longitude": -73.91584295779467
        },
        "name": "Kapadokya Mediterranean Cuisine",
        "address": {
            "address1": "453 Piermont Ave",
            "address2": "",
            "address3": None,
            "city": "Piermont",
            "zip_code": "10968",
            "country": "US",
            "state": "NY",
            "display_address": [
                "453 Piermont Ave",
                "Piermont, NY 10968"
            ]
        }
    },
    {
        "bid": "s4FX5HfMZw4yLd2Ik52jvw",
        "rating": 4.5,
        "reviews": 197,
        "coordinates": {
            "latitude": 40.5788,
            "longitude": -73.83699
        },
        "name": "Cuisine By Claudette",
        "address": {
            "address1": "143 Beach 116th St",
            "address2": "",
            "address3": "",
            "city": "Rockaway Park",
            "zip_code": "11694",
            "country": "US",
            "state": "NY",
            "display_address": [
                "143 Beach 116th St",
                "Rockaway Park, NY 11694"
            ]
        }
    },
    {
        "bid": "v4cVQTxYNmsuOuj2maZOzQ",
        "rating": 4.5,
        "reviews": 235,
        "coordinates": {
            "latitude": 41.21549,
            "longitude": -73.21322
        },
        "name": "Bereket Turkish Restaurant",
        "address": {
            "address1": "4031 Main St",
            "address2": "",
            "address3": "",
            "city": "Bridgeport",
            "zip_code": "06606",
            "country": "US",
            "state": "CT",
            "display_address": [
                "4031 Main St",
                "Bridgeport, CT 06606"
            ]
        }
    },
    {
        "bid": "7P-A3cBS8S8BiwxyiaTFlg",
        "rating": 4.5,
        "reviews": 140,
        "coordinates": {
            "latitude": 40.878129,
            "longitude": -74.382289
        },
        "name": "Bosphorus Restaurant",
        "address": {
            "address1": "32 N Beverwyck Rd",
            "address2": "",
            "address3": "",
            "city": "Lake Hiawatha",
            "zip_code": "07034",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "32 N Beverwyck Rd",
                "Lake Hiawatha, NJ 07034"
            ]
        }
    },
    {
        "bid": "GtfhGhWmr1kQ4EnFTlwg7w",
        "rating": 4.0,
        "reviews": 1680,
        "coordinates": {
            "latitude": 40.729209,
            "longitude": -74.001066
        },
        "name": "Beatnic - West Village",
        "address": {
            "address1": "185 Bleecker St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10012",
            "country": "US",
            "state": "NY",
            "display_address": [
                "185 Bleecker St",
                "New York, NY 10012"
            ]
        }
    },
    {
        "bid": "B3vbVvQOofXU6lFkrN1_2A",
        "rating": 4.0,
        "reviews": 266,
        "coordinates": {
            "latitude": 40.7675581,
            "longitude": -73.9892952
        },
        "name": "Gardenia Terrace",
        "address": {
            "address1": "826 10th Ave",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10019",
            "country": "US",
            "state": "NY",
            "display_address": [
                "826 10th Ave",
                "New York, NY 10019"
            ]
        }
    },
    {
        "bid": "2Fs93UYjqQr33Q89KlZ9Ug",
        "rating": 4.5,
        "reviews": 103,
        "coordinates": {
            "latitude": 41.1572593579738,
            "longitude": -73.2266020774841
        },
        "name": "Bereket Turkish Cuisine",
        "address": {
            "address1": "2871 Fairfield Ave",
            "address2": "",
            "address3": "",
            "city": "Bridgeport",
            "zip_code": "06605",
            "country": "US",
            "state": "CT",
            "display_address": [
                "2871 Fairfield Ave",
                "Bridgeport, CT 06605"
            ]
        }
    },
    {
        "bid": "JEVTEHfUGkaWOkvw0fjduA",
        "rating": 4.0,
        "reviews": 28,
        "coordinates": {
            "latitude": 40.1803917,
            "longitude": -74.0265995
        },
        "name": "Mr Greek",
        "address": {
            "address1": "823 Belmar Plz",
            "address2": "Unit 5",
            "address3": "",
            "city": "Belmar",
            "zip_code": "07719",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "823 Belmar Plz",
                "Unit 5",
                "Belmar, NJ 07719"
            ]
        }
    },
    {
        "bid": "ra_uZut2rZTm_5A-yrKTyA",
        "rating": 4.5,
        "reviews": 38,
        "coordinates": {
            "latitude": 40.6131490792599,
            "longitude": -74.1307060099566
        },
        "name": "Island Cafe",
        "address": {
            "address1": "949 Jewett Ave",
            "address2": "",
            "address3": "",
            "city": "Staten Island",
            "zip_code": "10314",
            "country": "US",
            "state": "NY",
            "display_address": [
                "949 Jewett Ave",
                "Staten Island, NY 10314"
            ]
        }
    },
    {
        "bid": "zcpA5_1M9msFeyhGhPnhZg",
        "rating": 5.0,
        "reviews": 10,
        "coordinates": {
            "latitude": 40.50002158924707,
            "longitude": -74.64526464315065
        },
        "name": "El Wadi Grill",
        "address": {
            "address1": "601 US Highway 206",
            "address2": "Unit  24",
            "address3": None,
            "city": "Hillsborough",
            "zip_code": "08844",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "601 US Highway 206",
                "Unit  24",
                "Hillsborough, NJ 08844"
            ]
        }
    },
    {
        "bid": "inP3Ca1x9LYZpp4QP0d6vg",
        "rating": 3.5,
        "reviews": 153,
        "coordinates": {
            "latitude": 40.91383187258055,
            "longitude": -73.77781837272468
        },
        "name": "NoMa Social",
        "address": {
            "address1": "1 Radisson Plz",
            "address2": "",
            "address3": "",
            "city": "New Rochelle",
            "zip_code": "10801",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1 Radisson Plz",
                "New Rochelle, NY 10801"
            ]
        }
    },
    {
        "bid": "sJ_YC5Lj7uEFRn8ZxlYz2A",
        "rating": 4.0,
        "reviews": 443,
        "coordinates": {
            "latitude": 40.4973704915297,
            "longitude": -74.44804826501188
        },
        "name": "Efes Mediterranean Grill",
        "address": {
            "address1": "32 Easton Ave",
            "address2": "",
            "address3": "",
            "city": "New Brunswick",
            "zip_code": "08901",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "32 Easton Ave",
                "New Brunswick, NJ 08901"
            ]
        }
    },
    {
        "bid": "Abkg91TpQMon-svPoRmdyQ",
        "rating": 4.5,
        "reviews": 38,
        "coordinates": {
            "latitude": 40.766842,
            "longitude": -73.912843
        },
        "name": "Mum Feteer",
        "address": {
            "address1": "25-48 Steinway St",
            "address2": "",
            "address3": None,
            "city": "Queens",
            "zip_code": "11103",
            "country": "US",
            "state": "NY",
            "display_address": [
                "25-48 Steinway St",
                "Queens, NY 11103"
            ]
        }
    },
    {
        "bid": "IfnapOvyQA8cRq4j2ERNvQ",
        "rating": 4.0,
        "reviews": 477,
        "coordinates": {
            "latitude": 41.05873,
            "longitude": -74.14007
        },
        "name": "Varka Estiatorio",
        "address": {
            "address1": "30 N Spruce St",
            "address2": "",
            "address3": "",
            "city": "Ramsey",
            "zip_code": "07446",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "30 N Spruce St",
                "Ramsey, NJ 07446"
            ]
        }
    },
    {
        "bid": "mNzCMU7RDOCXGjyCQuv3lA",
        "rating": 4.0,
        "reviews": 192,
        "coordinates": {
            "latitude": 40.3377871417559,
            "longitude": -74.0679233961345
        },
        "name": "Greek Eats",
        "address": {
            "address1": "89 Newman Springs Rd",
            "address2": "",
            "address3": "",
            "city": "Shrewsbury",
            "zip_code": "07702",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "89 Newman Springs Rd",
                "Shrewsbury, NJ 07702"
            ]
        }
    },
    {
        "bid": "HB2AbnU77lDXnCO-Hj-XmQ",
        "rating": 4.5,
        "reviews": 55,
        "coordinates": {
            "latitude": 40.6594422345383,
            "longitude": -73.6447722092271
        },
        "name": "Zora's Halal Grill",
        "address": {
            "address1": "91 N Park Ave",
            "address2": "",
            "address3": None,
            "city": "Rockville Centre",
            "zip_code": "11570",
            "country": "US",
            "state": "NY",
            "display_address": [
                "91 N Park Ave",
                "Rockville Centre, NY 11570"
            ]
        }
    },
    {
        "bid": "k_ps7pFNTE48MIm23vg87w",
        "rating": 3.0,
        "reviews": 30,
        "coordinates": {
            "latitude": 40.738255,
            "longitude": -73.614246
        },
        "name": "Olivos Mediterranean Bar & Grill",
        "address": {
            "address1": "630 Old Country Rd",
            "address2": "Fl 2",
            "address3": "Roosevelt Field Mall",
            "city": "Garden City",
            "zip_code": "11530",
            "country": "US",
            "state": "NY",
            "display_address": [
                "630 Old Country Rd",
                "Fl 2",
                "Roosevelt Field Mall",
                "Garden City, NY 11530"
            ]
        }
    },
    {
        "bid": "_AU96YHJM_CgFfw_QzpvAQ",
        "rating": 4.0,
        "reviews": 175,
        "coordinates": {
            "latitude": 40.76886340894398,
            "longitude": -73.9250964
        },
        "name": "Akrotiri Grill",
        "address": {
            "address1": "29-20 30th Ave",
            "address2": "",
            "address3": None,
            "city": "Astoria",
            "zip_code": "11102",
            "country": "US",
            "state": "NY",
            "display_address": [
                "29-20 30th Ave",
                "Astoria, NY 11102"
            ]
        }
    },
    {
        "bid": "mN1358NllxfPIMjGC5WY5A",
        "rating": 3.5,
        "reviews": 384,
        "coordinates": {
            "latitude": 40.610334319877,
            "longitude": -73.954959538747
        },
        "name": "Memo Shish Kebab - Brooklyn",
        "address": {
            "address1": "1821 Kings Hwy",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11229",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1821 Kings Hwy",
                "Brooklyn, NY 11229"
            ]
        }
    },
    {
        "bid": "wvp-SObBSxQYnA5IaewVlA",
        "rating": 4.5,
        "reviews": 141,
        "coordinates": {
            "latitude": 40.74752,
            "longitude": -73.32417
        },
        "name": "Nazar Restaurant & Market",
        "address": {
            "address1": "1474 Deer Park Ave",
            "address2": "",
            "address3": "",
            "city": "North Babylon",
            "zip_code": "11703",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1474 Deer Park Ave",
                "North Babylon, NY 11703"
            ]
        }
    },
    {
        "bid": "kq0YM3YX9tpvMELlGjzTzA",
        "rating": 4.5,
        "reviews": 220,
        "coordinates": {
            "latitude": 40.7553319,
            "longitude": -73.5093498
        },
        "name": "Kebab House",
        "address": {
            "address1": "526 S Broadway",
            "address2": None,
            "address3": "",
            "city": "Hicksville",
            "zip_code": "11801",
            "country": "US",
            "state": "NY",
            "display_address": [
                "526 S Broadway",
                "Hicksville, NY 11801"
            ]
        }
    },
    {
        "bid": "q2DmgTzzx0y9RLtBJZ6z7A",
        "rating": 3.0,
        "reviews": 60,
        "coordinates": {
            "latitude": 40.67268,
            "longitude": -74.20103
        },
        "name": "Terminal One",
        "address": {
            "address1": "566 Spring St",
            "address2": None,
            "address3": "",
            "city": "Elizabeth",
            "zip_code": "07201",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "566 Spring St",
                "Elizabeth, NJ 07201"
            ]
        }
    },
    {
        "bid": "lncpcEHlFEfYW8FxCEjNUw",
        "rating": 4.5,
        "reviews": 124,
        "coordinates": {
            "latitude": 40.601966,
            "longitude": -73.9346629
        },
        "name": "FalafaLafa Marine Park",
        "address": {
            "address1": "3113 Avenue U",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11229",
            "country": "US",
            "state": "NY",
            "display_address": [
                "3113 Avenue U",
                "Brooklyn, NY 11229"
            ]
        }
    },
    {
        "bid": "RY8EfSUz3nExIHs7H3076Q",
        "rating": 3.5,
        "reviews": 4,
        "coordinates": {
            "latitude": 40.756292,
            "longitude": -74.0434014
        },
        "name": "Sophias Kitchen ",
        "address": {
            "address1": "422B Paterson Plank Rd",
            "address2": None,
            "address3": "",
            "city": "Union City",
            "zip_code": "07087",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "422B Paterson Plank Rd",
                "Union City, NJ 07087"
            ]
        }
    },
    {
        "bid": "F5nN8S0BwDqO-04ax7kEUA",
        "rating": 4.0,
        "reviews": 75,
        "coordinates": {
            "latitude": 40.575452,
            "longitude": -73.9776775
        },
        "name": "Teraza Restaurant Lounge",
        "address": {
            "address1": "825 Surf Ave",
            "address2": "Fl 2",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11224",
            "country": "US",
            "state": "NY",
            "display_address": [
                "825 Surf Ave",
                "Fl 2",
                "Brooklyn, NY 11224"
            ]
        }
    },
    {
        "bid": "TcuWyuZAORVnQBPCMNbTgw",
        "rating": 4.5,
        "reviews": 810,
        "coordinates": {
            "latitude": 40.76331,
            "longitude": -73.97717
        },
        "name": "Beyond Sushi",
        "address": {
            "address1": "62 W 56th St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10019",
            "country": "US",
            "state": "NY",
            "display_address": [
                "62 W 56th St",
                "New York, NY 10019"
            ]
        }
    },
    {
        "bid": "CLSiixHnQK_3fZpEvfhA8Q",
        "rating": 5.0,
        "reviews": 60,
        "coordinates": {
            "latitude": 40.6196559,
            "longitude": -73.9582359
        },
        "name": "Falafel Tanami",
        "address": {
            "address1": "1305 E 17th St",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11230",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1305 E 17th St",
                "Brooklyn, NY 11230"
            ]
        }
    },
    {
        "bid": "bHkJ-7cOUTI7SJrqnRpt7g",
        "rating": 4.0,
        "reviews": 26,
        "coordinates": {
            "latitude": 40.613808,
            "longitude": -73.962715
        },
        "name": "King Solomon Glatt Kosher Catering & Reastaurant",
        "address": {
            "address1": "1787 Coney Island Ave",
            "address2": None,
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11230",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1787 Coney Island Ave",
                "Brooklyn, NY 11230"
            ]
        }
    },
    {
        "bid": "2At9cxG4uLElc_INpAe0Lw",
        "rating": 4.0,
        "reviews": 102,
        "coordinates": {
            "latitude": 40.6431503295898,
            "longitude": -73.9701995849609
        },
        "name": "Gyro Cafe",
        "address": {
            "address1": "580 Coney Island Ave",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11218",
            "country": "US",
            "state": "NY",
            "display_address": [
                "580 Coney Island Ave",
                "Brooklyn, NY 11218"
            ]
        }
    },
    {
        "bid": "XAWp4A8xJYaEX8TepS1xOg",
        "rating": 3.5,
        "reviews": 633,
        "coordinates": {
            "latitude": 40.58354,
            "longitude": -73.94087
        },
        "name": "Rocca Cafe Lounge",
        "address": {
            "address1": "2712 Emmons Ave",
            "address2": None,
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11235",
            "country": "US",
            "state": "NY",
            "display_address": [
                "2712 Emmons Ave",
                "Brooklyn, NY 11235"
            ]
        }
    },
    {
        "bid": "kFV-XAalWCEZN5VW77_3Hg",
        "rating": 4.0,
        "reviews": 204,
        "coordinates": {
            "latitude": 40.748279,
            "longitude": -73.986576
        },
        "name": "Market Crates",
        "address": {
            "address1": "26 W 33rd St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10001",
            "country": "US",
            "state": "NY",
            "display_address": [
                "26 W 33rd St",
                "New York, NY 10001"
            ]
        }
    },
    {
        "bid": "dTXVjTsTYmDWWsF-Cy1tGQ",
        "rating": 4.0,
        "reviews": 22,
        "coordinates": {
            "latitude": 40.72675,
            "longitude": -74.07624
        },
        "name": "Alnoor",
        "address": {
            "address1": "772 W Side Ave",
            "address2": None,
            "address3": None,
            "city": "Jersey City",
            "zip_code": "07306",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "772 W Side Ave",
                "Jersey City, NJ 07306"
            ]
        }
    },
    {
        "bid": "PGQX5sI4N56SIwbpo2itiA",
        "rating": 4.0,
        "reviews": 200,
        "coordinates": {
            "latitude": 40.7625,
            "longitude": -73.76961
        },
        "name": "King Souvlaki",
        "address": {
            "address1": "",
            "address2": "",
            "address3": "",
            "city": "Bayside",
            "zip_code": "11361",
            "country": "US",
            "state": "NY",
            "display_address": [
                "Bayside, NY 11361"
            ]
        }
    },
    {
        "bid": "RlAl2v6yLVa1NLAaAduFgQ",
        "rating": 4.0,
        "reviews": 95,
        "coordinates": {
            "latitude": 40.74205,
            "longitude": -73.9931
        },
        "name": "ta\u00efm mediterranean kitchen - Flatiron",
        "address": {
            "address1": "64 W 22nd St",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10010",
            "country": "US",
            "state": "NY",
            "display_address": [
                "64 W 22nd St",
                "New York, NY 10010"
            ]
        }
    },
    {
        "bid": "SU9fIyDu0mvEMZuBw5l2ig",
        "rating": 4.0,
        "reviews": 132,
        "coordinates": {
            "latitude": 40.7401437,
            "longitude": -73.7866026
        },
        "name": "Eons Greek Food For Life",
        "address": {
            "address1": "61-42 188th St",
            "address2": "",
            "address3": None,
            "city": "Fresh Meadows",
            "zip_code": "11365",
            "country": "US",
            "state": "NY",
            "display_address": [
                "61-42 188th St",
                "Fresh Meadows, NY 11365"
            ]
        }
    },
    {
        "bid": "85TC7GGcL5HYKdteMXWyOQ",
        "rating": 2.5,
        "reviews": 164,
        "coordinates": {
            "latitude": 40.752075393172,
            "longitude": -73.98402919938293
        },
        "name": "Colbeh",
        "address": {
            "address1": "32 W 39th St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10018",
            "country": "US",
            "state": "NY",
            "display_address": [
                "32 W 39th St",
                "New York, NY 10018"
            ]
        }
    },
    {
        "bid": "Pl7usBOnUHmpCGWgD4J0Mg",
        "rating": 3.0,
        "reviews": 96,
        "coordinates": {
            "latitude": 40.7524183,
            "longitude": -73.977933
        },
        "name": "Eata Pita",
        "address": {
            "address1": "89 E 42nd St",
            "address2": "",
            "address3": "Grand Central",
            "city": "New York",
            "zip_code": "10017",
            "country": "US",
            "state": "NY",
            "display_address": [
                "89 E 42nd St",
                "Grand Central",
                "New York, NY 10017"
            ]
        }
    },
    {
        "bid": "7NUnc7ZYS-p5WCqgRRVZvw",
        "rating": 4.0,
        "reviews": 159,
        "coordinates": {
            "latitude": 40.5486999,
            "longitude": -74.58666
        },
        "name": "Sahara Restaurant",
        "address": {
            "address1": "337 N Main St",
            "address2": "",
            "address3": None,
            "city": "Manville",
            "zip_code": "08835",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "337 N Main St",
                "Manville, NJ 08835"
            ]
        }
    },
    {
        "bid": "PT_yFcJdOmNQcPzLMqG3pA",
        "rating": 4.0,
        "reviews": 107,
        "coordinates": {
            "latitude": 40.81819,
            "longitude": -73.99317
        },
        "name": "Mythos Greek Taverna",
        "address": {
            "address1": "352 Anderson Ave",
            "address2": "",
            "address3": "",
            "city": "Cliffside Park",
            "zip_code": "07010",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "352 Anderson Ave",
                "Cliffside Park, NJ 07010"
            ]
        }
    },
    {
        "bid": "h0Dt9HdZok61akzsWm4Zsw",
        "rating": 5.0,
        "reviews": 1,
        "coordinates": {
            "latitude": 40.598305,
            "longitude": -73.979954
        },
        "name": "Reggi's Place Caffe",
        "address": {
            "address1": "144 Ave T",
            "address2": None,
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11223",
            "country": "US",
            "state": "NY",
            "display_address": [
                "144 Ave T",
                "Brooklyn, NY 11223"
            ]
        }
    },
    {
        "bid": "mg6pemwG9UOxAEwwMM6Tqg",
        "rating": 4.5,
        "reviews": 34,
        "coordinates": {
            "latitude": 40.71003,
            "longitude": -73.9584
        },
        "name": "Halal-N-out",
        "address": {
            "address1": "197 Havemeyer St",
            "address2": None,
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11211",
            "country": "US",
            "state": "NY",
            "display_address": [
                "197 Havemeyer St",
                "Brooklyn, NY 11211"
            ]
        }
    },
    {
        "bid": "PifDeZuBGQHcBOgdofXkhA",
        "rating": 4.5,
        "reviews": 168,
        "coordinates": {
            "latitude": 40.4396190012751,
            "longitude": -74.4772568761483
        },
        "name": "Four Seasons Mediterranean Cuisine",
        "address": {
            "address1": "1892 Rt 130 N",
            "address2": "",
            "address3": "",
            "city": "North Brunswick",
            "zip_code": "08902",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "1892 Rt 130 N",
                "North Brunswick, NJ 08902"
            ]
        }
    },
    {
        "bid": "EcaAW-p6UfC3HKIHS40OFQ",
        "rating": 3.5,
        "reviews": 164,
        "coordinates": {
            "latitude": 40.7963971,
            "longitude": -74.3146271
        },
        "name": "THAVMA Mediterranean Grill",
        "address": {
            "address1": "6230 Town Center Way",
            "address2": "",
            "address3": "",
            "city": "Livingston",
            "zip_code": "07039",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "6230 Town Center Way",
                "Livingston, NJ 07039"
            ]
        }
    },
    {
        "bid": "SbVbE4VRZ0XvMoZZx1itUg",
        "rating": 4.0,
        "reviews": 122,
        "coordinates": {
            "latitude": 40.85035,
            "longitude": -73.851727
        },
        "name": "The Healthy Kitchen",
        "address": {
            "address1": "1135C Morris Park Ave",
            "address2": "",
            "address3": None,
            "city": "Bronx",
            "zip_code": "10461",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1135C Morris Park Ave",
                "Bronx, NY 10461"
            ]
        }
    },
    {
        "bid": "_-LcAMoys6QGxJkupcG90g",
        "rating": 4.0,
        "reviews": 477,
        "coordinates": {
            "latitude": 40.7746,
            "longitude": -73.90809
        },
        "name": "Tru Astoria",
        "address": {
            "address1": "35-19 Ditmars Blvd",
            "address2": "",
            "address3": "",
            "city": "Astoria",
            "zip_code": "11105",
            "country": "US",
            "state": "NY",
            "display_address": [
                "35-19 Ditmars Blvd",
                "Astoria, NY 11105"
            ]
        }
    },
    {
        "bid": "p_h-nJ4q8ZwVjiTYoKCV_Q",
        "rating": 4.0,
        "reviews": 19,
        "coordinates": {
            "latitude": 40.6089099900247,
            "longitude": -73.958503715344
        },
        "name": "Ankara One Turkish Restaurant",
        "address": {
            "address1": "1425 Kings Hwy",
            "address2": None,
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11229",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1425 Kings Hwy",
                "Brooklyn, NY 11229"
            ]
        }
    },
    {
        "bid": "quezXFIQN9IJS1RvOdYRWw",
        "rating": 5.0,
        "reviews": 124,
        "coordinates": {
            "latitude": 41.319493,
            "longitude": -73.858168
        },
        "name": "Almadinah Market",
        "address": {
            "address1": "1969 E Main St",
            "address2": "",
            "address3": "",
            "city": "Mohegan Lake",
            "zip_code": "10547",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1969 E Main St",
                "Mohegan Lake, NY 10547"
            ]
        }
    },
    {
        "bid": "s_HHbD0TsGMqu6Hp5UW8dg",
        "rating": 4.0,
        "reviews": 60,
        "coordinates": {
            "latitude": 41.00340202745749,
            "longitude": -73.6834761500358
        },
        "name": "Cava",
        "address": {
            "address1": "3 Rye Ridge Plz",
            "address2": None,
            "address3": "",
            "city": "Rye Brook",
            "zip_code": "10573",
            "country": "US",
            "state": "NY",
            "display_address": [
                "3 Rye Ridge Plz",
                "Rye Brook, NY 10573"
            ]
        }
    },
    {
        "bid": "Pl7genlh781_P9-b_WDaqQ",
        "rating": 2.0,
        "reviews": 8,
        "coordinates": {
            "latitude": 40.739178,
            "longitude": -74.007027
        },
        "name": "MTerranean",
        "address": {
            "address1": "52 Gansevoort St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10014",
            "country": "US",
            "state": "NY",
            "display_address": [
                "52 Gansevoort St",
                "New York, NY 10014"
            ]
        }
    },
    {
        "bid": "PdOGgUoJevcOl6iGF-UtHg",
        "rating": 4.5,
        "reviews": 17,
        "coordinates": {
            "latitude": 40.73066,
            "longitude": -74.06214
        },
        "name": "Kulchay",
        "address": {
            "address1": "64 Sip Ave",
            "address2": "",
            "address3": None,
            "city": "Jersey City",
            "zip_code": "07306",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "64 Sip Ave",
                "Jersey City, NJ 07306"
            ]
        }
    },
    {
        "bid": "awRxWGb5C77OYCa-g32fUg",
        "rating": 4.0,
        "reviews": 199,
        "coordinates": {
            "latitude": 40.6221721770876,
            "longitude": -74.0260156989098
        },
        "name": "Ruzana",
        "address": {
            "address1": "486 85th St",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11209",
            "country": "US",
            "state": "NY",
            "display_address": [
                "486 85th St",
                "Brooklyn, NY 11209"
            ]
        }
    },
    {
        "bid": "G6meUIbWgt62AMg2h5KS_Q",
        "rating": 4.0,
        "reviews": 194,
        "coordinates": {
            "latitude": 40.9269293945064,
            "longitude": -73.9635167824173
        },
        "name": "Axia Taverna",
        "address": {
            "address1": "18 Piermont Rd",
            "address2": None,
            "address3": "",
            "city": "Tenafly",
            "zip_code": "07670",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "18 Piermont Rd",
                "Tenafly, NJ 07670"
            ]
        }
    },
    {
        "bid": "hlCRmdzXTTZbQA9dQeepvw",
        "rating": 4.0,
        "reviews": 3,
        "coordinates": {
            "latitude": 40.73715,
            "longitude": -73.99732
        },
        "name": "GyroLand",
        "address": {
            "address1": "519 6th Ave",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10011",
            "country": "US",
            "state": "NY",
            "display_address": [
                "519 6th Ave",
                "New York, NY 10011"
            ]
        }
    },
    {
        "bid": "_4ztTCCumLK79ZJkNqL3ZQ",
        "rating": 4.0,
        "reviews": 455,
        "coordinates": {
            "latitude": 40.645338,
            "longitude": -74.107791
        },
        "name": "Blue",
        "address": {
            "address1": "1115 Richmond Ter",
            "address2": "",
            "address3": "",
            "city": "Staten Island",
            "zip_code": "10310",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1115 Richmond Ter",
                "Staten Island, NY 10310"
            ]
        }
    },
    {
        "bid": "bia7RF6zP-8TXi-PNer9eg",
        "rating": 4.5,
        "reviews": 4,
        "coordinates": {
            "latitude": 40.894421740455186,
            "longitude": -74.15940000183842
        },
        "name": "Ziyafet Restaurant",
        "address": {
            "address1": "978 Main St",
            "address2": "",
            "address3": None,
            "city": "Paterson",
            "zip_code": "07503",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "978 Main St",
                "Paterson, NJ 07503"
            ]
        }
    },
    {
        "bid": "NZJpUCeZxnxQdOf_Zfv-pQ",
        "rating": 3.0,
        "reviews": 12,
        "coordinates": {
            "latitude": 40.77422701466651,
            "longitude": -74.0248387809003
        },
        "name": "Gyro Joint NJ",
        "address": {
            "address1": "3800 Palisade Ave",
            "address2": "",
            "address3": None,
            "city": "Union City",
            "zip_code": "07087",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "3800 Palisade Ave",
                "Union City, NJ 07087"
            ]
        }
    },
    {
        "bid": "P4pP92PS9V_QrGe5QS0XjQ",
        "rating": 3.0,
        "reviews": 9,
        "coordinates": {
            "latitude": 40.9231677456644,
            "longitude": -73.8595272820147
        },
        "name": "Yonkers Oasis Al-Waha",
        "address": {
            "address1": "654 Central Park Ave",
            "address2": "",
            "address3": "",
            "city": "Yonkers",
            "zip_code": "10704",
            "country": "US",
            "state": "NY",
            "display_address": [
                "654 Central Park Ave",
                "Yonkers, NY 10704"
            ]
        }
    },
    {
        "bid": "_3oBZZ8oKRJMVXIvKLhQjw",
        "rating": 5.0,
        "reviews": 4,
        "coordinates": {
            "latitude": 40.830626,
            "longitude": -73.693447
        },
        "name": "The Olive Room -Meeting Pointe-",
        "address": {
            "address1": "172 Main St",
            "address2": None,
            "address3": "",
            "city": "Port Washington",
            "zip_code": "11050",
            "country": "US",
            "state": "NY",
            "display_address": [
                "172 Main St",
                "Port Washington, NY 11050"
            ]
        }
    },
    {
        "bid": "4QnmpXjTj18g8LdOEczliQ",
        "rating": 4.0,
        "reviews": 34,
        "coordinates": {
            "latitude": 40.747374,
            "longitude": -73.892809
        },
        "name": "Shahi Darbar",
        "address": {
            "address1": "72-24 Broadway",
            "address2": None,
            "address3": "",
            "city": "Jackson Heights",
            "zip_code": "11372",
            "country": "US",
            "state": "NY",
            "display_address": [
                "72-24 Broadway",
                "Jackson Heights, NY 11372"
            ]
        }
    },
    {
        "bid": "DUj5b3dap4bCFOfD7GA2IA",
        "rating": 4.0,
        "reviews": 44,
        "coordinates": {
            "latitude": 40.8078499,
            "longitude": -73.7358017
        },
        "name": "Shiraz",
        "address": {
            "address1": "770 Middle Neck Rd",
            "address2": "",
            "address3": "",
            "city": "Great Neck",
            "zip_code": "11024",
            "country": "US",
            "state": "NY",
            "display_address": [
                "770 Middle Neck Rd",
                "Great Neck, NY 11024"
            ]
        }
    },
    {
        "bid": "ShQz0wFmdLkFcqI_sb6oBA",
        "rating": 4.5,
        "reviews": 159,
        "coordinates": {
            "latitude": 40.6259299,
            "longitude": -74.0750599
        },
        "name": "Taverna On The Bay",
        "address": {
            "address1": "661 Bay St",
            "address2": "",
            "address3": None,
            "city": "Staten Island",
            "zip_code": "10304",
            "country": "US",
            "state": "NY",
            "display_address": [
                "661 Bay St",
                "Staten Island, NY 10304"
            ]
        }
    },
    {
        "bid": "uzjbkQIbK1YxGV5UKrTRZA",
        "rating": 4.5,
        "reviews": 224,
        "coordinates": {
            "latitude": 41.117274,
            "longitude": -73.4127
        },
        "name": "Pontos Taverna",
        "address": {
            "address1": "7 Isaac St",
            "address2": "",
            "address3": "",
            "city": "Norwalk",
            "zip_code": "06850",
            "country": "US",
            "state": "CT",
            "display_address": [
                "7 Isaac St",
                "Norwalk, CT 06850"
            ]
        }
    },
    {
        "bid": "1uIAymVzDk9v6gueP8hs7A",
        "rating": 4.0,
        "reviews": 248,
        "coordinates": {
            "latitude": 40.817002,
            "longitude": -74.332095
        },
        "name": "Lithos Estiatorio",
        "address": {
            "address1": "405 Eisenhower Pkwy",
            "address2": "",
            "address3": "",
            "city": "Livingston",
            "zip_code": "07039",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "405 Eisenhower Pkwy",
                "Livingston, NJ 07039"
            ]
        }
    },
    {
        "bid": "yFLjlR0OU7fxjz2ra8ExDw",
        "rating": 3.5,
        "reviews": 17,
        "coordinates": {
            "latitude": 40.730715,
            "longitude": -74.142095
        },
        "name": "Lancer's Restaurant",
        "address": {
            "address1": "459 Ferry St",
            "address2": "",
            "address3": "",
            "city": "Newark",
            "zip_code": "07105",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "459 Ferry St",
                "Newark, NJ 07105"
            ]
        }
    },
    {
        "bid": "WNe9USe6zs7ZkuRwnc8XTQ",
        "rating": 4.5,
        "reviews": 157,
        "coordinates": {
            "latitude": 41.2777385,
            "longitude": -73.22684502355501
        },
        "name": "Abi\u2019s Falafel",
        "address": {
            "address1": "10 Broadway Rd",
            "address2": "",
            "address3": None,
            "city": "Trumbull",
            "zip_code": "06611",
            "country": "US",
            "state": "CT",
            "display_address": [
                "10 Broadway Rd",
                "Trumbull, CT 06611"
            ]
        }
    },
    {
        "bid": "lRlWTtDfIo9B3abciwTL0Q",
        "rating": 3.0,
        "reviews": 70,
        "coordinates": {
            "latitude": 40.7486085,
            "longitude": -73.7577606
        },
        "name": "Patoug Persian Cuisine",
        "address": {
            "address1": "220-06 Horace Harding Expwy",
            "address2": "",
            "address3": "",
            "city": "Oakland Gardens",
            "zip_code": "11364",
            "country": "US",
            "state": "NY",
            "display_address": [
                "220-06 Horace Harding Expwy",
                "Oakland Gardens, NY 11364"
            ]
        }
    },
    {
        "bid": "m0HUo-Vzs3Oxb9MqCu4V7Q",
        "rating": 4.5,
        "reviews": 44,
        "coordinates": {
            "latitude": 40.75245,
            "longitude": -73.98081
        },
        "name": "Balade Your Way",
        "address": {
            "address1": "8 E 41st St",
            "address2": None,
            "address3": "",
            "city": "New York",
            "zip_code": "10017",
            "country": "US",
            "state": "NY",
            "display_address": [
                "8 E 41st St",
                "New York, NY 10017"
            ]
        }
    },
    {
        "bid": "g-Ka1Qr47uJmlGuf-pZd8g",
        "rating": 4.0,
        "reviews": 278,
        "coordinates": {
            "latitude": 41.072603,
            "longitude": -74.137873
        },
        "name": "Greek City",
        "address": {
            "address1": "1300 Rt 17 N",
            "address2": "",
            "address3": "Ramsey Square Mall",
            "city": "Ramsey",
            "zip_code": "07446",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "1300 Rt 17 N",
                "Ramsey Square Mall",
                "Ramsey, NJ 07446"
            ]
        }
    },
    {
        "bid": "8dB9leZ0hUGf4y_Gz2Dsaw",
        "rating": 4.0,
        "reviews": 128,
        "coordinates": {
            "latitude": 40.9433501,
            "longitude": -73.9621362
        },
        "name": "Samdan",
        "address": {
            "address1": "178 Piermont Rd",
            "address2": "",
            "address3": "",
            "city": "Cresskill",
            "zip_code": "07626",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "178 Piermont Rd",
                "Cresskill, NJ 07626"
            ]
        }
    },
    {
        "bid": "hqAsvo-QZUZHGQdTM7WR5A",
        "rating": 4.5,
        "reviews": 99,
        "coordinates": {
            "latitude": 40.808427,
            "longitude": -74.119037
        },
        "name": "Lyndhurst Jerk & Gyro Spot",
        "address": {
            "address1": "307 Ridge Rd",
            "address2": None,
            "address3": "",
            "city": "Lyndhurst",
            "zip_code": "07071",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "307 Ridge Rd",
                "Lyndhurst, NJ 07071"
            ]
        }
    },
    {
        "bid": "5bghoYsf5sWngiwdBLza7w",
        "rating": 4.0,
        "reviews": 83,
        "coordinates": {
            "latitude": 40.93352,
            "longitude": -73.75882
        },
        "name": "Turquoise",
        "address": {
            "address1": "1895 Palmer Ave",
            "address2": "",
            "address3": "",
            "city": "Larchmont",
            "zip_code": "10538",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1895 Palmer Ave",
                "Larchmont, NY 10538"
            ]
        }
    },
    {
        "bid": "fmmbO9nuYMZabG5rZY59CQ",
        "rating": 4.0,
        "reviews": 67,
        "coordinates": {
            "latitude": 40.8094502,
            "longitude": -74.06692679999999
        },
        "name": "German Doner Kebab",
        "address": {
            "address1": "1 American Dream Way",
            "address2": "Level 2 Ste 268",
            "address3": "",
            "city": "East Rutherford",
            "zip_code": "07073",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "1 American Dream Way",
                "Level 2 Ste 268",
                "East Rutherford, NJ 07073"
            ]
        }
    },
    {
        "bid": "BAqvNvWs-DeCPZYh6ntBTw",
        "rating": 3.0,
        "reviews": 211,
        "coordinates": {
            "latitude": 40.67308,
            "longitude": -73.99061
        },
        "name": "Bison & Bourbon",
        "address": {
            "address1": "191 7th St",
            "address2": "",
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11215",
            "country": "US",
            "state": "NY",
            "display_address": [
                "191 7th St",
                "Brooklyn, NY 11215"
            ]
        }
    },
    {
        "bid": "bsVWuEgPAgECh8vOgGSIOQ",
        "rating": 4.0,
        "reviews": 143,
        "coordinates": {
            "latitude": 40.73303,
            "longitude": -73.44575
        },
        "name": "Grecian Grill",
        "address": {
            "address1": "261 Main St",
            "address2": "",
            "address3": "",
            "city": "Farmingdale",
            "zip_code": "11735",
            "country": "US",
            "state": "NY",
            "display_address": [
                "261 Main St",
                "Farmingdale, NY 11735"
            ]
        }
    },
    {
        "bid": "aiIhXRH_gPrKeYZtZEawqA",
        "rating": 3.0,
        "reviews": 58,
        "coordinates": {
            "latitude": 40.79151,
            "longitude": -74.05698
        },
        "name": "Mix Platter Halal Boys",
        "address": {
            "address1": "101 Plaza Ctr",
            "address2": "",
            "address3": None,
            "city": "Secaucus",
            "zip_code": "07094",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "101 Plaza Ctr",
                "Secaucus, NJ 07094"
            ]
        }
    },
    {
        "bid": "9gdokGFQBUqLDItNCCY3YA",
        "rating": 4.0,
        "reviews": 36,
        "coordinates": {
            "latitude": 40.881,
            "longitude": -74.04424
        },
        "name": "Sayat Nova Restaurant",
        "address": {
            "address1": "91 Main St",
            "address2": None,
            "address3": "",
            "city": "Hackensack",
            "zip_code": "07601",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "91 Main St",
                "Hackensack, NJ 07601"
            ]
        }
    },
    {
        "bid": "D4yoqzZ7ycSXGL2xjwJeMg",
        "rating": 4.0,
        "reviews": 17,
        "coordinates": {
            "latitude": 40.62255,
            "longitude": -73.96441
        },
        "name": "la tabun",
        "address": {
            "address1": "1111 Avenue K",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11230",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1111 Avenue K",
                "Brooklyn, NY 11230"
            ]
        }
    },
    {
        "bid": "gKF_n0_7Gv50k3HeoRv_mg",
        "rating": 3.5,
        "reviews": 128,
        "coordinates": {
            "latitude": 40.656364440918,
            "longitude": -73.6162796020508
        },
        "name": "Ayhan's Shish Kebab Restaurant",
        "address": {
            "address1": "550 Sunrise Hwy",
            "address2": "",
            "address3": "",
            "city": "Baldwin",
            "zip_code": "11510",
            "country": "US",
            "state": "NY",
            "display_address": [
                "550 Sunrise Hwy",
                "Baldwin, NY 11510"
            ]
        }
    },
    {
        "bid": "iRiWN3C19-UdicmHb8uPiQ",
        "rating": 3.5,
        "reviews": 141,
        "coordinates": {
            "latitude": 40.742848,
            "longitude": -73.99318
        },
        "name": "Memo Shish Kebab",
        "address": {
            "address1": "100 W 23rd St",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10011",
            "country": "US",
            "state": "NY",
            "display_address": [
                "100 W 23rd St",
                "New York, NY 10011"
            ]
        }
    },
    {
        "bid": "S4SzD0dzdzNO7FW8JM0dkQ",
        "rating": 4.0,
        "reviews": 121,
        "coordinates": {
            "latitude": 40.7265825,
            "longitude": -73.8536276
        },
        "name": "Mezze",
        "address": {
            "address1": "100-18 Queens Blvd",
            "address2": None,
            "address3": "",
            "city": "Forest Hills",
            "zip_code": "11375",
            "country": "US",
            "state": "NY",
            "display_address": [
                "100-18 Queens Blvd",
                "Forest Hills, NY 11375"
            ]
        }
    },
    {
        "bid": "xx7_r5fklSTEbGnXkEiKGw",
        "rating": 4.0,
        "reviews": 2,
        "coordinates": {
            "latitude": 40.75236953522526,
            "longitude": -73.97362264880074
        },
        "name": "Cava",
        "address": {
            "address1": "708 3rd Ave",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10017",
            "country": "US",
            "state": "NY",
            "display_address": [
                "708 3rd Ave",
                "New York, NY 10017"
            ]
        }
    },
    {
        "bid": "z-oniZMalNAx8MT_ifoHfg",
        "rating": 4.0,
        "reviews": 86,
        "coordinates": {
            "latitude": 40.8248163170191,
            "longitude": -73.9838568612533
        },
        "name": "Kabob On the Cliff",
        "address": {
            "address1": "657 Palisade Ave",
            "address2": None,
            "address3": None,
            "city": "Cliffside Park",
            "zip_code": "07010",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "657 Palisade Ave",
                "Cliffside Park, NJ 07010"
            ]
        }
    },
    {
        "bid": "eubzIlAbF-NHCgzREr3IaA",
        "rating": 4.0,
        "reviews": 62,
        "coordinates": {
            "latitude": 40.8005979,
            "longitude": -73.6481442
        },
        "name": "Shish Kebab Grill",
        "address": {
            "address1": "1380 Old Northern Blvd",
            "address2": "",
            "address3": "",
            "city": "Roslyn",
            "zip_code": "11576",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1380 Old Northern Blvd",
                "Roslyn, NY 11576"
            ]
        }
    },
    {
        "bid": "B4HKTYpNjMiZ9o8KiwZMvA",
        "rating": 1.5,
        "reviews": 2,
        "coordinates": {
            "latitude": 40.6763344490678,
            "longitude": -74.2130448252264
        },
        "name": "Halal R Us",
        "address": {
            "address1": "577 N Broad St",
            "address2": "",
            "address3": None,
            "city": "Elizabeth",
            "zip_code": "07208",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "577 N Broad St",
                "Elizabeth, NJ 07208"
            ]
        }
    },
    {
        "bid": "cOxpSez0IHkOuaGfeLgbpA",
        "rating": 3.0,
        "reviews": 141,
        "coordinates": {
            "latitude": 40.8324852463514,
            "longitude": -73.698374528836
        },
        "name": "Ayhan's Shish-Kebab Restaurant",
        "address": {
            "address1": "283 Main St",
            "address2": "",
            "address3": "",
            "city": "Port Washington",
            "zip_code": "11050",
            "country": "US",
            "state": "NY",
            "display_address": [
                "283 Main St",
                "Port Washington, NY 11050"
            ]
        }
    },
    {
        "bid": "WR8HCkBdPJPRPmg5z2Q3jw",
        "rating": 3.5,
        "reviews": 131,
        "coordinates": {
            "latitude": 40.74257,
            "longitude": -73.48212
        },
        "name": "Opa Grille",
        "address": {
            "address1": "505 Stewart Ave",
            "address2": None,
            "address3": None,
            "city": "Bethpage",
            "zip_code": "11714",
            "country": "US",
            "state": "NY",
            "display_address": [
                "505 Stewart Ave",
                "Bethpage, NY 11714"
            ]
        }
    },
    {
        "bid": "xdBdkdXNFQtqdorpBsBYoQ",
        "rating": 4.0,
        "reviews": 60,
        "coordinates": {
            "latitude": 40.57586,
            "longitude": -73.96916
        },
        "name": "Black Sea Fish & Grill",
        "address": {
            "address1": "3100 Ocean Pkwy",
            "address2": None,
            "address3": "",
            "city": "Brooklyn",
            "zip_code": "11235",
            "country": "US",
            "state": "NY",
            "display_address": [
                "3100 Ocean Pkwy",
                "Brooklyn, NY 11235"
            ]
        }
    },
    {
        "bid": "NaWR-AyQDyOeukDz_t1zew",
        "rating": 4.0,
        "reviews": 127,
        "coordinates": {
            "latitude": 40.8935907,
            "longitude": -74.2030434
        },
        "name": "King of Shish Kabab",
        "address": {
            "address1": "932 McBride Ave",
            "address2": "",
            "address3": "",
            "city": "Woodland Park",
            "zip_code": "07424",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "932 McBride Ave",
                "Woodland Park, NJ 07424"
            ]
        }
    },
    {
        "bid": "wPO7dYh-joSLELSwbUinuA",
        "rating": 4.5,
        "reviews": 2,
        "coordinates": {
            "latitude": 40.597901,
            "longitude": -73.963643
        },
        "name": "Baku Nights",
        "address": {
            "address1": "712 Avenue U",
            "address2": None,
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11223",
            "country": "US",
            "state": "NY",
            "display_address": [
                "712 Avenue U",
                "Brooklyn, NY 11223"
            ]
        }
    },
    {
        "bid": "v1isGI0Se7f0te07TBTAYQ",
        "rating": 4.0,
        "reviews": 51,
        "coordinates": {
            "latitude": 40.7533936,
            "longitude": -74.00106591165668
        },
        "name": "Milos Wine Bar",
        "address": {
            "address1": "20 Hudson Yards",
            "address2": "Fl 5",
            "address3": None,
            "city": "New York",
            "zip_code": "10001",
            "country": "US",
            "state": "NY",
            "display_address": [
                "20 Hudson Yards",
                "Fl 5",
                "New York, NY 10001"
            ]
        }
    },
    {
        "bid": "YvGMgQTVwvzMR2hUGrI7wg",
        "rating": 5.0,
        "reviews": 1,
        "coordinates": {
            "latitude": 40.7454557,
            "longitude": -73.9912724
        },
        "name": "Express Halal Food Truck",
        "address": {
            "address1": "88 W 27th St",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10010",
            "country": "US",
            "state": "NY",
            "display_address": [
                "88 W 27th St",
                "New York, NY 10010"
            ]
        }
    },
    {
        "bid": "WVUFdz_T_6smJ7bGb7umDQ",
        "rating": 2.5,
        "reviews": 12,
        "coordinates": {
            "latitude": 40.912469,
            "longitude": -73.837707
        },
        "name": "Lusiadas",
        "address": {
            "address1": "6 Gramatan Ave",
            "address2": "Unit 101",
            "address3": "",
            "city": "Mount Vernon",
            "zip_code": "10550",
            "country": "US",
            "state": "NY",
            "display_address": [
                "6 Gramatan Ave",
                "Unit 101",
                "Mount Vernon, NY 10550"
            ]
        }
    },
    {
        "bid": "zteMS1HMtY35bON3behErw",
        "rating": 4.5,
        "reviews": 7,
        "coordinates": {
            "latitude": 40.78921,
            "longitude": -74.39129
        },
        "name": "ta\u00efm mediterranean kitchen - Florham Park",
        "address": {
            "address1": "176 Columbia Turnpike",
            "address2": "",
            "address3": None,
            "city": "Florham Park",
            "zip_code": "07932",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "176 Columbia Turnpike",
                "Florham Park, NJ 07932"
            ]
        }
    },
    {
        "bid": "l4zRIDWk6hmOcP_jNJj84A",
        "rating": 4.0,
        "reviews": 608,
        "coordinates": {
            "latitude": 40.755963,
            "longitude": -73.928666
        },
        "name": "Psari Seafood Restaurant & Bar",
        "address": {
            "address1": "32-10 36th Ave",
            "address2": "",
            "address3": "",
            "city": "Astoria",
            "zip_code": "11106",
            "country": "US",
            "state": "NY",
            "display_address": [
                "32-10 36th Ave",
                "Astoria, NY 11106"
            ]
        }
    },
    {
        "bid": "qJgNzZKq4fJzxn3Jphde-Q",
        "rating": 4.0,
        "reviews": 147,
        "coordinates": {
            "latitude": 41.12097,
            "longitude": -73.40515
        },
        "name": "Bistro Mediterranean & Tapas Bar",
        "address": {
            "address1": "36 Westport Ave",
            "address2": "",
            "address3": "",
            "city": "Norwalk",
            "zip_code": "06851",
            "country": "US",
            "state": "CT",
            "display_address": [
                "36 Westport Ave",
                "Norwalk, CT 06851"
            ]
        }
    },
    {
        "bid": "qgL7vsorEeSnMghkNGBsPQ",
        "rating": 4.0,
        "reviews": 45,
        "coordinates": {
            "latitude": 40.5426715,
            "longitude": -74.3623068
        },
        "name": "Orchid The",
        "address": {
            "address1": "455 Main St",
            "address2": "",
            "address3": "",
            "city": "Metuchen",
            "zip_code": "08840",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "455 Main St",
                "Metuchen, NJ 08840"
            ]
        }
    },
    {
        "bid": "5AJQ0zXD5cVR2vCiotdmbg",
        "rating": 3.0,
        "reviews": 140,
        "coordinates": {
            "latitude": 40.73988,
            "longitude": -74.00322
        },
        "name": "Istanbul Grill",
        "address": {
            "address1": "310 W 14th St",
            "address2": "",
            "address3": "",
            "city": "New York",
            "zip_code": "10014",
            "country": "US",
            "state": "NY",
            "display_address": [
                "310 W 14th St",
                "New York, NY 10014"
            ]
        }
    },
    {
        "bid": "fJwo7q0KahhMxAbI30KEGw",
        "rating": 5.0,
        "reviews": 2,
        "coordinates": {
            "latitude": 40.089024,
            "longitude": -74.213905
        },
        "name": "Keepshuto",
        "address": {
            "address1": "37 S Clifton Ave",
            "address2": None,
            "address3": "",
            "city": "Lakewood",
            "zip_code": "08701",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "37 S Clifton Ave",
                "Lakewood, NJ 08701"
            ]
        }
    },
    {
        "bid": "ar25bKrHdK6PlQPIN2vrJg",
        "rating": 3.5,
        "reviews": 70,
        "coordinates": {
            "latitude": 40.7416419,
            "longitude": -73.9933102
        },
        "name": "Cava",
        "address": {
            "address1": "678 6th Ave",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10010",
            "country": "US",
            "state": "NY",
            "display_address": [
                "678 6th Ave",
                "New York, NY 10010"
            ]
        }
    },
    {
        "bid": "wfJCzfotoMELb74z4lITOA",
        "rating": 4.0,
        "reviews": 278,
        "coordinates": {
            "latitude": 40.72123,
            "longitude": -74.04592
        },
        "name": "Pet Shop",
        "address": {
            "address1": "193 Newark Ave",
            "address2": None,
            "address3": "",
            "city": "Jersey City",
            "zip_code": "07302",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "193 Newark Ave",
                "Jersey City, NJ 07302"
            ]
        }
    },
    {
        "bid": "CO90_8nlxQx10ATsM3b9AQ",
        "rating": 3.5,
        "reviews": 140,
        "coordinates": {
            "latitude": 40.7580291,
            "longitude": -73.7848921
        },
        "name": "Mythos Authentic Greek Cuisine",
        "address": {
            "address1": "19629 Northern Blvd",
            "address2": "",
            "address3": "",
            "city": "Flushing",
            "zip_code": "11358",
            "country": "US",
            "state": "NY",
            "display_address": [
                "19629 Northern Blvd",
                "Flushing, NY 11358"
            ]
        }
    },
    {
        "bid": "csD219GgiN6HB2_dMjUfOw",
        "rating": 3.5,
        "reviews": 3,
        "coordinates": {
            "latitude": 40.78025,
            "longitude": -73.980995
        },
        "name": "Homemade by Miriam",
        "address": {
            "address1": "300 Amsterdam Ave",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10023",
            "country": "US",
            "state": "NY",
            "display_address": [
                "300 Amsterdam Ave",
                "New York, NY 10023"
            ]
        }
    },
    {
        "bid": "34Ll2wHSX1EjaHKeB8zm3w",
        "rating": 3.5,
        "reviews": 232,
        "coordinates": {
            "latitude": 40.717472076416,
            "longitude": -74.3564224243164
        },
        "name": "Summit Greek Grill",
        "address": {
            "address1": "90 Summit Ave",
            "address2": "",
            "address3": "",
            "city": "Summit",
            "zip_code": "07901",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "90 Summit Ave",
                "Summit, NJ 07901"
            ]
        }
    },
    {
        "bid": "4qFR5aSGzabsKpGmmzmK0Q",
        "rating": 4.5,
        "reviews": 272,
        "coordinates": {
            "latitude": 41.2759,
            "longitude": -73.78253
        },
        "name": "Pappous Greek Kitchen",
        "address": {
            "address1": "1983 Commerce St",
            "address2": "",
            "address3": None,
            "city": "Yorktown Heights",
            "zip_code": "10598",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1983 Commerce St",
                "Yorktown Heights, NY 10598"
            ]
        }
    },
    {
        "bid": "ZhjRaJkfCIVopvamUzrEsA",
        "rating": 4.0,
        "reviews": 213,
        "coordinates": {
            "latitude": 40.8540465225016,
            "longitude": -73.8889484480023
        },
        "name": "San Gennaro Trattoria Restaurant Bar",
        "address": {
            "address1": "2329 Arthur Ave",
            "address2": "",
            "address3": "",
            "city": "West Bronx",
            "zip_code": "10458",
            "country": "US",
            "state": "NY",
            "display_address": [
                "2329 Arthur Ave",
                "West Bronx, NY 10458"
            ]
        }
    },
    {
        "bid": "MCVlUwhwQGpOt1veu-s93w",
        "rating": 4.0,
        "reviews": 117,
        "coordinates": {
            "latitude": 40.77226,
            "longitude": -73.7345
        },
        "name": "Kebab House",
        "address": {
            "address1": "25505 Northern Blvd",
            "address2": "",
            "address3": "",
            "city": "Little Neck",
            "zip_code": "11362",
            "country": "US",
            "state": "NY",
            "display_address": [
                "25505 Northern Blvd",
                "Little Neck, NY 11362"
            ]
        }
    },
    {
        "bid": "h96VCmjaFcxoxcH9ho1xKw",
        "rating": 4.5,
        "reviews": 7,
        "coordinates": {
            "latitude": 41.0515163,
            "longitude": -73.5393219
        },
        "name": "Taste of Grill",
        "address": {
            "address1": "270 Atlantic St",
            "address2": None,
            "address3": "",
            "city": "Stamford  Ct",
            "zip_code": "06901",
            "country": "US",
            "state": "CT",
            "display_address": [
                "270 Atlantic St",
                "Stamford  Ct, CT 06901"
            ]
        }
    },
    {
        "bid": "gXrj1hbH0cz_-GddzL1gDQ",
        "rating": 3.5,
        "reviews": 166,
        "coordinates": {
            "latitude": 40.8278494765447,
            "longitude": -73.9875280798444
        },
        "name": "Istanbul Borek & Kebab",
        "address": {
            "address1": "360 Lawton Ave",
            "address2": "",
            "address3": "",
            "city": "Cliffside Park",
            "zip_code": "07010",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "360 Lawton Ave",
                "Cliffside Park, NJ 07010"
            ]
        }
    },
    {
        "bid": "i6xP3ZfL78PXg2gjsOz-og",
        "rating": 4.0,
        "reviews": 57,
        "coordinates": {
            "latitude": 40.77625,
            "longitude": -73.98146
        },
        "name": "Noidue Carne",
        "address": {
            "address1": "141 W 69th St",
            "address2": "",
            "address3": None,
            "city": "New York",
            "zip_code": "10023",
            "country": "US",
            "state": "NY",
            "display_address": [
                "141 W 69th St",
                "New York, NY 10023"
            ]
        }
    },
    {
        "bid": "8Cv7q5bIKJG06Gw6Y2WYDw",
        "rating": 3.0,
        "reviews": 20,
        "coordinates": {
            "latitude": 40.768832,
            "longitude": -73.955591
        },
        "name": "Mexiterranean Grill",
        "address": {
            "address1": "1365 1st Ave",
            "address2": None,
            "address3": None,
            "city": "New York",
            "zip_code": "10021",
            "country": "US",
            "state": "NY",
            "display_address": [
                "1365 1st Ave",
                "New York, NY 10021"
            ]
        }
    },
    {
        "bid": "gP8mp6O-z21prrrQ4nfABg",
        "rating": 4.0,
        "reviews": 59,
        "coordinates": {
            "latitude": 40.62726,
            "longitude": -74.02323
        },
        "name": "Istakoza Seafood & Steak",
        "address": {
            "address1": "7721 5th Ave",
            "address2": "",
            "address3": None,
            "city": "Brooklyn",
            "zip_code": "11209",
            "country": "US",
            "state": "NY",
            "display_address": [
                "7721 5th Ave",
                "Brooklyn, NY 11209"
            ]
        }
    },
    {
        "bid": "6YGENp2AoGxR1EhZOb5eag",
        "rating": 5.0,
        "reviews": 19,
        "coordinates": {
            "latitude": 40.87931,
            "longitude": -74.04721
        },
        "name": "Shami Falafel",
        "address": {
            "address1": "29 State St",
            "address2": None,
            "address3": "",
            "city": "Hackensack",
            "zip_code": "07601",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "29 State St",
                "Hackensack, NJ 07601"
            ]
        }
    },
    {
        "bid": "TmKOAdfxucvj6e1EYjHcKw",
        "rating": 4.0,
        "reviews": 182,
        "coordinates": {
            "latitude": 40.8148590256261,
            "longitude": -74.2219932365319
        },
        "name": "Beyond Pita",
        "address": {
            "address1": "82 Church St",
            "address2": "",
            "address3": "",
            "city": "Montclair",
            "zip_code": "07042",
            "country": "US",
            "state": "NJ",
            "display_address": [
                "82 Church St",
                "Montclair, NJ 07042"
            ]
        }
    },
    {
        "bid": "gL-EZ0fqhqaCHyuxtsyXCQ",
        "rating": 3.5,
        "reviews": 92,
        "coordinates": {
            "latitude": 40.588123,
            "longitude": -73.665405
        },
        "name": "Abe's Pitaria",
        "address": {
            "address1": "32 W Park Ave",
            "address2": "",
            "address3": "",
            "city": "Long Beach",
            "zip_code": "11561",
            "country": "US",
            "state": "NY",
            "display_address": [
                "32 W Park Ave",
                "Long Beach, NY 11561"
            ]
        }
    }
]
    # 1
    insert_data(restraunts)
    return
def insert_data(data_list, db=None, table='yelp-restaurants'):
    if not db:
        db = boto3.resource('dynamodb')
    table = db.Table(table)
    # overwrite if the same index is provided
    for data in data_list:
        data['insertedAtTimestamp'] = str(datetime.now())
        item = json.loads(json.dumps(data), parse_float=Decimal)
        response = table.put_item(Item=item)
    print('@insert_data: response', response)
    return response
    
    
def lookup_data(key, db=None, table='6998Demo'):
    if not db:
        db = boto3.resource('dynamodb')
    table = db.Table(table)
    try:
        response = table.get_item(Key=key)
    except ClientError as e:
        print('Error', e.response['Error']['Message'])
    else:
        print(response['Item'])
        return response['Item']
def update_item(key, feature, db=None, table='6998Demo'):
    if not db:
        db = boto3.resource('dynamodb')
    table = db.Table(table)
    # change student location
    response = table.update_item(
        Key=key,
        UpdateExpression="set #feature=:f",
        ExpressionAttributeValues={
            ':f': feature
        },
        ExpressionAttributeNames={
            "#feature": "from"
        },
        ReturnValues="UPDATED_NEW"
    )
    print(response)
    return response
def delete_item(key, db=None, table='6998Demo'):
    if not db:
        db = boto3.resource('dynamodb')
    table = db.Table(table)
    try:
        response = table.delete_item(Key=key)
    except ClientError as e:
        print('Error', e.response['Error']['Message'])
    else:
        print(response)
        return response